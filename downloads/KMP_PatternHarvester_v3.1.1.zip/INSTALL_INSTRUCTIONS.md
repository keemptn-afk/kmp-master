# 🔧 KMP Pattern Harvester v3.1.1 — Install Guide

## ⭐ What's New

**v3.1.1 = v3.1 + FILE_COMMON patch** — แก้ปัญหา CSV ไฟล์หายระหว่าง Strategy Tester runs

ไฟล์ output ทั้งหมดจะเขียนที่ **path เดียว**:
```
Windows: C:\Users\<USER>\AppData\Roaming\MetaQuotes\Terminal\Common\Files\
Mac:     ~/Library/Application Support/MetaTrader 5/Common/Files/
```

หรือใน MT5: **File → Open Common Folder → Files/**

---

## 🛑 ก่อนติดตั้ง — หยุดของที่รันอยู่

### ถ้ามี Strategy Tester รันอยู่
- กด **Stop** ใน Strategy Tester ทุก instance

### ถ้ามี EA อยู่ใน chart
- คลิกขวาที่ chart → **Expert Advisors → Remove**

### ถ้า MetaEditor เปิด EA อยู่
- ปิด tab EA หรือปิด MetaEditor ทั้งหมด

### ถ้ารัน 2 MT5 instances
- หยุด**ทั้ง 2** instance — ต้อง recompile แต่ละ instance

---

## 🚀 ขั้นตอนติดตั้ง (5 ขั้นตอน)

### 1️⃣ Backup ของเดิม (สำคัญ!)

ใน MT5 → **File → Open Data Folder** → folder ชื่อยาวๆ เปิดขึ้นมา

ใน folder นี้จะเห็น:
```
MQL5/
├── Experts/
│   └── KMP_PatternHarvester.mq5    ← ของเดิม
├── Include/
│   ├── KMP_HarvesterLogger.mqh
│   ├── KMP_Indicators.mqh
│   ├── KMP_PatternMetadata.mqh
│   ├── KMP_Patterns.mqh
│   ├── KMP_Structures.mqh
│   └── Patterns/...
```

**Copy folder `MQL5` ไปวางที่อื่นก่อน** (เช่น Desktop) เป็น backup

### 2️⃣ ลบไฟล์ EA เก่า

ใน `MQL5/Experts/` ลบ:
- `KMP_PatternHarvester.mq5`
- `KMP_PatternHarvester.ex5` (compiled binary)

ใน `MQL5/Include/` ลบ:
- `KMP_HarvesterLogger.mqh`
- `KMP_Indicators.mqh`
- `KMP_PatternMetadata.mqh`
- `KMP_Patterns.mqh`
- `KMP_Structures.mqh`

ใน `MQL5/Include/Patterns/` ลบไฟล์ `KMP_*.mqh` ทั้งหมด

### 3️⃣ วางไฟล์ใหม่

แตก zip นี้ → ได้ folder `MQL5/` 

**ลาก folder `MQL5` ทับ** ไปที่ data folder ของ MT5

(หรือ copy ทุกไฟล์ไปวางตรงๆ ตาม structure)

### 4️⃣ Recompile

เปิด **MetaEditor** (กด F4 ใน MT5):
1. เปิด `Experts/KMP_PatternHarvester.mq5`
2. กด **F7** เพื่อ Compile
3. ✅ ต้องเห็น `0 errors, 0 warnings`
4. ถ้า error → ตรวจไฟล์ที่ขาด/path ผิด

### 5️⃣ ลบ Tester cache

ลบทุกไฟล์ใน `MQL5/Profiles/Tester/KMP_PatternHarvester*.set`

(หรือ `KeemPatternHarvester*.set` ถ้าชื่อเก่า)

---

## ✅ ตรวจว่า Patch ทำงาน

หลังรัน Strategy Tester ดู Journal tab — ต้องเห็น:
```
Phase 1: ON
Phase 2: ON  
Phase 3: ON
Time-stop: 240h
Weekend mode: AUTO
```

ที่ **File → Open Common Folder → Files/** ต้องเห็น CSV ออกชื่อ:
```
KMP_Harvest_<SYMBOL>_<TF>.csv
```

---

## 🔄 Workflow ใหม่

### รัน MT5 พร้อมกัน 2 instances

```
MT5 #1                          MT5 #2
─────────────                   ─────────────
BTC H1                          ETH H4
BTC H4                          ETH H1
EUR H1                          XAU H4
EUR H4                          XAU H1
              ↓
        ทุกไฟล์อยู่ Common\Files\
        ปลอดภัย ไม่ทับกัน
```

### หลัง test แต่ละรอบ

1. เช็ค **Common\Files\** ว่าไฟล์ออกครบ
2. **คัดลอก CSV** ไปเก็บใน folder backup ทันที
3. ส่งให้ Claude analyze

---

## 📋 ไฟล์ที่อยู่ใน Patch นี้

```
MQL5/
├── Experts/
│   └── KMP_PatternHarvester.mq5         (50.7 KB · main EA)
└── Include/
    ├── KMP_HarvesterLogger.mqh          (15.3 KB · ⭐ PATCHED)
    ├── KMP_Indicators.mqh               (16.5 KB)
    ├── KMP_PatternMetadata.mqh          (32.7 KB · 177 patterns metadata)
    ├── KMP_Patterns.mqh                 (22.2 KB · main pattern dispatch)
    ├── KMP_Structures.mqh               (49.2 KB · data structures)
    └── Patterns/                        (177 patterns split by category)
        ├── KMP_CandleHelpers.mqh
        ├── KMP_PatternsA_Original.mqh   (P1-P20)
        ├── KMP_PatternsB_Candlestick.mqh (P21-P40)
        ├── KMP_PatternsC_SupportRes.mqh  (P41-P50)
        ├── KMP_PatternsD_Structure.mqh   (P51-P60)
        ├── KMP_PatternsE_ChartPatterns.mqh (P61-P70)
        ├── KMP_PatternsF_SmartMoney.mqh  (P71-P80)
        ├── KMP_PatternsG_StatEdge.mqh    (P81-P88)
        ├── KMP_PatternsH_SMCAdvanced.mqh (P89-P97)
        ├── KMP_PatternsI_VolumeWyckoff.mqh (P98-P107)
        ├── KMP_PatternsJ_Harmonic.mqh    (P108-P125)
        ├── KMP_PatternsK_MultiTF.mqh     (P126-P135)
        ├── KMP_PatternsL_Ichimoku.mqh    (P136-P142)
        ├── KMP_PatternsM_ModernSMC.mqh   (P143-P150)
        ├── KMP_PatternsN_Momentum.mqh    (P151-P160)
        ├── KMP_PatternsO_VolumeProfile.mqh (P161-P165)
        ├── KMP_PatternsP_Range.mqh       (P166-P170)
        ├── KMP_PatternsQ_ABCD.mqh        (P171-P174)
        └── KMP_PatternsR_VolRegime.mqh   (P175-P177)
```

**Total: 25 files · ~470 KB**

---

## 🆘 Troubleshooting

### Compile error: "cannot open include file"
- ตรวจว่าไฟล์ Include/ อยู่ครบทุกตัว
- ตรวจ path ใน `#include` (ใช้ `<...>` หรือ `"..."`)

### CSV ไม่ออก
- ดู Journal tab ใน Tester — หา error code
- ตรวจ permission ของ Common Files folder
- ลองรัน MT5 as Administrator

### EA ไม่ขึ้นใน Strategy Tester
- ตรวจว่า compile สำเร็จ (ดูใน Navigator panel — ต้องไม่มี ❌)
- Refresh Navigator (right-click → Refresh)

---

✅ **เสร็จแล้ว — รัน BTC H1 (ตัวสุดท้าย) ได้เลย!**
