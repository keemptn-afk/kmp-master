//+------------------------------------------------------------------+
//|                                       KMP_PatternHarvester.mq5  |
//|                                         Keem & Claude - 2026   |
//|                                                                  |
//|  PATTERN HARVESTER EA — Maximum Data Collection (177 patterns)  |
//|                                                                  |
//|  Mission:                                                        |
//|    "หว่านแห" - cast wide net to gather data on every pattern.    |
//|    NO TRADE BLOCKING. EVERY pattern fires its own order.        |
//|                                                                  |
//|  Phase toggles (independent on/off):                             |
//|    InpEnablePhase1 = P1-P80   (Cat A-F, default ON)              |
//|    InpEnablePhase2 = P81-P125 (Cat G-J, default ON in v6)        |
//|    InpEnablePhase3 = P126-P177 (Cat K-R, default ON in v6)       |
//|                                                                  |
//|  Per-Pattern Mode:                                               |
//|    Each fired pattern → opens its own order                     |
//|    Order tagged with pattern_id (in comment)                    |
//|    Bar with 5 patterns firing → 5 orders open                   |
//|                                                                  |
//|  Data Collected (per trade):                                     |
//|    ✓ Pattern ID, name, category, expected direction              |
//|    ✓ Bar anatomy (OHLC, body, wicks, range)                     |
//|    ✓ Entry quality (where in bar entry happened — wick/body/etc)|
//|    ✓ Path tracking at 1/6/12/24/48/72 hour milestones           |
//|      (post-72h: only MFE/MAE summary, no granular path)         |
//|    ✓ MFE/MAE in dollars and ATR (tracks full hold period)       |
//|    ✓ "Would SL @ 0.5×/1×/2×/3×ATR have hit?" (within hold)      |
//|    ✓ "Would TP @ 1×/2×/3×/5×ATR have hit?" (within hold)        |
//|    ✓ Hours-to-TP for each level                                 |
//|    ✓ All 177 pattern flags + indicators at entry                |
//|                                                                  |
//|  Default time-stop = 168h (7 trading days) — was 72h in v4.     |
//|  Reason: ~24% of EUR H4 trades had MFE peak past 72h in v4.    |
//|                                                                  |
//|  Result: comprehensive CSV ready for analysis                    |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#property version   "3.00"
#property strict

#include <Trade/Trade.mqh>
#include <Trade/PositionInfo.mqh>
#include <Trade/HistoryOrderInfo.mqh>
#include <Trade/DealInfo.mqh>

#include <KMP_Structures.mqh>
#include <KMP_Indicators.mqh>
#include <KMP_Patterns.mqh>
#include <KMP_PatternMetadata.mqh>
#include <KMP_HarvesterLogger.mqh>

//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input group "=== Phase Master Toggles ==="
input bool     InpEnablePhase1     = true;   // Phase 1 (P1-P80, Cat A-F)
input bool     InpEnablePhase2     = true;   // Phase 2 (P81-P125, Cat G-J) — ON for v6 baseline
input bool     InpEnablePhase3     = true;   // Phase 3 (P126-P177, Cat K-R) — ON for v6 baseline

input group "=== Categories Enable (default ALL) ==="
input bool     InpEnableCatA       = true;   // Original (P1-P20)
input bool     InpEnableCatB       = true;   // Candlestick (P21-P40)
input bool     InpEnableCatC       = true;   // S/R & OB (P41-P50)
input bool     InpEnableCatD       = true;   // Structure (P51-P60)
input bool     InpEnableCatE       = true;   // Chart patterns (P61-P70)
input bool     InpEnableCatF       = true;   // SMC (P71-P80)
input bool     InpEnableCatG       = true;   // Stat-Edge (P81-P88)
input bool     InpEnableCatH       = true;   // SMC Advanced (P89-P97)
input bool     InpEnableCatI       = true;   // Volume/Wyckoff (P98-P107)
input bool     InpEnableCatJ       = true;   // Harmonic+Special (P108-P125)
input bool     InpEnableCatK       = true;   // Multi-TF Confluence (P126-P135)
input bool     InpEnableCatL       = true;   // Ichimoku (P136-P142)
input bool     InpEnableCatM       = true;   // Modern SMC (P143-P150)
input bool     InpEnableCatN       = true;   // Momentum+Hidden Div (P151-P160)
input bool     InpEnableCatO       = true;   // Volume Profile (P161-P165)
input bool     InpEnableCatP       = true;   // Range/Reversion (P166-P170)
input bool     InpEnableCatQ       = true;   // ABCD/Three Drives (P171-P174)
input bool     InpEnableCatR       = true;   // Vol Regime (P175-P177)

input group "=== Direction-Agnostic Patterns ==="
input bool     InpAgnosticBoth     = true;   // For dir=0 patterns: open BOTH long & short

input group "=== Pattern Detection — Cat A (Original) ==="
input double   InpWRBMultiplier      = 1.5;    // Wide-Range-Bar threshold (× avg body)
input double   InpWickPctMin         = 30.0;   // Min wick % of range for rejection
input double   InpBodyPctMin         = 50.0;   // Min body % for confirmation
input int      InpMultiRejMin        = 3;      // Min rejections for "multi-rej zone"
input double   InpPinWickPct         = 60.0;   // Pin bar wick % of range

input group "=== Pattern Detection — Cat B (Candlestick) ==="
input double   InpDojiBodyPct        = 5.0;    // Doji: body % below this = doji
input double   InpLongWickPct        = 60.0;   // "Long wick" threshold
input double   InpMarubozuBodyPct    = 95.0;   // Marubozu: body % above this

input group "=== Pattern Detection — Cat C/D (S/R, Structure) ==="
input int      InpDetectLookback     = 50;     // Bars to scan for swings/zones
input double   InpDetectZoneATR      = 0.3;    // Zone proximity (× ATR) — for detection only
input double   InpDetectImpulseATR   = 2.0;    // "Strong move" threshold (× ATR) — for detection only
input int      InpSwingLeft          = 3;      // Swing pivot left bars
input int      InpSwingRight         = 3;      // Swing pivot right bars

input group "=== Pattern Detection — Cat G (Stat-Edge) ==="
input int      InpZScoreLookback     = 20;     // Bars for Z-score mean/std
input double   InpZScoreThreshold    = 2.0;    // |Z| >= threshold to fire
input int      InpORBRangeBars       = 4;      // Opening range size in bars
input double   InpORBBreakATR        = 0.1;    // Break magnitude (× ATR)

input group "=== Pattern Detection — Cat H (SMC Advanced) ==="
input double   InpOTELower           = 0.62;   // OTE Fib lower bound
input double   InpOTEUpper           = 0.79;   // OTE Fib upper bound
input int      InpLondonKZStart      = 9;      // London KZ start (broker hour)
input int      InpLondonKZEnd        = 12;     // London KZ end (broker hour)
input int      InpNYSilverBulletStart= 16;     // NY SB start (broker hour)
input int      InpNYSilverBulletEnd  = 17;     // NY SB end (broker hour)
input int      InpPowerOf3Lookback   = 24;     // Bars for Accumulation range

input group "=== Pattern Detection — Cat I (Volume / Wyckoff / VSA) ==="
input double   InpClimaxVolRatio     = 2.5;    // Tick-vol ratio for climax
input double   InpLowVolRatio        = 0.6;    // Tick-vol ratio for No-Demand/Supply
input double   InpClimaxRangeATR     = 2.0;    // Bar range × ATR for climax
input int      InpWyckoffRangeLB     = 30;     // Trading range lookback
input double   InpWyckoffRangeMaxATR = 3.0;    // Trading range max width × ATR
input int      InpCVDDivLookback     = 30;     // CVD-div swing search window

input group "=== Pattern Detection — Cat J (Harmonic + Specialized) ==="
input int      InpHarmonicSwingLB    = 80;     // Bars to scan for X-A-B-C swings
input int      InpAsianStart         = 0;      // Asian session start (broker hour)
input int      InpAsianEnd           = 8;      // Asian session end (broker hour)
input int      InpLondonStart        = 9;      // London window start (broker hour)
input int      InpLondonEnd          = 13;     // London window end (broker hour)

input group "=== Pattern Detection — Cat M (Modern SMC) ==="
input int      InpM_SwingLB         = 20;     // Swing lookback for inducement
input int      InpM_ExternalLB      = 50;     // External liquidity lookback
input int      InpM_DonchianPeriod  = 20;     // Turtle Soup Donchian period
input double   InpM_VolClimax       = 2.0;    // Stop-Run min volume_ratio

input group "=== Pattern Detection — Cat N (Momentum + Hidden Div) ==="
input int      InpN_SwingLB         = 50;     // Swing lookback for trendline
input int      InpN_DivLB           = 30;     // Divergence lookback

input group "=== Pattern Detection — Cat O (Volume Profile) ==="
input int      InpO_ProfileBars     = 24;     // Bars to build profile (24 = 1 day on H1)

input group "=== Pattern Detection — Cat P (Range/Reversion) ==="
input int      InpP_RangeLB         = 50;     // Range lookback for mid bounce

input group "=== Pattern Detection — Cat Q (ABCD/Three Drives) ==="
input int      InpQ_SwingLB         = 50;     // Swing lookback for ABCD legs

input group "=== Trade Settings ==="
input double   InpRiskPct            = 0.01;   // % balance to risk per trade (small for testing)
input int      InpTimeStopHours      = 240;    // Close all after N trading hours (240 = 10 days = 2 weeks)
enum ENUM_WEEKEND_MODE
{
   WEEKEND_AUTO   = 0,  // AUTO: detect from symbol session info (recommended)
   WEEKEND_SKIP   = 1,  // FORCE skip Sat-Sun (force trading-hour count)
   WEEKEND_COUNT  = 2   // FORCE count Sat-Sun (force calendar-hour count)
};

input ENUM_WEEKEND_MODE InpWeekendMode = WEEKEND_AUTO; // Weekend handling for time-stop (AUTO = correct per symbol)
input bool     InpForceMinLot        = true;   // Use broker min_lot if calc < min (no order blocking)
input double   InpMaxLot             = 1.0;    // Cap on lot size
input ulong    InpMagic              = 70707070;

input group "=== Emergency Protection (kicks in only if needed) ==="
input bool     InpEmergencyClose     = true;   // Close ALL if equity drops dangerously
input double   InpMaxLossPct         = 50.0;   // Drawdown % threshold for emergency close

//+------------------------------------------------------------------+
//| Tracked Position with full HarvestRecord                        |
//|                                                                  |
//|  MAX_TRACKED_POSITIONS = 10,000                                  |
//|  (~10MB memory, plenty for 4-month backtest at any TF)          |
//|  Real-world peak in 4 months: ~100-1500 concurrent positions    |
//+------------------------------------------------------------------+
#define MAX_TRACKED_POSITIONS 10000

CTrade                  g_trade;
CPositionInfo           g_position;
CIndicatorManager       g_Indicators;
CMasterPatternDetector  g_MasterDetector;
CHarvesterLogger        g_Logger;

HarvestRecord  g_tracked[MAX_TRACKED_POSITIONS];
int            g_tracked_count = 0;
int            g_peak_concurrent = 0;     // diagnostic: peak concurrent positions
int            g_total_orders_opened = 0; // diagnostic: lifetime total orders
int            g_total_orders_failed = 0; // diagnostic: lifetime failures

// Detailed counters per category (for debugging "why so few trades")
int            g_bars_processed = 0;
int            g_bars_with_signal = 0;
int            g_patterns_fired_total = 0;
int            g_patterns_per_cat[18] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; // A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R
int            g_orders_attempted = 0;
int            g_lot_zero_count = 0;
int            g_slot_full_count = 0;

datetime          g_last_bar_time = 0;
IndicatorSnapshot g_prev_snap;
bool              g_prev_snap_valid = false;

//+------------------------------------------------------------------+
//| Build log filename                                              |
//+------------------------------------------------------------------+
string BuildLogFilename()
{
   string sym = Symbol();
   StringReplace(sym, ".", "_");
   string tf = EnumToString(_Period);
   StringReplace(tf, "PERIOD_", "");
   return "KMP_Harvest_" + sym + "_" + tf + ".csv";
}

//+------------------------------------------------------------------+
//| Calculate expire time (skip weekends)                           |
//+------------------------------------------------------------------+
// Resolved at OnInit based on symbol auto-detection or InpWeekendMode override
bool g_skip_weekend = false;

//+------------------------------------------------------------------+
//| Detect if symbol has trading sessions on Saturday/Sunday        |
//+------------------------------------------------------------------+
bool SymbolTradesOnWeekend(string sym)
{
   datetime from, to;
   for(int sess = 0; sess < 5; sess++)
   {
      if(SymbolInfoSessionTrade(sym, SATURDAY, sess, from, to)) return true;
      if(SymbolInfoSessionTrade(sym, SUNDAY,   sess, from, to)) return true;
   }
   return false;
}

datetime CalculateExpireTime(datetime open_time, int hours)
{
   if(!g_skip_weekend)
      return open_time + hours * 3600;
   
   datetime result = open_time;
   int hours_remaining = hours;
   
   while(hours_remaining > 0)
   {
      result += 3600;
      MqlDateTime dt;
      TimeToStruct(result, dt);
      if(dt.day_of_week >= 1 && dt.day_of_week <= 5)
         hours_remaining--;
   }
   return result;
}

//+------------------------------------------------------------------+
//| Calculate lot                                                   |
//+------------------------------------------------------------------+
double CalculateLot(double risk_pct, double sl_distance_price)
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double tick_value = SymbolInfoDouble(Symbol(), SYMBOL_TRADE_TICK_VALUE);
   double tick_size  = SymbolInfoDouble(Symbol(), SYMBOL_TRADE_TICK_SIZE);
   double step    = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_STEP);
   double min_lot = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MIN);
   double max_lot = SymbolInfoDouble(Symbol(), SYMBOL_VOLUME_MAX);
   
   if(tick_value <= 0 || tick_size <= 0)
      return InpForceMinLot ? min_lot : 0;
   
   double lot = min_lot;  // safe default
   
   if(sl_distance_price > 0)
   {
      double risk_amount = balance * risk_pct / 100.0;
      double sl_distance_ticks = sl_distance_price / tick_size;
      double pnl_per_lot_at_sl = sl_distance_ticks * tick_value;
      
      if(pnl_per_lot_at_sl > 0)
         lot = risk_amount / pnl_per_lot_at_sl;
   }
   
   if(step > 0) lot = MathFloor(lot / step) * step;
   
   if(lot < min_lot)
      lot = InpForceMinLot ? min_lot : 0;  // NEVER block - use min if forced
   
   if(lot > max_lot) lot = max_lot;
   if(lot > InpMaxLot) lot = InpMaxLot;
   
   return NormalizeDouble(lot, 2);
}

//+------------------------------------------------------------------+
//| Find tracking slot                                              |
//+------------------------------------------------------------------+
int FindTrackedSlot(ulong ticket)
{
   for(int i = 0; i < g_tracked_count; i++)
      if(g_tracked[i].active && g_tracked[i].ticket == ticket)
         return i;
   return -1;
}

int FindFreeSlot()
{
   for(int i = 0; i < g_tracked_count; i++)
      if(!g_tracked[i].active)
         return i;
   if(g_tracked_count < MAX_TRACKED_POSITIONS)
      return g_tracked_count++;
   return -1;
}

int CountActiveSlots()
{
   int n = 0;
   for(int i = 0; i < g_tracked_count; i++)
      if(g_tracked[i].active) n++;
   if(n > g_peak_concurrent) g_peak_concurrent = n;
   return n;
}

//+------------------------------------------------------------------+
//| Check if pattern's category is enabled (gated by Phase toggle)  |
//+------------------------------------------------------------------+
bool IsCategoryEnabled(string cat)
{
   // Phase 1 categories (A-F) require InpEnablePhase1 AND the cat toggle
   if(cat == "A") return InpEnablePhase1 && InpEnableCatA;
   if(cat == "B") return InpEnablePhase1 && InpEnableCatB;
   if(cat == "C") return InpEnablePhase1 && InpEnableCatC;
   if(cat == "D") return InpEnablePhase1 && InpEnableCatD;
   if(cat == "E") return InpEnablePhase1 && InpEnableCatE;
   if(cat == "F") return InpEnablePhase1 && InpEnableCatF;
   // Phase 2 categories (G-J) require InpEnablePhase2 AND the cat toggle
   if(cat == "G") return InpEnablePhase2 && InpEnableCatG;
   if(cat == "H") return InpEnablePhase2 && InpEnableCatH;
   if(cat == "I") return InpEnablePhase2 && InpEnableCatI;
   if(cat == "J") return InpEnablePhase2 && InpEnableCatJ;
   // Phase 3 categories (K-R) require InpEnablePhase3 AND the cat toggle
   if(cat == "K") return InpEnablePhase3 && InpEnableCatK;
   if(cat == "L") return InpEnablePhase3 && InpEnableCatL;
   if(cat == "M") return InpEnablePhase3 && InpEnableCatM;
   if(cat == "N") return InpEnablePhase3 && InpEnableCatN;
   if(cat == "O") return InpEnablePhase3 && InpEnableCatO;
   if(cat == "P") return InpEnablePhase3 && InpEnableCatP;
   if(cat == "Q") return InpEnablePhase3 && InpEnableCatQ;
   if(cat == "R") return InpEnablePhase3 && InpEnableCatR;
   return false;
}

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("==========================================================");
   Print("KMP PATTERN HARVESTER EA — Max Data Collection (177 P)");
   Print("Symbol: ", Symbol(), " | TF: ", EnumToString(_Period));
   Print("Mode: PER-PATTERN (1 pattern fired = 1 order)");
   Print("Phase 1 (P1-P80):  ", InpEnablePhase1 ? "ON" : "OFF");
   Print("Phase 2 (P81-P125):", InpEnablePhase2 ? "ON" : "OFF");
   Print("Phase 3 (P126-P177):", InpEnablePhase3 ? "ON" : "OFF");
   Print("Cats P1: ",
         InpEnableCatA ? "A " : "",
         InpEnableCatB ? "B " : "",
         InpEnableCatC ? "C " : "",
         InpEnableCatD ? "D " : "",
         InpEnableCatE ? "E " : "",
         InpEnableCatF ? "F" : "");
   Print("Cats P2: ",
         InpEnableCatG ? "G " : "",
         InpEnableCatH ? "H " : "",
         InpEnableCatI ? "I " : "",
         InpEnableCatJ ? "J" : "");
   Print("Risk: ", InpRiskPct, "% | Time-stop: ", InpTimeStopHours, "h");
   Print("Mode: NO SL, NO TP — time-stop = ", InpTimeStopHours, "h");
   
   // Resolve weekend handling per symbol
   bool sym_has_weekend = SymbolTradesOnWeekend(Symbol());
   string mode_label = "";
   switch(InpWeekendMode)
   {
      case WEEKEND_AUTO:
         g_skip_weekend = !sym_has_weekend;
         mode_label = StringFormat("AUTO (symbol weekend=%s → skip=%s)",
                                   sym_has_weekend ? "YES" : "NO",
                                   g_skip_weekend  ? "YES" : "NO");
         break;
      case WEEKEND_SKIP:
         g_skip_weekend = true;
         mode_label = "FORCE SKIP (count Mon-Fri only)";
         break;
      case WEEKEND_COUNT:
         g_skip_weekend = false;
         mode_label = "FORCE COUNT (count all calendar hours)";
         break;
   }
   Print("Weekend mode: ", mode_label);
   Print("Time-stop counter: ", g_skip_weekend
            ? "Mon-Fri hours only (skip Sat-Sun)"
            : "Calendar hours (include Sat-Sun)");
   
   Print("Force min_lot: ", InpForceMinLot ? "YES (no order blocking)" : "NO");
   Print("Max positions: ", MAX_TRACKED_POSITIONS);
   Print("==========================================================");

   // Init indicators
   if(!g_Indicators.Init(Symbol(), _Period))
   {
      Print("ERROR: Indicator init failed");
      return INIT_FAILED;
   }

   // Init detector
   g_MasterDetector.Init(Symbol(), _Period);
   g_MasterDetector.SetCatAParams(InpWRBMultiplier, InpWickPctMin, InpBodyPctMin,
                                    InpMultiRejMin, InpPinWickPct);
   g_MasterDetector.SetCatBParams(InpDojiBodyPct, InpLongWickPct, InpMarubozuBodyPct);
   g_MasterDetector.SetCatCParams(InpDetectLookback, InpDetectZoneATR, InpDetectImpulseATR);
   g_MasterDetector.SetCatDParams(InpDetectLookback, InpSwingLeft, InpSwingRight, 0.2);
   // Phase 2 detectors — params are no-ops if Phase 2 is disabled
   g_MasterDetector.SetCatGParams(InpZScoreLookback, InpZScoreThreshold,
                                  InpORBRangeBars, InpORBBreakATR);
   g_MasterDetector.SetCatHParams(InpDetectLookback, InpOTELower, InpOTEUpper,
                                  InpLondonKZStart, InpLondonKZEnd,
                                  InpNYSilverBulletStart, InpNYSilverBulletEnd,
                                  InpPowerOf3Lookback);
   g_MasterDetector.SetCatIParams(InpDetectLookback, InpClimaxVolRatio, InpLowVolRatio,
                                  InpClimaxRangeATR, InpWyckoffRangeLB,
                                  InpWyckoffRangeMaxATR, InpCVDDivLookback);
   g_MasterDetector.SetCatJParams(InpHarmonicSwingLB, InpSwingLeft, InpSwingRight,
                                  InpAsianStart, InpAsianEnd,
                                  InpLondonStart, InpLondonEnd);
   // Phase 3 detectors — params are no-ops if Phase 3 is disabled
   g_MasterDetector.SetCatMParams(InpM_SwingLB, InpM_ExternalLB,
                                  InpM_DonchianPeriod, InpM_VolClimax);
   g_MasterDetector.SetCatNParams(InpN_SwingLB, InpN_DivLB);
   g_MasterDetector.SetCatOParams(InpO_ProfileBars);
   g_MasterDetector.SetCatPParams(InpP_RangeLB);
   g_MasterDetector.SetCatQParams(InpQ_SwingLB);
   // Cat K (Multi-TF), L (Ichimoku), R (Vol Regime) have no tunable params
   
   // Init trade
   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(50);
   g_trade.SetTypeFilling(ORDER_FILLING_IOC);
   
   // Reset tracking
   for(int i = 0; i < MAX_TRACKED_POSITIONS; i++)
      g_tracked[i].active = false;
   g_tracked_count = 0;
   
   // Open log
   string logfile = BuildLogFilename();
   if(!g_Logger.Open(logfile))
      Print("WARN: Cannot open log");
   else
      Print("Log: ", logfile);
   
   g_last_bar_time = 0;
   g_prev_snap_valid = false;
   
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| OnDeinit                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   // Force close all tracked positions
   for(int i = 0; i < g_tracked_count; i++)
   {
      if(g_tracked[i].active && g_tracked[i].ticket > 0)
         g_trade.PositionClose(g_tracked[i].ticket);
   }

   // Safety: close any orphan positions with our magic that weren't tracked
   // (rare — happens only if position_id resolution failed at open time).
   int orphan_closed = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(!g_position.SelectByIndex(i)) continue;
      if(g_position.Symbol() != Symbol()) continue;
      if(g_position.Magic() != InpMagic) continue;
      ulong t = g_position.Ticket();
      if(FindTrackedSlot(t) >= 0) continue;  // already handled above
      g_trade.PositionClose(t);
      orphan_closed++;
   }
   if(orphan_closed > 0)
      Print("Closed ", orphan_closed, " orphan positions (magic match, not tracked)");

   // CRITICAL: write final records for any active positions that haven't been
   // captured by OnTradeTransaction yet (backtest end / EA removal can race
   // with the close confirmation, causing data loss). We synthesize exit
   // values from current market price + MFE/MAE state.
   datetime now = TimeCurrent();
   int forced_writes = 0;
   for(int i = 0; i < g_tracked_count; i++)
   {
      if(!g_tracked[i].active) continue;
      if(g_tracked[i].close_time > 0) continue;  // already filled by OnTradeTransaction

      double current = (g_tracked[i].trade_direction == 1)
         ? SymbolInfoDouble(Symbol(), SYMBOL_BID)
         : SymbolInfoDouble(Symbol(), SYMBOL_ASK);

      g_tracked[i].close_time = now;
      g_tracked[i].exit_price = current;
      g_tracked[i].exit_reason = "BACKTEST_END";
      g_tracked[i].hours_held = (int)((now - g_tracked[i].open_time) / 3600);

      double dir_move;
      if(g_tracked[i].trade_direction == 1)
         dir_move = current - g_tracked[i].entry_price;
      else
         dir_move = g_tracked[i].entry_price - current;
      if(g_tracked[i].entry_atr > 0)
         g_tracked[i].pnl_atr = dir_move / g_tracked[i].entry_atr;

      // Approximate dollar PnL using direction + lot + tick value
      double tick_value = SymbolInfoDouble(Symbol(), SYMBOL_TRADE_TICK_VALUE);
      double tick_size = SymbolInfoDouble(Symbol(), SYMBOL_TRADE_TICK_SIZE);
      if(tick_size > 0)
         g_tracked[i].pnl_dollars = (dir_move / tick_size) * tick_value * g_tracked[i].lot;
      g_tracked[i].direction_correct = g_tracked[i].pnl_dollars > 0;

      // Copy path snapshot pnl into legacy pnl_at_* fields (for any consumers)
      g_tracked[i].pnl_at_1h  = g_tracked[i].path_1h.pnl_atr;
      g_tracked[i].pnl_at_6h  = g_tracked[i].path_6h.pnl_atr;
      g_tracked[i].pnl_at_12h = g_tracked[i].path_12h.pnl_atr;
      g_tracked[i].pnl_at_24h = g_tracked[i].path_24h.pnl_atr;
      g_tracked[i].pnl_at_48h = g_tracked[i].path_48h.pnl_atr;
      g_tracked[i].pnl_at_72h = g_tracked[i].path_72h.pnl_atr;

      g_Logger.WriteRecord(g_tracked[i]);
      g_tracked[i].active = false;
      forced_writes++;
   }
   if(forced_writes > 0)
      Print("Force-wrote ", forced_writes, " active positions at backtest end (BACKTEST_END exit)");

   g_Logger.Close();
   g_Indicators.Deinit();
   
   Print("==========================================================");
   Print("HARVESTER FINAL STATS");
   Print("==========================================================");
   Print("Bars processed:         ", g_bars_processed);
   Print("Bars with signals:      ", g_bars_with_signal,
         " (", (g_bars_processed > 0 ? g_bars_with_signal * 100.0 / g_bars_processed : 0), "%)");
   Print("Total patterns fired:   ", g_patterns_fired_total);
   Print("  Cat A (P1-P20):       ", g_patterns_per_cat[0]);
   Print("  Cat B (P21-P40):      ", g_patterns_per_cat[1]);
   Print("  Cat C (P41-P50):      ", g_patterns_per_cat[2]);
   Print("  Cat D (P51-P60):      ", g_patterns_per_cat[3]);
   Print("  Cat E (P61-P70):      ", g_patterns_per_cat[4]);
   Print("  Cat F (P71-P80):      ", g_patterns_per_cat[5]);
   Print("  Cat G (P81-P88):      ", g_patterns_per_cat[6]);
   Print("  Cat H (P89-P97):      ", g_patterns_per_cat[7]);
   Print("  Cat I (P98-P107):     ", g_patterns_per_cat[8]);
   Print("  Cat J (P108-P125):    ", g_patterns_per_cat[9]);
   Print("  Cat K (P126-P135):    ", g_patterns_per_cat[10]);
   Print("  Cat L (P136-P142):    ", g_patterns_per_cat[11]);
   Print("  Cat M (P143-P150):    ", g_patterns_per_cat[12]);
   Print("  Cat N (P151-P160):    ", g_patterns_per_cat[13]);
   Print("  Cat O (P161-P165):    ", g_patterns_per_cat[14]);
   Print("  Cat P (P166-P170):    ", g_patterns_per_cat[15]);
   Print("  Cat Q (P171-P174):    ", g_patterns_per_cat[16]);
   Print("  Cat R (P175-P177):    ", g_patterns_per_cat[17]);
   Print("---");
   Print("Orders attempted:       ", g_orders_attempted);
   Print("Orders opened (success): ", g_total_orders_opened);
   Print("Orders failed (broker):  ", g_total_orders_failed);
   Print("  → Lot=0 fails:         ", g_lot_zero_count);
   Print("  → Slot full:           ", g_slot_full_count);
   Print("---");
   Print("Peak concurrent:        ", g_peak_concurrent, " of ", MAX_TRACKED_POSITIONS);
   if(g_orders_attempted > 0)
      Print("Success rate:           ", (g_total_orders_opened * 100.0 / g_orders_attempted), "%");
   if(g_peak_concurrent >= MAX_TRACKED_POSITIONS - 100)
      Print("⚠️ WARNING: peak near MAX_TRACKED_POSITIONS — may have lost orders!");
   Print("==========================================================");
   Print("Harvester deinit. Reason=", reason);
}

//+------------------------------------------------------------------+
//| OnTick                                                           |
//+------------------------------------------------------------------+
void OnTick()
{
   datetime now = TimeCurrent();
   
   // Emergency check
   if(InpEmergencyClose)
   {
      double balance = AccountInfoDouble(ACCOUNT_BALANCE);
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);
      if(balance > 0)
      {
         double dd_pct = (equity - balance) / balance * 100;
         if(dd_pct <= -InpMaxLossPct)
         {
            Print("EMERGENCY: dd=", dd_pct, "% — closing all");
            for(int i = 0; i < g_tracked_count; i++)
               if(g_tracked[i].active && g_tracked[i].ticket > 0)
                  g_trade.PositionClose(g_tracked[i].ticket);
         }
      }
   }
   
   UpdateActivePositions(now);
   
   // New bar
   datetime curr_bar_time = iTime(Symbol(), _Period, 0);
   if(curr_bar_time == g_last_bar_time) return;
   
   if(g_last_bar_time == 0)
   {
      g_last_bar_time = curr_bar_time;
      return;
   }
   
   ProcessClosedBar(1);
   g_last_bar_time = curr_bar_time;
}

//+------------------------------------------------------------------+
//| Update active positions: MFE/MAE, path snapshots, time-stop     |
//+------------------------------------------------------------------+
void UpdateActivePositions(datetime now)
{
   for(int i = 0; i < g_tracked_count; i++)
   {
      if(!g_tracked[i].active) continue;
      if(g_tracked[i].ticket == 0) continue;
      if(!g_position.SelectByTicket(g_tracked[i].ticket)) continue;
      
      double current = (g_tracked[i].trade_direction == 1)
         ? SymbolInfoDouble(Symbol(), SYMBOL_BID)
         : SymbolInfoDouble(Symbol(), SYMBOL_ASK);
      
      double entry = g_tracked[i].entry_price;
      double atr = g_tracked[i].entry_atr;
      
      // Update MFE/MAE
      if(g_tracked[i].trade_direction == 1)
      {
         if(current > g_tracked[i].max_favorable)
         {
            g_tracked[i].max_favorable = current;
            g_tracked[i].mfe_time = now;
            g_tracked[i].hours_to_mfe = (int)((now - g_tracked[i].open_time) / 3600);
         }
         if(current < g_tracked[i].max_adverse || g_tracked[i].max_adverse == 0)
         {
            g_tracked[i].max_adverse = current;
            g_tracked[i].mae_time = now;
            g_tracked[i].hours_to_mae = (int)((now - g_tracked[i].open_time) / 3600);
         }
         if(atr > 0)
         {
            g_tracked[i].max_favorable_atr = (g_tracked[i].max_favorable - entry) / atr;
            g_tracked[i].max_adverse_atr = (entry - g_tracked[i].max_adverse) / atr;
         }
      }
      else if(g_tracked[i].trade_direction == -1)
      {
         if(current < g_tracked[i].max_favorable || g_tracked[i].max_favorable == 0)
         {
            g_tracked[i].max_favorable = current;
            g_tracked[i].mfe_time = now;
            g_tracked[i].hours_to_mfe = (int)((now - g_tracked[i].open_time) / 3600);
         }
         if(current > g_tracked[i].max_adverse)
         {
            g_tracked[i].max_adverse = current;
            g_tracked[i].mae_time = now;
            g_tracked[i].hours_to_mae = (int)((now - g_tracked[i].open_time) / 3600);
         }
         if(atr > 0)
         {
            g_tracked[i].max_favorable_atr = (entry - g_tracked[i].max_favorable) / atr;
            g_tracked[i].max_adverse_atr = (g_tracked[i].max_adverse - entry) / atr;
         }
      }
      
      // Capture path snapshots at milestones
      int hours_held = (int)((now - g_tracked[i].open_time) / 3600);
      double dir_pnl_atr = 0;
      if(atr > 0)
      {
         if(g_tracked[i].trade_direction == 1)
            dir_pnl_atr = (current - entry) / atr;
         else
            dir_pnl_atr = (entry - current) / atr;
      }
      
      if(!g_tracked[i].path_1h.captured && hours_held >= 1)
      {
         g_tracked[i].path_1h.captured = true;
         g_tracked[i].path_1h.hour_offset = 1;
         g_tracked[i].path_1h.price = current;
         g_tracked[i].path_1h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_6h.captured && hours_held >= 6)
      {
         g_tracked[i].path_6h.captured = true;
         g_tracked[i].path_6h.hour_offset = 6;
         g_tracked[i].path_6h.price = current;
         g_tracked[i].path_6h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_12h.captured && hours_held >= 12)
      {
         g_tracked[i].path_12h.captured = true;
         g_tracked[i].path_12h.hour_offset = 12;
         g_tracked[i].path_12h.price = current;
         g_tracked[i].path_12h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_24h.captured && hours_held >= 24)
      {
         g_tracked[i].path_24h.captured = true;
         g_tracked[i].path_24h.hour_offset = 24;
         g_tracked[i].path_24h.price = current;
         g_tracked[i].path_24h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_48h.captured && hours_held >= 48)
      {
         g_tracked[i].path_48h.captured = true;
         g_tracked[i].path_48h.hour_offset = 48;
         g_tracked[i].path_48h.price = current;
         g_tracked[i].path_48h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_72h.captured && hours_held >= 72)
      {
         g_tracked[i].path_72h.captured = true;
         g_tracked[i].path_72h.hour_offset = 72;
         g_tracked[i].path_72h.price = current;
         g_tracked[i].path_72h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_120h.captured && hours_held >= 120)
      {
         g_tracked[i].path_120h.captured = true;
         g_tracked[i].path_120h.hour_offset = 120;
         g_tracked[i].path_120h.price = current;
         g_tracked[i].path_120h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_168h.captured && hours_held >= 168)
      {
         g_tracked[i].path_168h.captured = true;
         g_tracked[i].path_168h.hour_offset = 168;
         g_tracked[i].path_168h.price = current;
         g_tracked[i].path_168h.pnl_atr = dir_pnl_atr;
      }
      if(!g_tracked[i].path_240h.captured && hours_held >= 240)
      {
         g_tracked[i].path_240h.captured = true;
         g_tracked[i].path_240h.hour_offset = 240;
         g_tracked[i].path_240h.price = current;
         g_tracked[i].path_240h.pnl_atr = dir_pnl_atr;
      }
      
      // Track virtual SL/TP hits (for analysis only — don't actually close)
      double mfe_atr = g_tracked[i].max_favorable_atr;
      double mae_atr = g_tracked[i].max_adverse_atr;
      
      if(mae_atr >= 0.5) g_tracked[i].sl_05_hit = true;
      if(mae_atr >= 1.0) g_tracked[i].sl_10_hit = true;
      if(mae_atr >= 2.0) g_tracked[i].sl_20_hit = true;
      if(mae_atr >= 3.0) g_tracked[i].sl_30_hit = true;
      
      if(mfe_atr >= 1.0 && !g_tracked[i].tp_10_hit)
      { g_tracked[i].tp_10_hit = true; g_tracked[i].tp_10_time = now; }
      if(mfe_atr >= 2.0 && !g_tracked[i].tp_20_hit)
      { g_tracked[i].tp_20_hit = true; g_tracked[i].tp_20_time = now; }
      if(mfe_atr >= 3.0 && !g_tracked[i].tp_30_hit)
      { g_tracked[i].tp_30_hit = true; g_tracked[i].tp_30_time = now; }
      if(mfe_atr >= 5.0 && !g_tracked[i].tp_50_hit)
      { g_tracked[i].tp_50_hit = true; g_tracked[i].tp_50_time = now; }
      
      // Time-stop
      if(now >= g_tracked[i].expire_time)
         g_trade.PositionClose(g_tracked[i].ticket);
   }
}

//+------------------------------------------------------------------+
//| OnTradeTransaction                                               |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                          const MqlTradeRequest &request,
                          const MqlTradeResult &result)
{
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
   if(!HistoryDealSelect(trans.deal)) return;
   
   ulong deal_magic = HistoryDealGetInteger(trans.deal, DEAL_MAGIC);
   if(deal_magic != InpMagic) return;
   
   string deal_symbol = HistoryDealGetString(trans.deal, DEAL_SYMBOL);
   if(deal_symbol != Symbol()) return;
   
   long deal_entry_type = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   
   // === HANDLE OPENING DEAL — capture actual fill price for slippage analysis ===
   if(deal_entry_type == DEAL_ENTRY_IN)
   {
      ulong open_position_id = HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);
      int open_slot = FindTrackedSlot(open_position_id);
      if(open_slot >= 0)
      {
         // Update entry_price to ACTUAL broker fill (intended_entry_price stays as requested)
         double actual_fill = HistoryDealGetDouble(trans.deal, DEAL_PRICE);
         g_tracked[open_slot].entry_price = actual_fill;
         // slippage in CSV = entry_price - intended_entry_price (computed in analysis)
      }
      return; // Don't process opening deal beyond this
   }
   
   if(deal_entry_type != DEAL_ENTRY_OUT) return;
   
   ulong position_id = HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);
   int slot = FindTrackedSlot(position_id);
   if(slot < 0) return;
   
   double deal_price = HistoryDealGetDouble(trans.deal, DEAL_PRICE);
   double deal_profit = HistoryDealGetDouble(trans.deal, DEAL_PROFIT);
   double deal_swap = HistoryDealGetDouble(trans.deal, DEAL_SWAP);
   double deal_commission = HistoryDealGetDouble(trans.deal, DEAL_COMMISSION);
   double total_pnl = deal_profit + deal_swap + deal_commission;
   datetime deal_time = (datetime)HistoryDealGetInteger(trans.deal, DEAL_TIME);
   long deal_reason = HistoryDealGetInteger(trans.deal, DEAL_REASON);
   
   // Determine close reason
   string close_reason = "EXPERT";
   if(deal_reason == DEAL_REASON_TP)      close_reason = "TP_HIT";
   else if(deal_reason == DEAL_REASON_SL) close_reason = "SL_HIT";
   else if(deal_reason == DEAL_REASON_EXPERT) close_reason = "TIME_STOP";
   else close_reason = "REASON_" + IntegerToString(deal_reason);
   
   // Fill in close info
   g_tracked[slot].close_time = deal_time;
   g_tracked[slot].exit_price = deal_price;
   g_tracked[slot].spread_at_exit_pts = (int)SymbolInfoInteger(Symbol(), SYMBOL_SPREAD);
   g_tracked[slot].pnl_dollars = total_pnl;
   g_tracked[slot].exit_reason = close_reason;
   g_tracked[slot].hours_held = (int)((deal_time - g_tracked[slot].open_time) / 3600);
   g_tracked[slot].direction_correct = total_pnl > 0;
   
   if(g_tracked[slot].entry_atr > 0)
   {
      double dir_move;
      if(g_tracked[slot].trade_direction == 1)
         dir_move = deal_price - g_tracked[slot].entry_price;
      else
         dir_move = g_tracked[slot].entry_price - deal_price;
      g_tracked[slot].pnl_atr = dir_move / g_tracked[slot].entry_atr;
   }
   
   // Compute pnl_at_Xh from path snapshots
   g_tracked[slot].pnl_at_1h = g_tracked[slot].path_1h.pnl_atr;
   g_tracked[slot].pnl_at_6h = g_tracked[slot].path_6h.pnl_atr;
   g_tracked[slot].pnl_at_12h = g_tracked[slot].path_12h.pnl_atr;
   g_tracked[slot].pnl_at_24h = g_tracked[slot].path_24h.pnl_atr;
   g_tracked[slot].pnl_at_48h = g_tracked[slot].path_48h.pnl_atr;
   g_tracked[slot].pnl_at_72h = g_tracked[slot].path_72h.pnl_atr;
   
   // Write to log
   g_Logger.WriteRecord(g_tracked[slot]);
   
   // Free slot
   g_tracked[slot].active = false;
   g_tracked[slot].ticket = 0;
}

//+------------------------------------------------------------------+
//| Open one order for one pattern                                  |
//+------------------------------------------------------------------+
bool OpenForPattern(int pattern_id, int direction, const PatternFlags &all_flags,
                     const IndicatorSnapshot &snap)
{
   PatternMeta meta = CPatternMeta::Get(pattern_id);
   
   double entry_price = (direction == 1) 
      ? SymbolInfoDouble(Symbol(), SYMBOL_ASK)
      : SymbolInfoDouble(Symbol(), SYMBOL_BID);
   
   // NO SL, NO TP — pure direction test, time-stop closes positions
   double sl = 0;
   double tp = 0;
   double sl_dist = snap.atr_14 * 5;  // notional distance for lot sizing (5×ATR)
   
   double lot = CalculateLot(InpRiskPct, sl_dist);
   if(lot <= 0)
   {
      g_lot_zero_count++;
      if(g_lot_zero_count <= 5)
         Print("DEBUG: Lot=0 for P", pattern_id, " | balance=", AccountInfoDouble(ACCOUNT_BALANCE),
               " atr=", snap.atr_14, " sl_dist=", sl_dist);
      return false;
   }
   
   int slot = FindFreeSlot();
   if(slot < 0)
   {
      g_slot_full_count++;
      if(g_slot_full_count <= 3)
         Print("WARN: All ", MAX_TRACKED_POSITIONS, " slots used");
      return false;
   }
   
   string comment = "P" + IntegerToString(pattern_id) + " " + meta.name;
   if(StringLen(comment) > 31) comment = StringSubstr(comment, 0, 31);
   
   double balance_before = AccountInfoDouble(ACCOUNT_BALANCE);
   
   bool ok;
   if(direction == 1)
      ok = g_trade.Buy(lot, Symbol(), entry_price, sl, tp, comment);
   else
      ok = g_trade.Sell(lot, Symbol(), entry_price, sl, tp, comment);
   
   if(!ok)
   {
      g_total_orders_failed++;
      Print("Order failed for P", pattern_id, ": ",
            g_trade.ResultRetcode(), " - ", g_trade.ResultRetcodeDescription());
      return false;
   }
   
   g_total_orders_opened++;
   
   ulong deal_ticket = g_trade.ResultDeal();
   ulong position_id = 0;
   if(HistoryDealSelect(deal_ticket))
      position_id = HistoryDealGetInteger(deal_ticket, DEAL_POSITION_ID);

   // Fallback: if HistoryDealSelect failed (rare in backtest), find newest
   // position that isn't already in our tracked list. This prevents
   // accidentally claiming an existing tracked position.
   if(position_id == 0)
   {
      for(int i = PositionsTotal() - 1; i >= 0; i--)
      {
         if(g_position.SelectByIndex(i))
         {
            if(g_position.Symbol() == Symbol() && g_position.Magic() == InpMagic)
            {
               ulong cand = g_position.Ticket();
               // Skip if already tracked
               if(FindTrackedSlot(cand) >= 0) continue;
               position_id = cand;
               break;
            }
         }
      }
   }

   if(position_id == 0)
   {
      // Could not link the opened order to a position — log loudly. The
      // position is open but untracked; OnDeinit will close orphan positions.
      Print("ERROR: Order opened for P", pattern_id, " but position_id=0 (untracked!) ",
            "deal_ticket=", deal_ticket);
      return false;
   }
   
   datetime now = TimeCurrent();
   datetime expire = CalculateExpireTime(now, InpTimeStopHours);
   
   // Capture bar anatomy
   double bar_o = iOpen(Symbol(), _Period, 1);
   double bar_h = iHigh(Symbol(), _Period, 1);
   double bar_l = iLow(Symbol(), _Period, 1);
   double bar_c = iClose(Symbol(), _Period, 1);
   double bar_body = MathAbs(bar_c - bar_o);
   double bar_range = bar_h - bar_l;
   double bar_upper_wick = bar_h - MathMax(bar_o, bar_c);
   double bar_lower_wick = MathMin(bar_o, bar_c) - bar_l;
   
   // Entry quality analysis
   double entry_vs_range_pct = 0;
   double entry_vs_body_pct = 0;
   if(bar_range > 0)
      entry_vs_range_pct = (entry_price - bar_l) / bar_range * 100;
   double body_low = MathMin(bar_o, bar_c);
   double body_high = MathMax(bar_o, bar_c);
   if(bar_body > 0)
      entry_vs_body_pct = (entry_price - body_low) / bar_body * 100;
   
   double entry_dist_high_atr = 0;
   double entry_dist_low_atr = 0;
   if(snap.atr_14 > 0)
   {
      entry_dist_high_atr = (bar_h - entry_price) / snap.atr_14;
      entry_dist_low_atr = (entry_price - bar_l) / snap.atr_14;
   }
   
   string entry_quality = "MIDDLE";
   if(entry_vs_range_pct > 80) entry_quality = "AT_HIGH";
   else if(entry_vs_range_pct < 20) entry_quality = "AT_LOW";
   else if(entry_vs_range_pct > 50) entry_quality = "UPPER_HALF";
   else entry_quality = "LOWER_HALF";
   
   // Fill record
   g_tracked[slot].ticket = position_id;
   g_tracked[slot].pattern_id = pattern_id;
   g_tracked[slot].pattern_name = meta.name;
   g_tracked[slot].pattern_category = meta.category;
   g_tracked[slot].pattern_direction = meta.direction;
   g_tracked[slot].trade_direction = direction;
   g_tracked[slot].symbol = Symbol();
   g_tracked[slot].timeframe = _Period;
   g_tracked[slot].open_time = now;
   g_tracked[slot].close_time = 0;
   g_tracked[slot].expire_time = expire;
   
   g_tracked[slot].bar_open = bar_o;
   g_tracked[slot].bar_high = bar_h;
   g_tracked[slot].bar_low = bar_l;
   g_tracked[slot].bar_close = bar_c;
   g_tracked[slot].bar_body = bar_body;
   g_tracked[slot].bar_upper_wick = bar_upper_wick;
   g_tracked[slot].bar_lower_wick = bar_lower_wick;
   g_tracked[slot].bar_range = bar_range;
   
   g_tracked[slot].entry_price = entry_price;            // Will be updated to actual fill in OnTradeTransaction DEAL_ENTRY_IN
   g_tracked[slot].intended_entry_price = entry_price;   // Frozen: what we requested before broker fill
   g_tracked[slot].spread_at_entry_pts = (int)SymbolInfoInteger(Symbol(), SYMBOL_SPREAD);
   g_tracked[slot].spread_at_exit_pts = 0;               // Will be set at close
   g_tracked[slot].entry_vs_body_pct = entry_vs_body_pct;
   g_tracked[slot].entry_vs_range_pct = entry_vs_range_pct;
   g_tracked[slot].entry_distance_from_high_atr = entry_dist_high_atr;
   g_tracked[slot].entry_distance_from_low_atr = entry_dist_low_atr;
   g_tracked[slot].entry_quality = entry_quality;
   
   g_tracked[slot].path_1h.Reset();
   g_tracked[slot].path_6h.Reset();
   g_tracked[slot].path_12h.Reset();
   g_tracked[slot].path_24h.Reset();
   g_tracked[slot].path_48h.Reset();
   g_tracked[slot].path_72h.Reset();
   g_tracked[slot].path_120h.Reset();
   g_tracked[slot].path_168h.Reset();
   g_tracked[slot].path_240h.Reset();
   
   g_tracked[slot].max_favorable = entry_price;
   g_tracked[slot].max_adverse = entry_price;
   g_tracked[slot].max_favorable_atr = 0;
   g_tracked[slot].max_adverse_atr = 0;
   g_tracked[slot].mfe_time = now;
   g_tracked[slot].mae_time = now;
   g_tracked[slot].hours_to_mfe = 0;
   g_tracked[slot].hours_to_mae = 0;
   
   g_tracked[slot].sl_05_hit = false;
   g_tracked[slot].sl_10_hit = false;
   g_tracked[slot].sl_20_hit = false;
   g_tracked[slot].sl_30_hit = false;
   g_tracked[slot].tp_10_hit = false;
   g_tracked[slot].tp_20_hit = false;
   g_tracked[slot].tp_30_hit = false;
   g_tracked[slot].tp_50_hit = false;
   g_tracked[slot].tp_10_time = 0;
   g_tracked[slot].tp_20_time = 0;
   g_tracked[slot].tp_30_time = 0;
   g_tracked[slot].tp_50_time = 0;
   
   g_tracked[slot].lot = lot;
   g_tracked[slot].entry_balance = balance_before;
   g_tracked[slot].entry_atr = snap.atr_14;
   g_tracked[slot].indicators = snap;
   g_tracked[slot].all_patterns = all_flags;
   g_tracked[slot].active = true;
   
   return true;
}

//+------------------------------------------------------------------+
//| ProcessClosedBar — fire orders for ALL fired patterns           |
//+------------------------------------------------------------------+
void ProcessClosedBar(int shift)
{
   if(iBars(Symbol(), _Period) < 250) return;
   
   g_bars_processed++;
   
   IndicatorSnapshot snap;
   if(!g_Indicators.CaptureSnapshot(shift, snap)) return;
   
   PatternFlags flags;
   g_MasterDetector.DetectAll(shift, flags, snap, g_prev_snap, g_prev_snap_valid);
   
   g_prev_snap = snap;
   g_prev_snap_valid = true;
   
   if(flags.total_count == 0) return;
   
   g_bars_with_signal++;
   g_patterns_fired_total += flags.total_count;
   
   // Count by category
   g_patterns_per_cat[0] += g_MasterDetector.CountCatA(flags);
   g_patterns_per_cat[1] += g_MasterDetector.CountCatB(flags);
   g_patterns_per_cat[2] += g_MasterDetector.CountCatC(flags);
   g_patterns_per_cat[3] += g_MasterDetector.CountCatD(flags);
   g_patterns_per_cat[4] += g_MasterDetector.CountCatE(flags);
   g_patterns_per_cat[5] += g_MasterDetector.CountCatF(flags);
   g_patterns_per_cat[6] += g_MasterDetector.CountCatG(flags);
   g_patterns_per_cat[7] += g_MasterDetector.CountCatH(flags);
   g_patterns_per_cat[8] += g_MasterDetector.CountCatI(flags);
   g_patterns_per_cat[9] += g_MasterDetector.CountCatJ(flags);
   g_patterns_per_cat[10] += g_MasterDetector.CountCatK(flags);
   g_patterns_per_cat[11] += g_MasterDetector.CountCatL(flags);
   g_patterns_per_cat[12] += g_MasterDetector.CountCatM(flags);
   g_patterns_per_cat[13] += g_MasterDetector.CountCatN(flags);
   g_patterns_per_cat[14] += g_MasterDetector.CountCatO(flags);
   g_patterns_per_cat[15] += g_MasterDetector.CountCatP(flags);
   g_patterns_per_cat[16] += g_MasterDetector.CountCatQ(flags);
   g_patterns_per_cat[17] += g_MasterDetector.CountCatR(flags);
   
   // For EVERY pattern that fired, open an order
   int orders_opened = 0;
   for(int pid = 1; pid <= TOTAL_PATTERNS; pid++)
   {
      if(!CPatternMeta::IsFired(pid, flags)) continue;
      
      PatternMeta meta = CPatternMeta::Get(pid);
      
      // Category filter
      if(!IsCategoryEnabled(meta.category)) continue;
      
      // Determine direction
      if(meta.direction == 1)
      {
         g_orders_attempted++;
         if(OpenForPattern(pid, 1, flags, snap)) orders_opened++;
      }
      else if(meta.direction == -1)
      {
         g_orders_attempted++;
         if(OpenForPattern(pid, -1, flags, snap)) orders_opened++;
      }
      else
      {
         // Direction-agnostic
         if(InpAgnosticBoth)
         {
            g_orders_attempted += 2;
            if(OpenForPattern(pid, 1, flags, snap)) orders_opened++;
            if(OpenForPattern(pid, -1, flags, snap)) orders_opened++;
         }
      }
   }
   
   if(orders_opened > 0 || flags.total_count > 0)
   {
      Print("Bar ", iTime(Symbol(), _Period, shift),
            " | patterns=", flags.total_count,
            " (A=", g_MasterDetector.CountCatA(flags),
            " B=", g_MasterDetector.CountCatB(flags),
            " C=", g_MasterDetector.CountCatC(flags),
            " D=", g_MasterDetector.CountCatD(flags),
            " E=", g_MasterDetector.CountCatE(flags),
            " F=", g_MasterDetector.CountCatF(flags),
            " G=", g_MasterDetector.CountCatG(flags),
            " H=", g_MasterDetector.CountCatH(flags),
            " I=", g_MasterDetector.CountCatI(flags),
            " J=", g_MasterDetector.CountCatJ(flags), ")",
            " | dir=", flags.direction,
            " | orders=", orders_opened,
            " | active=", CountActiveSlots());
   }
}
//+------------------------------------------------------------------+