//+------------------------------------------------------------------+
//|                                              KMP_Indicators.mqh |
//|                              Indicator handle management         |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_INDICATORS_MQH
#define KMP_INDICATORS_MQH

#include "KMP_Structures.mqh"

//+------------------------------------------------------------------+
//| Indicator manager class                                          |
//+------------------------------------------------------------------+
class CIndicatorManager
{
private:
   string   m_symbol;
   ENUM_TIMEFRAMES m_tf;
   
   // Indicator handles
   int   h_ema9, h_ema20, h_ema50, h_ema100, h_ema200;
   int   h_bb_20_2, h_bb_50_2;
   int   h_atr14, h_atr50;
   int   h_rsi14, h_rsi7;
   int   h_stoch;
   int   h_macd;
   int   h_adx;
   int   h_ichimoku;
   
public:
   CIndicatorManager() : m_symbol(""), m_tf(PERIOD_CURRENT)
   {
      h_ema9 = h_ema20 = h_ema50 = h_ema100 = h_ema200 = INVALID_HANDLE;
      h_bb_20_2 = h_bb_50_2 = INVALID_HANDLE;
      h_atr14 = h_atr50 = INVALID_HANDLE;
      h_rsi14 = h_rsi7 = INVALID_HANDLE;
      h_stoch = h_macd = h_adx = INVALID_HANDLE;
      h_ichimoku = INVALID_HANDLE;
   }
   
   ~CIndicatorManager() { Deinit(); }
   
   //+---------------------------------------------------------------+
   //| Initialize all indicator handles                              |
   //+---------------------------------------------------------------+
   bool Init(string symbol, ENUM_TIMEFRAMES tf)
   {
      m_symbol = symbol;
      m_tf = tf;
      
      h_ema9   = iMA(symbol, tf, 9,   0, MODE_EMA, PRICE_CLOSE);
      h_ema20  = iMA(symbol, tf, 20,  0, MODE_EMA, PRICE_CLOSE);
      h_ema50  = iMA(symbol, tf, 50,  0, MODE_EMA, PRICE_CLOSE);
      h_ema100 = iMA(symbol, tf, 100, 0, MODE_EMA, PRICE_CLOSE);
      h_ema200 = iMA(symbol, tf, 200, 0, MODE_EMA, PRICE_CLOSE);
      
      h_bb_20_2 = iBands(symbol, tf, 20, 0, 2.0, PRICE_CLOSE);
      h_bb_50_2 = iBands(symbol, tf, 50, 0, 2.0, PRICE_CLOSE);
      
      h_atr14 = iATR(symbol, tf, 14);
      h_atr50 = iATR(symbol, tf, 50);
      
      h_rsi14 = iRSI(symbol, tf, 14, PRICE_CLOSE);
      h_rsi7  = iRSI(symbol, tf, 7,  PRICE_CLOSE);
      
      h_stoch = iStochastic(symbol, tf, 14, 3, 3, MODE_SMA, STO_LOWHIGH);
      h_macd  = iMACD(symbol, tf, 12, 26, 9, PRICE_CLOSE);
      h_adx   = iADX(symbol, tf, 14);
      h_ichimoku = iIchimoku(symbol, tf, 9, 26, 52);  // Tenkan/Kijun/Senkou
      
      // Verify all handles
      int handles[] = {h_ema9, h_ema20, h_ema50, h_ema100, h_ema200,
                       h_bb_20_2, h_bb_50_2, h_atr14, h_atr50,
                       h_rsi14, h_rsi7, h_stoch, h_macd, h_adx,
                       h_ichimoku};
      
      for(int i = 0; i < ArraySize(handles); i++)
      {
         if(handles[i] == INVALID_HANDLE)
         {
            Print("ERROR: Failed to create indicator handle index ", i);
            return false;
         }
      }
      
      Print("All indicator handles created successfully");
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| Cleanup                                                       |
   //+---------------------------------------------------------------+
   void Deinit()
   {
      if(h_ema9 != INVALID_HANDLE)   IndicatorRelease(h_ema9);
      if(h_ema20 != INVALID_HANDLE)  IndicatorRelease(h_ema20);
      if(h_ema50 != INVALID_HANDLE)  IndicatorRelease(h_ema50);
      if(h_ema100 != INVALID_HANDLE) IndicatorRelease(h_ema100);
      if(h_ema200 != INVALID_HANDLE) IndicatorRelease(h_ema200);
      if(h_bb_20_2 != INVALID_HANDLE) IndicatorRelease(h_bb_20_2);
      if(h_bb_50_2 != INVALID_HANDLE) IndicatorRelease(h_bb_50_2);
      if(h_atr14 != INVALID_HANDLE)  IndicatorRelease(h_atr14);
      if(h_atr50 != INVALID_HANDLE)  IndicatorRelease(h_atr50);
      if(h_rsi14 != INVALID_HANDLE)  IndicatorRelease(h_rsi14);
      if(h_rsi7 != INVALID_HANDLE)   IndicatorRelease(h_rsi7);
      if(h_stoch != INVALID_HANDLE)  IndicatorRelease(h_stoch);
      if(h_macd != INVALID_HANDLE)   IndicatorRelease(h_macd);
      if(h_adx != INVALID_HANDLE)    IndicatorRelease(h_adx);
      if(h_ichimoku != INVALID_HANDLE) IndicatorRelease(h_ichimoku);
   }
   
   //+---------------------------------------------------------------+
   //| Helper: get single value from buffer at shift                |
   //+---------------------------------------------------------------+
   double GetValue(int handle, int buffer, int shift)
   {
      double v[];
      if(CopyBuffer(handle, buffer, shift, 1, v) <= 0) return 0;
      return v[0];
   }
   
   //+---------------------------------------------------------------+
   //| Capture full snapshot at specified shift                     |
   //+---------------------------------------------------------------+
   bool CaptureSnapshot(int shift, IndicatorSnapshot &snap)
   {
      snap.Reset();
      
      // EMAs
      snap.ema_9   = GetValue(h_ema9, 0, shift);
      snap.ema_20  = GetValue(h_ema20, 0, shift);
      snap.ema_50  = GetValue(h_ema50, 0, shift);
      snap.ema_100 = GetValue(h_ema100, 0, shift);
      snap.ema_200 = GetValue(h_ema200, 0, shift);
      
      // EMA alignment
      bool all_bull = (snap.ema_9 > snap.ema_20 && snap.ema_20 > snap.ema_50 &&
                      snap.ema_50 > snap.ema_100 && snap.ema_100 > snap.ema_200);
      bool all_bear = (snap.ema_9 < snap.ema_20 && snap.ema_20 < snap.ema_50 &&
                      snap.ema_50 < snap.ema_100 && snap.ema_100 < snap.ema_200);
      snap.ema_alignment = all_bull ? "ALL_BULL" : (all_bear ? "ALL_BEAR" : "MIXED");
      
      // Bollinger Bands (20, 2)
      snap.bb_upper  = GetValue(h_bb_20_2, 1, shift);
      snap.bb_middle = GetValue(h_bb_20_2, 0, shift);
      snap.bb_lower  = GetValue(h_bb_20_2, 2, shift);
      snap.bb_width  = snap.bb_upper - snap.bb_lower;
      
      // BB width avg over last 50 bars
      double width_sum = 0;
      int width_count = 0;
      for(int i = shift; i < shift + 50; i++)
      {
         double up = GetValue(h_bb_20_2, 1, i);
         double lo = GetValue(h_bb_20_2, 2, i);
         if(up > 0 && lo > 0)
         {
            width_sum += (up - lo);
            width_count++;
         }
      }
      snap.bb_width_avg = (width_count > 0) ? width_sum / width_count : snap.bb_width;
      snap.bb_width_ratio = (snap.bb_width_avg > 0) ? snap.bb_width / snap.bb_width_avg : 1.0;
      
      // BB position
      double close_price = iClose(m_symbol, m_tf, shift);
      if(snap.bb_width > 0)
         snap.bb_position_pct = ((close_price - snap.bb_lower) / snap.bb_width) * 100.0;
      
      snap.bb_squeeze = (snap.bb_width_ratio < 0.7);
      snap.bb_expansion = (snap.bb_width_ratio > 1.3);
      
      // ATR
      snap.atr_14 = GetValue(h_atr14, 0, shift);
      snap.atr_50 = GetValue(h_atr50, 0, shift);
      snap.atr_ratio = (snap.atr_50 > 0) ? snap.atr_14 / snap.atr_50 : 1.0;
      
      if(snap.atr_ratio < 0.7) snap.volatility_regime = "LOW";
      else if(snap.atr_ratio < 1.3) snap.volatility_regime = "NORMAL";
      else if(snap.atr_ratio < 2.0) snap.volatility_regime = "HIGH";
      else snap.volatility_regime = "EXTREME";
      
      // Momentum
      snap.rsi_14 = GetValue(h_rsi14, 0, shift);
      snap.rsi_7  = GetValue(h_rsi7, 0, shift);
      snap.stoch_k = GetValue(h_stoch, 0, shift);
      snap.stoch_d = GetValue(h_stoch, 1, shift);
      snap.macd_main      = GetValue(h_macd, 0, shift);
      snap.macd_signal    = GetValue(h_macd, 1, shift);
      snap.macd_histogram = snap.macd_main - snap.macd_signal;
      
      // RSI Divergence (simplified detection over last 14 bars)
      snap.rsi_divergence_bull = DetectBullishDivergence(shift);
      snap.rsi_divergence_bear = DetectBearishDivergence(shift);
      
      // Volume
      snap.tick_volume = iTickVolume(m_symbol, m_tf, shift);
      double vol_sum = 0;
      for(int i = shift + 1; i <= shift + 20; i++)
         vol_sum += (double)iTickVolume(m_symbol, m_tf, i);
      snap.volume_ma_20 = vol_sum / 20.0;
      snap.volume_ratio = (snap.volume_ma_20 > 0) ? (double)snap.tick_volume / snap.volume_ma_20 : 1.0;
      snap.volume_spike = (snap.volume_ratio > 2.0);
      
      // Trend
      snap.adx      = GetValue(h_adx, 0, shift);
      snap.di_plus  = GetValue(h_adx, 1, shift);
      snap.di_minus = GetValue(h_adx, 2, shift);
      
      double di_diff = snap.di_plus - snap.di_minus;
      if(snap.adx > 25)
      {
         if(di_diff > 5) snap.trend_regime = "STRONG_UP";
         else if(di_diff < -5) snap.trend_regime = "STRONG_DOWN";
         else snap.trend_regime = "RANGING";
      }
      else
      {
         if(di_diff > 0) snap.trend_regime = "WEAK_UP";
         else if(di_diff < 0) snap.trend_regime = "WEAK_DOWN";
         else snap.trend_regime = "RANGING";
      }
      
      // Ichimoku — buffer 0=Tenkan, 1=Kijun, 2=SenkouA, 3=SenkouB, 4=Chikou
      // Note: SenkouA/B are projected forward 26 periods; Chikou shifted back 26
      snap.ichimoku_tenkan   = GetValue(h_ichimoku, 0, shift);
      snap.ichimoku_kijun    = GetValue(h_ichimoku, 1, shift);
      // For current bar's "cloud" we read SenkouA/B at shift+26 (which is "current" cloud)
      snap.ichimoku_senkou_a = GetValue(h_ichimoku, 2, shift + 26);
      snap.ichimoku_senkou_b = GetValue(h_ichimoku, 3, shift + 26);
      // For "future cloud" (twist detection) read SenkouA/B at shift (projected to shift+26)
      snap.ichimoku_future_a = GetValue(h_ichimoku, 2, shift);
      snap.ichimoku_future_b = GetValue(h_ichimoku, 3, shift);
      // Chikou span = close shifted back 26 periods (read at shift, value = close 26 ago)
      snap.ichimoku_chikou   = GetValue(h_ichimoku, 4, shift + 26);

      // Market Structure
      DetectSwings(shift, snap);
      
      // Time
      datetime t = iTime(m_symbol, m_tf, shift);
      MqlDateTime dt;
      TimeToStruct(t, dt);
      snap.hour_of_day = dt.hour;
      snap.day_of_week = dt.day_of_week;
      snap.session = DetermineSession(dt.hour);
      
      // Key Levels
      snap.daily_high = iHigh(m_symbol, PERIOD_D1, 0);
      snap.daily_low  = iLow(m_symbol, PERIOD_D1, 0);
      snap.prev_day_high = iHigh(m_symbol, PERIOD_D1, 1);
      snap.prev_day_low  = iLow(m_symbol, PERIOD_D1, 1);
      
      // Pivot Points (classic)
      double pdh = snap.prev_day_high;
      double pdl = snap.prev_day_low;
      double pdc = iClose(m_symbol, PERIOD_D1, 1);
      snap.pivot_pp = (pdh + pdl + pdc) / 3.0;
      snap.pivot_r1 = 2 * snap.pivot_pp - pdl;
      snap.pivot_s1 = 2 * snap.pivot_pp - pdh;
      
      // Round number (nearest 5 USD on gold, 100 on BTC)
      double round_step = 5.0;  // Default for gold
      if(StringFind(m_symbol, "BTC") >= 0) round_step = 100.0;
      else if(StringFind(m_symbol, "JPY") >= 0) round_step = 0.5;
      else if(StringFind(m_symbol, "USD") >= 0) round_step = 0.01;  // forex majors
      
      snap.nearest_round = MathRound(close_price / round_step) * round_step;
      snap.distance_to_round = MathAbs(close_price - snap.nearest_round);
      
      // Candle microstructure
      double h = iHigh(m_symbol, m_tf, shift);
      double l = iLow(m_symbol, m_tf, shift);
      double o = iOpen(m_symbol, m_tf, shift);
      double c = iClose(m_symbol, m_tf, shift);
      
      snap.bar_range = h - l;
      snap.bar_body = MathAbs(c - o);
      snap.bar_upper_wick = h - MathMax(o, c);
      snap.bar_lower_wick = MathMin(o, c) - l;
      snap.bar_body_pct = (snap.bar_range > 0) ? (snap.bar_body / snap.bar_range) * 100.0 : 0;
      
      double range_sum = 0;
      for(int i = shift + 1; i <= shift + 20; i++)
         range_sum += (iHigh(m_symbol, m_tf, i) - iLow(m_symbol, m_tf, i));
      double range_avg = range_sum / 20.0;
      snap.bar_size_vs_avg = (range_avg > 0) ? snap.bar_range / range_avg : 1.0;
      
      return true;
   }
   
private:
   //+---------------------------------------------------------------+
   //| Determine trading session by hour (broker time, GMT+2/3)     |
   //+---------------------------------------------------------------+
   string DetermineSession(int hour)
   {
      // Approximate sessions (broker time may vary)
      if(hour >= 0 && hour < 7)   return "ASIAN";
      if(hour >= 7 && hour < 12)  return "LONDON";
      if(hour >= 12 && hour < 16) return "OVERLAP";  // London + NY
      if(hour >= 16 && hour < 21) return "NY";
      return "ASIAN";  // late evening
   }
   
   //+---------------------------------------------------------------+
   //| Simple swing detection (5-bar fractal)                       |
   //+---------------------------------------------------------------+
   void DetectSwings(int shift, IndicatorSnapshot &snap)
   {
      // Look back up to 50 bars for nearest swing
      double last_high = 0, last_low = 0;
      int bars_high = -1, bars_low = -1;
      
      for(int i = shift + 2; i < shift + 50; i++)
      {
         double h_curr = iHigh(m_symbol, m_tf, i);
         double l_curr = iLow(m_symbol, m_tf, i);
         
         // Swing high: higher than 2 bars on each side
         if(last_high == 0 &&
            h_curr > iHigh(m_symbol, m_tf, i+1) &&
            h_curr > iHigh(m_symbol, m_tf, i+2) &&
            h_curr > iHigh(m_symbol, m_tf, i-1) &&
            h_curr > iHigh(m_symbol, m_tf, i-2))
         {
            last_high = h_curr;
            bars_high = i - shift;
         }
         
         if(last_low == 0 &&
            l_curr < iLow(m_symbol, m_tf, i+1) &&
            l_curr < iLow(m_symbol, m_tf, i+2) &&
            l_curr < iLow(m_symbol, m_tf, i-1) &&
            l_curr < iLow(m_symbol, m_tf, i-2))
         {
            last_low = l_curr;
            bars_low = i - shift;
         }
         
         if(last_high > 0 && last_low > 0) break;
      }
      
      snap.last_swing_high = last_high;
      snap.last_swing_low = last_low;
      snap.bars_since_swing_high = bars_high;
      snap.bars_since_swing_low = bars_low;
      
      // Determine structure (HH/HL vs LL/LH) — simplified
      if(bars_high > 0 && bars_low > 0)
      {
         if(bars_high < bars_low)  // Recent swing high more recent
            snap.structure_state = "LL_LH";  // bearish
         else
            snap.structure_state = "HH_HL";  // bullish
      }
      else
         snap.structure_state = "MIXED";
   }
   
   //+---------------------------------------------------------------+
   //| Detect bullish RSI divergence                                |
   //+---------------------------------------------------------------+
   bool DetectBullishDivergence(int shift)
   {
      // Look for: price makes lower low, RSI makes higher low
      // Simplified: compare current bar vs 5-10 bars ago
      double price_now = iLow(m_symbol, m_tf, shift);
      double rsi_now = GetValue(h_rsi14, 0, shift);
      
      double lowest_price = price_now;
      double rsi_at_lowest = rsi_now;
      
      // Find recent lowest low in last 10 bars
      for(int i = shift + 1; i <= shift + 14; i++)
      {
         double l = iLow(m_symbol, m_tf, i);
         if(l < lowest_price)
         {
            lowest_price = l;
            rsi_at_lowest = GetValue(h_rsi14, 0, i);
         }
      }
      
      // Bullish divergence: price made new low recently but RSI is higher now
      return (price_now < lowest_price * 1.001 && rsi_now > rsi_at_lowest + 3);
   }
   
   //+---------------------------------------------------------------+
   //| Detect bearish RSI divergence                                |
   //+---------------------------------------------------------------+
   bool DetectBearishDivergence(int shift)
   {
      double price_now = iHigh(m_symbol, m_tf, shift);
      double rsi_now = GetValue(h_rsi14, 0, shift);
      
      double highest_price = price_now;
      double rsi_at_highest = rsi_now;
      
      for(int i = shift + 1; i <= shift + 14; i++)
      {
         double h = iHigh(m_symbol, m_tf, i);
         if(h > highest_price)
         {
            highest_price = h;
            rsi_at_highest = GetValue(h_rsi14, 0, i);
         }
      }
      
      return (price_now > highest_price * 0.999 && rsi_now < rsi_at_highest - 3);
   }
};

#endif  // KMP_INDICATORS_MQH
//+------------------------------------------------------------------+