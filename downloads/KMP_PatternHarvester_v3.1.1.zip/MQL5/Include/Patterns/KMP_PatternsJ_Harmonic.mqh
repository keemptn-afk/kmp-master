//+------------------------------------------------------------------+
//|                                  KMP_PatternsJ_Harmonic.mqh     |
//|                                                                  |
//|  CATEGORY J: HARMONIC + SPECIALIZED PATTERNS (P108-P125)         |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Scott M. Carney — "Harmonic Trading Vol.1 & Vol.2" (2010). |
//|      The 5-point XABCD harmonic patterns: Gartley, Bat,         |
//|      Butterfly, Crab, Cypher.                                    |
//|  [2] Thomas Bulkowski — "Encyclopedia of Chart Patterns" — the  |
//|      Bullish/Bearish Kicker is reported at ~78% accuracy.        |
//|  [3] Larry Williams — "Long-Term Secrets to Short-Term Trading"  |
//|      and CME-style intraday research on session-range sweeps.   |
//|                                                                  |
//|  Harmonic implementation note:                                   |
//|  We identify 4 alternating swing pivots before the current bar |
//|  to form the X-A-B-C structure; the current price is treated as |
//|  the D completion point. Tolerances on each Fib ratio are       |
//|  reasonably wide (~ +/-15%) since strict harmonic ratios rarely |
//|  match perfectly on raw OHLC and market microstructure.          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_J_MQH
#define KMP_PATTERNS_J_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CHarmonicPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

   int    m_swing_lookback;
   int    m_swing_left;
   int    m_swing_right;
   int    m_asian_start_hour;     // broker hour Asian session start (default 0)
   int    m_asian_end_hour;       // broker hour Asian session end   (default 8)
   int    m_london_start_hour;    // broker hour London (sweep window) (default 9)
   int    m_london_end_hour;      // (default 13)

public:
   CHarmonicPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                         m_swing_lookback(80),
                         m_swing_left(3), m_swing_right(3),
                         m_asian_start_hour(0),  m_asian_end_hour(8),
                         m_london_start_hour(9), m_london_end_hour(13) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int swing_lookback = 80, int swing_left = 3, int swing_right = 3,
                  int asian_start = 0, int asian_end = 8,
                  int london_start = 9, int london_end = 13)
   {
      m_swing_lookback   = swing_lookback;
      m_swing_left       = swing_left;
      m_swing_right      = swing_right;
      m_asian_start_hour = asian_start;
      m_asian_end_hour   = asian_end;
      m_london_start_hour= london_start;
      m_london_end_hour  = london_end;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      // Harmonic: precompute the 4 alternating swing points once, reuse for all 5 patterns
      double X = 0, A = 0, B = 0, C = 0;
      bool bull_struct = FindHarmonicStructure(shift, 1, X, A, B, C, atr);
      bool bear_struct = FindHarmonicStructure(shift, -1, X, A, B, C, atr);

      // Bullish patterns (D point is below C, near a Fib of XA)
      if(bull_struct)
      {
         FindHarmonicStructure(shift, 1, X, A, B, C, atr);  // refresh into output
         double cur_low = iLow(m_symbol, m_period, shift);
         flags.P108_Gartley_Bull   = CheckGartleyBull(X, A, B, C, cur_low, atr);
         flags.P110_Bat_Bull       = CheckBatBull    (X, A, B, C, cur_low, atr);
         flags.P112_Butterfly_Bull = CheckButterflyBull(X, A, B, C, cur_low, atr);
         flags.P114_Crab_Bull      = CheckCrabBull   (X, A, B, C, cur_low, atr);
         flags.P116_Cypher_Bull    = CheckCypherBull (X, A, B, C, cur_low, atr);
      }
      if(bear_struct)
      {
         FindHarmonicStructure(shift, -1, X, A, B, C, atr);
         double cur_high = iHigh(m_symbol, m_period, shift);
         flags.P109_Gartley_Bear   = CheckGartleyBear(X, A, B, C, cur_high, atr);
         flags.P111_Bat_Bear       = CheckBatBear    (X, A, B, C, cur_high, atr);
         flags.P113_Butterfly_Bear = CheckButterflyBear(X, A, B, C, cur_high, atr);
         flags.P115_Crab_Bear      = CheckCrabBear   (X, A, B, C, cur_high, atr);
         flags.P117_Cypher_Bear    = CheckCypherBear (X, A, B, C, cur_high, atr);
      }

      // Specialized
      flags.P118_Asian_Sweep_Long  = DetectAsianSweepLong (shift, snap, atr);
      flags.P119_Asian_Sweep_Short = DetectAsianSweepShort(shift, snap, atr);
      flags.P120_Sunday_Gap_Fill_Long  = DetectSundayGapFillLong (shift, atr);
      flags.P121_Sunday_Gap_Fill_Short = DetectSundayGapFillShort(shift, atr);
      flags.P122_Kicker_Bull       = DetectKickerBull (shift, atr);
      flags.P123_Kicker_Bear       = DetectKickerBear (shift, atr);
      flags.P124_ThreeBar_Rev_Bull = DetectThreeBarRevBull(shift, atr);
      flags.P125_ThreeBar_Rev_Bear = DetectThreeBarRevBear(shift, atr);
   }

private:
   //+---------------------------------------------------------------+
   //| Find harmonic structure: 4 alternating swings X-A-B-C         |
   //|  direction =  1 → looking for bullish (X low, A high, B low, C high)
   //|  direction = -1 → bearish (X high, A low, B high, C low)
   //|  Returns true if found; sets X,A,B,C as price levels.         |
   //+---------------------------------------------------------------+
   bool FindHarmonicStructure(int shift, int direction,
                              double &X, double &A, double &B, double &C,
                              double atr)
   {
      // Find C first (most recent extreme opposite to D)
      int c_idx = -1;
      if(direction == 1)
         c_idx = FindSwingHigh(m_symbol, m_period, shift + 1, m_swing_lookback, m_swing_left, m_swing_right);
      else
         c_idx = FindSwingLow (m_symbol, m_period, shift + 1, m_swing_lookback, m_swing_left, m_swing_right);
      if(c_idx < 0) return false;

      // Find B (opposite swing before C)
      int b_idx = -1;
      if(direction == 1)
         b_idx = FindSwingLow (m_symbol, m_period, c_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      else
         b_idx = FindSwingHigh(m_symbol, m_period, c_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      if(b_idx < 0) return false;

      // Find A (same direction as C, before B)
      int a_idx = -1;
      if(direction == 1)
         a_idx = FindSwingHigh(m_symbol, m_period, b_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      else
         a_idx = FindSwingLow (m_symbol, m_period, b_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      if(a_idx < 0) return false;

      // Find X (same direction as B, before A)
      int x_idx = -1;
      if(direction == 1)
         x_idx = FindSwingLow (m_symbol, m_period, a_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      else
         x_idx = FindSwingHigh(m_symbol, m_period, a_idx + 4, m_swing_lookback, m_swing_left, m_swing_right);
      if(x_idx < 0) return false;

      if(direction == 1)
      {
         X = iLow (m_symbol, m_period, x_idx);
         A = iHigh(m_symbol, m_period, a_idx);
         B = iLow (m_symbol, m_period, b_idx);
         C = iHigh(m_symbol, m_period, c_idx);
         // Sanity: A > X, B > X (B is correction not full retrace), C > B, C < A typically
         if(A <= X) return false;
         if(B <= X) return false;
         if(C <= B) return false;
      }
      else
      {
         X = iHigh(m_symbol, m_period, x_idx);
         A = iLow (m_symbol, m_period, a_idx);
         B = iHigh(m_symbol, m_period, b_idx);
         C = iLow (m_symbol, m_period, c_idx);
         if(A >= X) return false;
         if(B >= X) return false;
         if(C >= B) return false;
      }

      // require minimum leg size relative to ATR
      if(MathAbs(A - X) < 1.0 * atr) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| Helper: ratio in tolerance                                    |
   //+---------------------------------------------------------------+
   bool RatioIn(double r, double lo, double hi)
   {
      return (r >= lo && r <= hi);
   }

   //+---------------------------------------------------------------+
   //| GARTLEY BULL — XA up, retrace 0.618; D at 0.786 of XA          |
   //|  AB / XA   ≈ 0.618 (tol 0.50–0.71)                              |
   //|  BC / AB   ∈ [0.382, 0.886]                                     |
   //|  CD / BC   ∈ [1.13, 1.618]                                      |
   //|  D level   ≈ X + (A-X)*(1 - 0.786)  i.e. close to 0.786 retrace |
   //+---------------------------------------------------------------+
   bool CheckGartleyBull(double X, double A, double B, double C, double cur_low, double atr)
   {
      double XA = A - X;
      double AB = A - B;
      double BC = C - B;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.50, 0.71)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A - XA * 0.786;
      return MathAbs(cur_low - D_target) <= 0.5 * atr && cur_low <= C;
   }
   bool CheckGartleyBear(double X, double A, double B, double C, double cur_high, double atr)
   {
      double XA = X - A;
      double AB = B - A;
      double BC = B - C;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.50, 0.71)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A + XA * 0.786;
      return MathAbs(cur_high - D_target) <= 0.5 * atr && cur_high >= C;
   }

   //+---------------------------------------------------------------+
   //| BAT BULL — AB shallow, D deep at 0.886 of XA                  |
   //+---------------------------------------------------------------+
   bool CheckBatBull(double X, double A, double B, double C, double cur_low, double atr)
   {
      double XA = A - X;
      double AB = A - B;
      double BC = C - B;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.50)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A - XA * 0.886;
      return MathAbs(cur_low - D_target) <= 0.5 * atr && cur_low <= C;
   }
   bool CheckBatBear(double X, double A, double B, double C, double cur_high, double atr)
   {
      double XA = X - A;
      double AB = B - A;
      double BC = B - C;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.50)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A + XA * 0.886;
      return MathAbs(cur_high - D_target) <= 0.5 * atr && cur_high >= C;
   }

   //+---------------------------------------------------------------+
   //| BUTTERFLY BULL — AB at 0.786, D extends to 1.272 of XA       |
   //+---------------------------------------------------------------+
   bool CheckButterflyBull(double X, double A, double B, double C, double cur_low, double atr)
   {
      double XA = A - X;
      double AB = A - B;
      double BC = C - B;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.71, 0.886)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A - XA * 1.272;
      return MathAbs(cur_low - D_target) <= 0.5 * atr && cur_low < X;
   }
   bool CheckButterflyBear(double X, double A, double B, double C, double cur_high, double atr)
   {
      double XA = X - A;
      double AB = B - A;
      double BC = B - C;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.71, 0.886)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A + XA * 1.272;
      return MathAbs(cur_high - D_target) <= 0.5 * atr && cur_high > X;
   }

   //+---------------------------------------------------------------+
   //| CRAB BULL — deepest extension, D at 1.618 of XA              |
   //+---------------------------------------------------------------+
   bool CheckCrabBull(double X, double A, double B, double C, double cur_low, double atr)
   {
      double XA = A - X;
      double AB = A - B;
      double BC = C - B;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.618)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A - XA * 1.618;
      return MathAbs(cur_low - D_target) <= 0.5 * atr && cur_low < X;
   }
   bool CheckCrabBear(double X, double A, double B, double C, double cur_high, double atr)
   {
      double XA = X - A;
      double AB = B - A;
      double BC = B - C;
      if(XA <= 0 || AB <= 0 || BC <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.618)) return false;
      if(!RatioIn(BC/AB, 0.382, 0.886)) return false;
      double D_target = A + XA * 1.618;
      return MathAbs(cur_high - D_target) <= 0.5 * atr && cur_high > X;
   }

   //+---------------------------------------------------------------+
   //| CYPHER BULL — BC extends past A; D at 0.786 of XC            |
   //+---------------------------------------------------------------+
   bool CheckCypherBull(double X, double A, double B, double C, double cur_low, double atr)
   {
      double XA = A - X;
      double AB = A - B;
      if(XA <= 0 || AB <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.618)) return false;
      double XC = C - X;
      if(XC <= 0) return false;
      double XC_to_XA = XC / XA;
      if(!RatioIn(XC_to_XA, 1.13, 1.414)) return false;
      double D_target = C - XC * 0.786;
      return MathAbs(cur_low - D_target) <= 0.5 * atr;
   }
   bool CheckCypherBear(double X, double A, double B, double C, double cur_high, double atr)
   {
      double XA = X - A;
      double AB = B - A;
      if(XA <= 0 || AB <= 0) return false;
      if(!RatioIn(AB/XA, 0.382, 0.618)) return false;
      double XC = X - C;
      if(XC <= 0) return false;
      double XC_to_XA = XC / XA;
      if(!RatioIn(XC_to_XA, 1.13, 1.414)) return false;
      double D_target = C + XC * 0.786;
      return MathAbs(cur_high - D_target) <= 0.5 * atr;
   }

   //+---------------------------------------------------------------+
   //| P118 — ASIAN RANGE SWEEP LONG                                 |
   //|                                                                |
   //|  Theory (Williams/ICT): Asian session typically forms a tight |
   //|  range. London open often sweeps that range extreme then       |
   //|  reverses. Long if Asian-low was swept and current bar bullish.|
   //|                                                                |
   //|  Detection (broker hours):                                     |
   //|   1. Identify bars with hour in [asian_start, asian_end) in   |
   //|      most recent 48 bars; compute Asian_high / Asian_low.     |
   //|   2. Current bar's hour is in [london_start, london_end).      |
   //|   3. Either current or one of last 5 bars dipped below        |
   //|      Asian_low - 0.1*ATR.                                      |
   //|   4. Current bar bullish.                                      |
   //+---------------------------------------------------------------+
   void GetAsianRange(int shift, double &asian_high, double &asian_low)
   {
      asian_high = 0;
      asian_low  = 0;
      bool found = false;
      MqlDateTime dt;
      // Walk back to last completed Asian session (yesterday's)
      for(int i = shift + 1; i < shift + 96; i++)
      {
         datetime t = iTime(m_symbol, m_period, i);
         if(t == 0) break;
         TimeToStruct(t, dt);
         if(dt.hour >= m_asian_start_hour && dt.hour < m_asian_end_hour)
         {
            double h = iHigh(m_symbol, m_period, i);
            double l = iLow (m_symbol, m_period, i);
            if(!found)
            {
               asian_high = h;
               asian_low  = l;
               found = true;
            }
            else
            {
               if(h > asian_high) asian_high = h;
               if(l < asian_low)  asian_low  = l;
            }
         }
         else if(found)
         {
            // We left the Asian session block — stop
            break;
         }
      }
   }

   bool DetectAsianSweepLong(int shift, const IndicatorSnapshot &snap, double atr)
   {
      int h = snap.hour_of_day;
      if(h < m_london_start_hour || h >= m_london_end_hour) return false;

      double asian_high = 0, asian_low = 0;
      GetAsianRange(shift, asian_high, asian_low);
      if(asian_low <= 0 || asian_high <= 0) return false;

      bool swept = false;
      for(int j = shift; j <= shift + 5; j++)
      {
         if(iLow(m_symbol, m_period, j) < asian_low - 0.1 * atr) { swept = true; break; }
      }
      if(!swept) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      return (cur_close > cur_open) && (cur_close > asian_low);
   }

   bool DetectAsianSweepShort(int shift, const IndicatorSnapshot &snap, double atr)
   {
      int h = snap.hour_of_day;
      if(h < m_london_start_hour || h >= m_london_end_hour) return false;

      double asian_high = 0, asian_low = 0;
      GetAsianRange(shift, asian_high, asian_low);
      if(asian_low <= 0 || asian_high <= 0) return false;

      bool swept = false;
      for(int j = shift; j <= shift + 5; j++)
      {
         if(iHigh(m_symbol, m_period, j) > asian_high + 0.1 * atr) { swept = true; break; }
      }
      if(!swept) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      return (cur_close < cur_open) && (cur_close < asian_high);
   }

   //+---------------------------------------------------------------+
   //| P120 — SUNDAY GAP FILL LONG                                   |
   //|                                                                |
   //|  Theory: Markets open Sunday/Monday with a price gap from    |
   //|  Friday's close. Statistically, gaps tend to fill within the |
   //|  first few sessions. If current bar is on Mon/Tue and price  |
   //|  gapped DOWN (close[Sun] < close[Fri]), expect long bias as  |
   //|  price rallies to fill.                                       |
   //|                                                                |
   //|  Detection: locate Friday's last close (day_of_week==5)       |
   //|  and Sunday/Monday's open. If gap exists and current bar     |
   //|  is within 24 bars of week start AND bullish, fire.           |
   //+---------------------------------------------------------------+
   bool DetectSundayGapFillLong(int shift, double atr)
   {
      MqlDateTime dt_now;
      datetime t_now = iTime(m_symbol, m_period, shift);
      if(t_now == 0) return false;
      TimeToStruct(t_now, dt_now);
      // Only Mon/Tue (1 or 2)
      if(dt_now.day_of_week != 1 && dt_now.day_of_week != 2) return false;

      // Find Friday close and Sunday/Monday open within last 96 bars
      double friday_close = 0;
      double weekend_open = 0;
      bool found_fri = false, found_open = false;
      for(int i = shift + 1; i < shift + 96; i++)
      {
         datetime t = iTime(m_symbol, m_period, i);
         if(t == 0) break;
         MqlDateTime dt;
         TimeToStruct(t, dt);

         // First monday/sunday open seen walking back is the weekend re-open
         if(!found_open && (dt.day_of_week == 0 || dt.day_of_week == 1))
         {
            weekend_open = iOpen(m_symbol, m_period, i);
            found_open = true;
         }
         if(dt.day_of_week == 5)  // Friday
         {
            friday_close = iClose(m_symbol, m_period, i);
            found_fri = true;
            break;
         }
      }
      if(!found_fri || !found_open) return false;

      double gap = weekend_open - friday_close;
      // Gap DOWN of meaningful size (> 0.5*ATR)
      if(gap >= -0.5 * atr) return false;

      // Current bar bullish + price still below friday_close (gap not fully filled)
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close <= cur_open) return false;
      if(cur_close >= friday_close) return false;

      return true;
   }

   bool DetectSundayGapFillShort(int shift, double atr)
   {
      MqlDateTime dt_now;
      datetime t_now = iTime(m_symbol, m_period, shift);
      if(t_now == 0) return false;
      TimeToStruct(t_now, dt_now);
      if(dt_now.day_of_week != 1 && dt_now.day_of_week != 2) return false;

      double friday_close = 0;
      double weekend_open = 0;
      bool found_fri = false, found_open = false;
      for(int i = shift + 1; i < shift + 96; i++)
      {
         datetime t = iTime(m_symbol, m_period, i);
         if(t == 0) break;
         MqlDateTime dt;
         TimeToStruct(t, dt);
         if(!found_open && (dt.day_of_week == 0 || dt.day_of_week == 1))
         {
            weekend_open = iOpen(m_symbol, m_period, i);
            found_open = true;
         }
         if(dt.day_of_week == 5)
         {
            friday_close = iClose(m_symbol, m_period, i);
            found_fri = true;
            break;
         }
      }
      if(!found_fri || !found_open) return false;

      double gap = weekend_open - friday_close;
      // Gap UP of meaningful size
      if(gap <= 0.5 * atr) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close >= cur_open) return false;
      if(cur_close <= friday_close) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P122 — KICKER BULL                                            |
   //|                                                                |
   //|  Theory (Bulkowski): A bearish candle followed by a strongly |
   //|  bullish candle that opens at-or-above the prior close (no   |
   //|  overlap of bodies). Reversal pattern ~78% accuracy.          |
   //|                                                                |
   //|  Detection:                                                    |
   //|   - bar[shift+1] is bearish with meaningful body              |
   //|   - bar[shift] is bullish with meaningful body                |
   //|   - open[shift] >= close[shift+1] (gap or flat at minimum)    |
   //|   - body[shift] >= body[shift+1] (strong continuation)        |
   //+---------------------------------------------------------------+
   bool DetectKickerBull(int shift, double atr)
   {
      double o1 = iOpen (m_symbol, m_period, shift + 1);
      double c1 = iClose(m_symbol, m_period, shift + 1);
      double o0 = iOpen (m_symbol, m_period, shift);
      double c0 = iClose(m_symbol, m_period, shift);

      double body1 = MathAbs(c1 - o1);
      double body0 = MathAbs(c0 - o0);

      if(c1 >= o1) return false;          // prior must be bearish
      if(c0 <= o0) return false;          // current must be bullish
      if(body1 < 0.5 * atr) return false; // meaningful prior body
      if(body0 < 0.5 * atr) return false; // meaningful current body
      if(o0 < c1) return false;           // open at-or-above prior close
      if(body0 < body1) return false;     // current body must dominate

      return true;
   }

   bool DetectKickerBear(int shift, double atr)
   {
      double o1 = iOpen (m_symbol, m_period, shift + 1);
      double c1 = iClose(m_symbol, m_period, shift + 1);
      double o0 = iOpen (m_symbol, m_period, shift);
      double c0 = iClose(m_symbol, m_period, shift);

      double body1 = MathAbs(c1 - o1);
      double body0 = MathAbs(c0 - o0);

      if(c1 <= o1) return false;          // prior must be bullish
      if(c0 >= o0) return false;          // current must be bearish
      if(body1 < 0.5 * atr) return false;
      if(body0 < 0.5 * atr) return false;
      if(o0 > c1) return false;           // open at-or-below prior close
      if(body0 < body1) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P124 — THREE-BAR REVERSAL BULL                                |
   //|                                                                |
   //|  Theory (Brooks, classical PA): Three-bar reversal at swing  |
   //|  low: bar -2 makes a low, bar -1 makes a lower low, bar 0    |
   //|  closes above the high of bar -1 (and ideally bar -2). Strong|
   //|  short-term reversal signal.                                   |
   //+---------------------------------------------------------------+
   bool DetectThreeBarRevBull(int shift, double atr)
   {
      double l2 = iLow  (m_symbol, m_period, shift + 2);
      double l1 = iLow  (m_symbol, m_period, shift + 1);
      double h1 = iHigh (m_symbol, m_period, shift + 1);
      double c0 = iClose(m_symbol, m_period, shift);
      double o0 = iOpen (m_symbol, m_period, shift);

      if(l1 >= l2) return false;     // bar-1 must be a lower low than bar-2
      if(c0 <= h1) return false;     // current closes ABOVE bar-1 high
      if(c0 <= o0) return false;     // current bullish
      // Require minimum bar-0 body to avoid trivial fires
      if(c0 - o0 < 0.5 * atr) return false;
      return true;
   }

   bool DetectThreeBarRevBear(int shift, double atr)
   {
      double h2 = iHigh (m_symbol, m_period, shift + 2);
      double h1 = iHigh (m_symbol, m_period, shift + 1);
      double l1 = iLow  (m_symbol, m_period, shift + 1);
      double c0 = iClose(m_symbol, m_period, shift);
      double o0 = iOpen (m_symbol, m_period, shift);

      if(h1 <= h2) return false;
      if(c0 >= l1) return false;
      if(c0 >= o0) return false;
      if(o0 - c0 < 0.5 * atr) return false;
      return true;
   }
};

#endif  // KMP_PATTERNS_J_MQH