//+------------------------------------------------------------------+
//|                                  KMP_PatternsP_Range.mqh       |
//|  CATEGORY P: RANGE / REVERSION (P166-P170)                       |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] John Murphy — "Technical Analysis of the Financial         |
//|      Markets" (1999). Pivot points + round number psychology.   |
//|  [2] Edwin Lefèvre — "Reminiscences of a Stock Operator" (1923).|
//|      Round numbers act as psychological barriers/magnets.       |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_P_MQH
#define KMP_PATTERNS_P_MQH

#include "../KMP_Structures.mqh"

class CRangeReversionPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_range_lookback;

public:
   CRangeReversionPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                               m_range_lookback(50) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int range_lb = 50) { m_range_lookback = range_lb; }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P166_Round_Number_Bounce_Long  = DetectRoundLong (shift, snap, atr);
      flags.P167_Round_Number_Bounce_Short = DetectRoundShort(shift, snap, atr);
      flags.P168_Daily_Pivot_Tag_Long      = DetectPivotTagLong (shift, snap, atr);
      flags.P169_Daily_Pivot_Tag_Short     = DetectPivotTagShort(shift, snap, atr);
      flags.P170_Range_Mid_Bounce          = DetectRangeMidBounce(shift, atr);
   }

private:
   //+---------------------------------------------------------------+
   //| P166 — Round Number Bounce Long                               |
   //|  snap.nearest_round = nearest round price (psychological)     |
   //|  snap.distance_to_round = distance in price                   |
   //|  Bounce: low touched within 0.2 ATR of round + bullish bar    |
   //+---------------------------------------------------------------+
   bool DetectRoundLong(int shift, const IndicatorSnapshot &snap, double atr)
   {
      if(snap.nearest_round <= 0) return false;
      double cur_low = iLow(m_symbol, m_period, shift);
      double dist = MathAbs(cur_low - snap.nearest_round);
      if(dist > 0.2 * atr) return false;
      if(cur_low > snap.nearest_round + 0.05 * atr) return false;  // didn't actually touch from above
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o) && (c > snap.nearest_round);  // close back above
   }

   bool DetectRoundShort(int shift, const IndicatorSnapshot &snap, double atr)
   {
      if(snap.nearest_round <= 0) return false;
      double cur_high = iHigh(m_symbol, m_period, shift);
      double dist = MathAbs(cur_high - snap.nearest_round);
      if(dist > 0.2 * atr) return false;
      if(cur_high < snap.nearest_round - 0.05 * atr) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o) && (c < snap.nearest_round);
   }

   //+---------------------------------------------------------------+
   //| P168/P169 — Daily Pivot Point Tag                             |
   //|  snap.pivot_pp = classical daily pivot                        |
   //+---------------------------------------------------------------+
   bool DetectPivotTagLong(int shift, const IndicatorSnapshot &snap, double atr)
   {
      if(snap.pivot_pp <= 0) return false;
      double cur_low = iLow(m_symbol, m_period, shift);
      double dist = MathAbs(cur_low - snap.pivot_pp);
      if(dist > 0.2 * atr) return false;
      if(cur_low > snap.pivot_pp + 0.1 * atr) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o) && (c > snap.pivot_pp);
   }

   bool DetectPivotTagShort(int shift, const IndicatorSnapshot &snap, double atr)
   {
      if(snap.pivot_pp <= 0) return false;
      double cur_high = iHigh(m_symbol, m_period, shift);
      double dist = MathAbs(cur_high - snap.pivot_pp);
      if(dist > 0.2 * atr) return false;
      if(cur_high < snap.pivot_pp - 0.1 * atr) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o) && (c < snap.pivot_pp);
   }

   //+---------------------------------------------------------------+
   //| P170 — Range Mid (50%) Bounce — BOTH dir                      |
   //|  Trading range over m_range_lookback. 50% mid acts as pivot.  |
   //+---------------------------------------------------------------+
   bool DetectRangeMidBounce(int shift, double atr)
   {
      double hi = iHigh(m_symbol, m_period, shift + 1);
      double lo = iLow (m_symbol, m_period, shift + 1);
      for(int i = 2; i <= m_range_lookback; i++)
      {
         double h = iHigh(m_symbol, m_period, shift + i);
         double l = iLow (m_symbol, m_period, shift + i);
         if(h > hi) hi = h;
         if(l < lo) lo = l;
      }
      double range = hi - lo;
      if(range < 1.0 * atr) return false;     // range too tight
      if(range > 8.0 * atr) return false;     // not really a range
      double mid = (hi + lo) / 2.0;
      double cur_low  = iLow (m_symbol, m_period, shift);
      double cur_high = iHigh(m_symbol, m_period, shift);
      double cur_close= iClose(m_symbol, m_period, shift);
      double cur_open = iOpen (m_symbol, m_period, shift);
      // Touched mid AND closed away from it
      bool touched = (cur_low <= mid + 0.2 * atr) && (cur_high >= mid - 0.2 * atr);
      if(!touched) return false;
      // Some directional bar (either bull or bear with body)
      double body = MathAbs(cur_close - cur_open);
      double r = cur_high - cur_low;
      if(r <= 0) return false;
      return body / r >= 0.5;
   }
};

#endif  // KMP_PATTERNS_P_MQH