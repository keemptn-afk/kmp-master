//+------------------------------------------------------------------+
//|                                                KMP_Patterns.mqh |
//|                              All 20 pattern detection functions  |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_MQH
#define KMP_PATTERNS_MQH

#include "../KMP_Structures.mqh"

//+------------------------------------------------------------------+
//| Pattern detection class                                          |
//+------------------------------------------------------------------+
class CPatternDetector
{
private:
   string   m_symbol;
   ENUM_TIMEFRAMES m_tf;
   
   // Configurable parameters
   double   m_wrb_multiplier;        // WRB threshold (1.5× avg)
   double   m_wick_pct_min;          // Min wick % of range (30%)
   double   m_body_pct_min;          // Min body % for confirmation (50%)
   int      m_multi_rej_min;         // Min rejections in zone (3)
   double   m_multi_rej_tolerance;   // Zone tolerance in points
   double   m_pin_wick_pct;          // Pin bar wick % (60%)
   int      m_swing_lookback;        // Bars for swing detection (20)
   double   m_round_step;            // Round number step
   
public:
   CPatternDetector() : m_symbol(""), m_tf(PERIOD_CURRENT)
   {
      m_wrb_multiplier = 1.5;
      m_wick_pct_min = 30.0;
      m_body_pct_min = 50.0;
      m_multi_rej_min = 3;
      m_multi_rej_tolerance = 5.0;  // points
      m_pin_wick_pct = 60.0;
      m_swing_lookback = 20;
      m_round_step = 5.0;
   }
   
   void Init(string symbol, ENUM_TIMEFRAMES tf)
   {
      m_symbol = symbol;
      m_tf = tf;
      
      // Auto-detect round step based on symbol
      if(StringFind(symbol, "BTC") >= 0) m_round_step = 100.0;
      else if(StringFind(symbol, "XAU") >= 0) m_round_step = 5.0;
      else m_round_step = 0.005;
      
      // Adjust multi-rejection tolerance based on point size
      m_multi_rej_tolerance = SymbolInfoDouble(symbol, SYMBOL_POINT) * 50;
      if(StringFind(symbol, "XAU") >= 0) m_multi_rej_tolerance = 0.5;  // 0.50 USD
      if(StringFind(symbol, "BTC") >= 0) m_multi_rej_tolerance = 50.0; // 50 USD
   }
   
   void SetParams(double wrb_mult, double wick_pct, double body_pct, 
                  int multi_rej, double pin_wick)
   {
      m_wrb_multiplier = wrb_mult;
      m_wick_pct_min = wick_pct;
      m_body_pct_min = body_pct;
      m_multi_rej_min = multi_rej;
      m_pin_wick_pct = pin_wick;
   }
   
   //+---------------------------------------------------------------+
   //| Main detection — checks all patterns                         |
   //+---------------------------------------------------------------+
   void DetectAll(int shift, PatternFlags &flags)
   {
      flags.Reset();
      
      // Price Action Patterns
      flags.P1_MultiRej_Long  = CheckP1_MultiRejLong(shift);
      flags.P2_MultiRej_Short = CheckP2_MultiRejShort(shift);
      flags.P3_WRB_Bull       = CheckP3_WRBBull(shift);
      flags.P4_WRB_Bear       = CheckP4_WRBBear(shift);
      flags.P5_Engulf_Trap_Bull = CheckP5_EngulfingTrapBull(shift);
      flags.P6_Engulf_Trap_Bear = CheckP6_EngulfingTrapBear(shift);
      flags.P7_PinBar         = CheckP7_PinBar(shift);
      flags.P8_TwoBar_Reversal = CheckP8_TwoBarReversal(shift);
      
      // Indicator-based — these will be set externally via SetIndicatorPatterns
      // because they need indicator handles
      
      // Count totals
      flags.total_count = 0;
      int dir_long = 0, dir_short = 0;
      
      if(flags.P1_MultiRej_Long) { flags.total_count++; dir_long++; }
      if(flags.P2_MultiRej_Short){ flags.total_count++; dir_short++; }
      if(flags.P3_WRB_Bull)      { flags.total_count++; dir_long++; }
      if(flags.P4_WRB_Bear)      { flags.total_count++; dir_short++; }
      if(flags.P5_Engulf_Trap_Bull) { flags.total_count++; dir_long++; }
      if(flags.P6_Engulf_Trap_Bear) { flags.total_count++; dir_short++; }
      if(flags.P7_PinBar)        { flags.total_count++; }  // direction inferred
      if(flags.P8_TwoBar_Reversal) { flags.total_count++; }
      
      flags.direction = (dir_long > dir_short) ? 1 : (dir_short > dir_long ? -1 : 0);
   }
   
   //+---------------------------------------------------------------+
   //| Set indicator-based pattern flags (called from main EA)      |
   //+---------------------------------------------------------------+
   void SetIndicatorPatterns(int shift, PatternFlags &flags, 
                              const IndicatorSnapshot &snap, 
                              const IndicatorSnapshot &prev_snap)
   {
      flags.P9_BB_Touch_Reversal = CheckP9_BBTouch(shift, snap);
      flags.P10_BB_Squeeze_Break = CheckP10_BBSqueezeBreak(shift, snap, prev_snap);
      flags.P11_EMA_Bounce       = CheckP11_EMABounce(shift, snap);
      flags.P12_EMA_Cross        = CheckP12_EMACross(shift, snap, prev_snap);
      flags.P13_RSI_Extreme_Rev  = CheckP13_RSIExtremeRev(shift, snap);
      flags.P14_RSI_Divergence   = (snap.rsi_divergence_bull || snap.rsi_divergence_bear);
      flags.P15_MACD_Zero_Cross  = CheckP15_MACDZeroCross(shift, snap, prev_snap);
      flags.P16_Stoch_Cross      = CheckP16_StochCross(shift, snap, prev_snap);
      flags.P17_Volume_Spike_Rev = CheckP17_VolumeSpike(shift, snap);
      flags.P18_Pivot_Bounce     = CheckP18_PivotBounce(shift, snap);
      flags.P19_Round_Number     = CheckP19_RoundNumber(shift, snap);
      flags.P20_Inside_Bar_Break = CheckP20_InsideBarBreak(shift);
      
      // Update totals
      if(flags.P9_BB_Touch_Reversal) flags.total_count++;
      if(flags.P10_BB_Squeeze_Break) flags.total_count++;
      if(flags.P11_EMA_Bounce) flags.total_count++;
      if(flags.P12_EMA_Cross) flags.total_count++;
      if(flags.P13_RSI_Extreme_Rev) flags.total_count++;
      if(flags.P14_RSI_Divergence) flags.total_count++;
      if(flags.P15_MACD_Zero_Cross) flags.total_count++;
      if(flags.P16_Stoch_Cross) flags.total_count++;
      if(flags.P17_Volume_Spike_Rev) flags.total_count++;
      if(flags.P18_Pivot_Bounce) flags.total_count++;
      if(flags.P19_Round_Number) flags.total_count++;
      if(flags.P20_Inside_Bar_Break) flags.total_count++;
   }
   
private:
   //+---------------------------------------------------------------+
   //| Helper: get bar data                                          |
   //+---------------------------------------------------------------+
   double Bar_Open(int shift)  { return iOpen(m_symbol, m_tf, shift); }
   double Bar_Close(int shift) { return iClose(m_symbol, m_tf, shift); }
   double Bar_High(int shift)  { return iHigh(m_symbol, m_tf, shift); }
   double Bar_Low(int shift)   { return iLow(m_symbol, m_tf, shift); }
   double Bar_Range(int shift) { return Bar_High(shift) - Bar_Low(shift); }
   double Bar_Body(int shift)  { return MathAbs(Bar_Close(shift) - Bar_Open(shift)); }
   double Bar_UpperWick(int shift) { return Bar_High(shift) - MathMax(Bar_Open(shift), Bar_Close(shift)); }
   double Bar_LowerWick(int shift) { return MathMin(Bar_Open(shift), Bar_Close(shift)) - Bar_Low(shift); }
   bool   Bar_IsBull(int shift) { return Bar_Close(shift) > Bar_Open(shift); }
   bool   Bar_IsBear(int shift) { return Bar_Close(shift) < Bar_Open(shift); }
   
   double AvgBody(int shift, int period)
   {
      double sum = 0;
      for(int i = shift + 1; i <= shift + period; i++)
         sum += Bar_Body(i);
      return sum / period;
   }
   
   double AvgRange(int shift, int period)
   {
      double sum = 0;
      for(int i = shift + 1; i <= shift + period; i++)
         sum += Bar_Range(i);
      return sum / period;
   }
   
   //+---------------------------------------------------------------+
   //| P1: Multi-Rejection Zone (Long)                              |
   //| 3+ candles touching same low ±tolerance, with lower wicks    |
   //| Confirmation: bullish candle closes above zone               |
   //+---------------------------------------------------------------+
   bool CheckP1_MultiRejLong(int shift)
   {
      // Current bar must be bullish confirmation
      if(!Bar_IsBull(shift)) return false;
      
      // Look back for cluster of lows
      double cluster_price = 0;
      int rejection_count = 0;
      
      // Try to find a cluster of lows within tolerance
      for(int anchor = shift + 1; anchor < shift + 15; anchor++)
      {
         double anchor_low = Bar_Low(anchor);
         double anchor_lower_wick = Bar_LowerWick(anchor);
         double anchor_range = Bar_Range(anchor);
         
         if(anchor_range == 0) continue;
         if((anchor_lower_wick / anchor_range) * 100.0 < m_wick_pct_min) continue;
         
         // Count similar lows within tolerance
         int count = 1;  // anchor itself
         for(int i = anchor + 1; i < shift + 20 && i < anchor + 10; i++)
         {
            double i_low = Bar_Low(i);
            double i_wick = Bar_LowerWick(i);
            double i_range = Bar_Range(i);
            
            if(i_range == 0) continue;
            if(MathAbs(i_low - anchor_low) <= m_multi_rej_tolerance &&
               (i_wick / i_range) * 100.0 >= m_wick_pct_min)
            {
               count++;
            }
         }
         
         if(count >= m_multi_rej_min)
         {
            cluster_price = anchor_low;
            rejection_count = count;
            break;
         }
      }
      
      if(rejection_count < m_multi_rej_min) return false;
      
      // Confirm: current bar close above the zone (above highest of cluster + tolerance)
      if(Bar_Close(shift) <= cluster_price + m_multi_rej_tolerance) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P2: Multi-Rejection Zone (Short)                             |
   //+---------------------------------------------------------------+
   bool CheckP2_MultiRejShort(int shift)
   {
      if(!Bar_IsBear(shift)) return false;
      
      double cluster_price = 0;
      int rejection_count = 0;
      
      for(int anchor = shift + 1; anchor < shift + 15; anchor++)
      {
         double anchor_high = Bar_High(anchor);
         double anchor_upper_wick = Bar_UpperWick(anchor);
         double anchor_range = Bar_Range(anchor);
         
         if(anchor_range == 0) continue;
         if((anchor_upper_wick / anchor_range) * 100.0 < m_wick_pct_min) continue;
         
         int count = 1;
         for(int i = anchor + 1; i < shift + 20 && i < anchor + 10; i++)
         {
            double i_high = Bar_High(i);
            double i_wick = Bar_UpperWick(i);
            double i_range = Bar_Range(i);
            
            if(i_range == 0) continue;
            if(MathAbs(i_high - anchor_high) <= m_multi_rej_tolerance &&
               (i_wick / i_range) * 100.0 >= m_wick_pct_min)
            {
               count++;
            }
         }
         
         if(count >= m_multi_rej_min)
         {
            cluster_price = anchor_high;
            rejection_count = count;
            break;
         }
      }
      
      if(rejection_count < m_multi_rej_min) return false;
      if(Bar_Close(shift) >= cluster_price - m_multi_rej_tolerance) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P3: WRB-Reversal Bullish                                     |
   //| Bar 1 (shift+2): WRB-bearish with lower wick rejection      |
   //| Bar 2 (shift+1): Bullish, body strong, total wick < Bar 1   |
   //| Entry at Bar 3 (shift)                                       |
   //+---------------------------------------------------------------+
   bool CheckP3_WRBBull(int shift)
   {
      double avg_body_20 = AvgBody(shift, 20);
      if(avg_body_20 == 0) return false;
      
      // Bar 1 — WRB bearish with lower wick
      int b1 = shift + 2;
      if(!Bar_IsBear(b1)) return false;
      
      double b1_range = Bar_Range(b1);
      double b1_body = Bar_Body(b1);
      double b1_lower_wick = Bar_LowerWick(b1);
      
      if(b1_body < m_wrb_multiplier * avg_body_20) return false;
      if(b1_range == 0) return false;
      if((b1_lower_wick / b1_range) * 100.0 < m_wick_pct_min) return false;
      
      // Bar 2 — bullish confirmation
      int b2 = shift + 1;
      if(!Bar_IsBull(b2)) return false;
      
      double b2_range = Bar_Range(b2);
      double b2_body = Bar_Body(b2);
      double b2_total_wick = Bar_UpperWick(b2) + Bar_LowerWick(b2);
      double b1_total_wick = Bar_UpperWick(b1) + b1_lower_wick;
      
      if(b2_total_wick >= b1_total_wick) return false;
      if(b2_range == 0) return false;
      if((b2_body / b2_range) * 100.0 < m_body_pct_min) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P4: WRB-Reversal Bearish                                     |
   //+---------------------------------------------------------------+
   bool CheckP4_WRBBear(int shift)
   {
      double avg_body_20 = AvgBody(shift, 20);
      if(avg_body_20 == 0) return false;
      
      int b1 = shift + 2;
      if(!Bar_IsBull(b1)) return false;
      
      double b1_range = Bar_Range(b1);
      double b1_body = Bar_Body(b1);
      double b1_upper_wick = Bar_UpperWick(b1);
      
      if(b1_body < m_wrb_multiplier * avg_body_20) return false;
      if(b1_range == 0) return false;
      if((b1_upper_wick / b1_range) * 100.0 < m_wick_pct_min) return false;
      
      int b2 = shift + 1;
      if(!Bar_IsBear(b2)) return false;
      
      double b2_range = Bar_Range(b2);
      double b2_body = Bar_Body(b2);
      double b2_total_wick = Bar_UpperWick(b2) + Bar_LowerWick(b2);
      double b1_total_wick = b1_upper_wick + Bar_LowerWick(b1);
      
      if(b2_total_wick >= b1_total_wick) return false;
      if(b2_range == 0) return false;
      if((b2_body / b2_range) * 100.0 < m_body_pct_min) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P5: Engulfing After Trap (Bullish)                           |
   //| Bar 1: Strong bearish move                                    |
   //| Bar 2: Bearish continuation but failed (wick > body, no LL)   |
   //| Bar 3: Bullish engulfing of Bar 2 body                        |
   //+---------------------------------------------------------------+
   bool CheckP5_EngulfingTrapBull(int shift)
   {
      int b1 = shift + 3;
      int b2 = shift + 2;
      int b3 = shift + 1;
      
      double avg_body = AvgBody(shift, 20);
      if(avg_body == 0) return false;
      
      // Bar 1: strong bearish (body > avg)
      if(!Bar_IsBear(b1)) return false;
      if(Bar_Body(b1) < avg_body) return false;
      
      // Bar 2: bearish but failed — lower wick > body, no new low after b1
      if(!Bar_IsBear(b2)) return false;
      double b2_lwick = Bar_LowerWick(b2);
      double b2_body = Bar_Body(b2);
      if(b2_lwick <= b2_body) return false;
      // No new low (actually higher low than b1)
      if(Bar_Low(b2) < Bar_Low(b1)) return false;
      
      // Bar 3: bullish engulfing of b2 body
      if(!Bar_IsBull(b3)) return false;
      if(Bar_Open(b3) > Bar_Close(b2)) return false;  // open at or below b2 close
      if(Bar_Close(b3) <= Bar_Open(b2)) return false; // close above b2 open
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P6: Engulfing After Trap (Bearish)                           |
   //+---------------------------------------------------------------+
   bool CheckP6_EngulfingTrapBear(int shift)
   {
      int b1 = shift + 3;
      int b2 = shift + 2;
      int b3 = shift + 1;
      
      double avg_body = AvgBody(shift, 20);
      if(avg_body == 0) return false;
      
      if(!Bar_IsBull(b1)) return false;
      if(Bar_Body(b1) < avg_body) return false;
      
      if(!Bar_IsBull(b2)) return false;
      double b2_uwick = Bar_UpperWick(b2);
      double b2_body = Bar_Body(b2);
      if(b2_uwick <= b2_body) return false;
      if(Bar_High(b2) > Bar_High(b1)) return false;
      
      if(!Bar_IsBear(b3)) return false;
      if(Bar_Open(b3) < Bar_Close(b2)) return false;
      if(Bar_Close(b3) >= Bar_Open(b2)) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P7: Pin Bar at Extreme                                        |
   //| One-sided wick ≥ pin_wick_pct, body ≤ 30% of range           |
   //| At swing high or swing low (last 20 bars)                    |
   //+---------------------------------------------------------------+
   bool CheckP7_PinBar(int shift)
   {
      // Check the bar before current (shift+1) since current is "entry" bar
      int b = shift + 1;
      
      double range = Bar_Range(b);
      if(range == 0) return false;
      
      double body = Bar_Body(b);
      double upper_wick = Bar_UpperWick(b);
      double lower_wick = Bar_LowerWick(b);
      
      double body_pct = (body / range) * 100.0;
      double upper_pct = (upper_wick / range) * 100.0;
      double lower_pct = (lower_wick / range) * 100.0;
      
      // Body must be small
      if(body_pct > 30.0) return false;
      
      // One wick must be dominant
      bool bullish_pin = (lower_pct >= m_pin_wick_pct);
      bool bearish_pin = (upper_pct >= m_pin_wick_pct);
      
      if(!bullish_pin && !bearish_pin) return false;
      
      // Must be at extreme — check swing position
      double bar_low = Bar_Low(b);
      double bar_high = Bar_High(b);
      
      if(bullish_pin)
      {
         // Check if this is lowest low in lookback
         double lowest = bar_low;
         for(int i = b + 1; i <= b + m_swing_lookback; i++)
         {
            if(Bar_Low(i) < lowest) return false;  // not the extreme
         }
         return true;
      }
      
      if(bearish_pin)
      {
         double highest = bar_high;
         for(int i = b + 1; i <= b + m_swing_lookback; i++)
         {
            if(Bar_High(i) > highest) return false;
         }
         return true;
      }
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P8: Two-Bar Strict Reversal                                   |
   //| Like P3/P4 but stricter: simpler 2-bar pattern                |
   //+---------------------------------------------------------------+
   bool CheckP8_TwoBarReversal(int shift)
   {
      int b1 = shift + 2;
      int b2 = shift + 1;
      
      double r1 = Bar_Range(b1);
      double r2 = Bar_Range(b2);
      if(r1 == 0 || r2 == 0) return false;
      
      // Bar 1: any color with significant wick (≥30%) on one side
      double b1_uwick_pct = (Bar_UpperWick(b1) / r1) * 100.0;
      double b1_lwick_pct = (Bar_LowerWick(b1) / r1) * 100.0;
      
      bool b1_has_wick = (b1_uwick_pct >= m_wick_pct_min || b1_lwick_pct >= m_wick_pct_min);
      if(!b1_has_wick) return false;
      
      // Bar 2: opposite color, total wick < bar 1 total wick
      bool b1_bull = Bar_IsBull(b1);
      bool b2_bull = Bar_IsBull(b2);
      if(b1_bull == b2_bull) return false;  // must be opposite colors
      
      double b1_total_wick = Bar_UpperWick(b1) + Bar_LowerWick(b1);
      double b2_total_wick = Bar_UpperWick(b2) + Bar_LowerWick(b2);
      
      if(b2_total_wick >= b1_total_wick) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P9: BB Touch + Reversal                                       |
   //+---------------------------------------------------------------+
   bool CheckP9_BBTouch(int shift, const IndicatorSnapshot &snap)
   {
      int b = shift + 1;  // previous bar
      double low = Bar_Low(b);
      double high = Bar_High(b);
      double close = Bar_Close(b);
      
      // Touched lower band and bullish reversal
      if(low <= snap.bb_lower && close > snap.bb_lower && Bar_IsBull(b))
         return true;
      
      // Touched upper band and bearish reversal
      if(high >= snap.bb_upper && close < snap.bb_upper && Bar_IsBear(b))
         return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P10: BB Squeeze Breakout                                      |
   //+---------------------------------------------------------------+
   bool CheckP10_BBSqueezeBreak(int shift, const IndicatorSnapshot &snap, 
                                  const IndicatorSnapshot &prev_snap)
   {
      // Was in squeeze previously
      if(!prev_snap.bb_squeeze) return false;
      
      // Now expanding
      if(snap.bb_width_ratio < 1.0) return false;
      
      // Current bar closes outside band
      double close = Bar_Close(shift);
      if(close > snap.bb_upper || close < snap.bb_lower) return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P11: EMA Bounce                                               |
   //+---------------------------------------------------------------+
   bool CheckP11_EMABounce(int shift, const IndicatorSnapshot &snap)
   {
      int b = shift + 1;
      double low = Bar_Low(b);
      double high = Bar_High(b);
      double close = Bar_Close(b);
      double tolerance = snap.atr_14 * 0.3;
      
      // Bullish bounce off EMA50 or EMA200
      if(Bar_IsBull(b))
      {
         if(MathAbs(low - snap.ema_50) < tolerance && close > snap.ema_50) return true;
         if(MathAbs(low - snap.ema_200) < tolerance && close > snap.ema_200) return true;
      }
      
      // Bearish bounce
      if(Bar_IsBear(b))
      {
         if(MathAbs(high - snap.ema_50) < tolerance && close < snap.ema_50) return true;
         if(MathAbs(high - snap.ema_200) < tolerance && close < snap.ema_200) return true;
      }
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P12: EMA Cross                                                |
   //+---------------------------------------------------------------+
   bool CheckP12_EMACross(int shift, const IndicatorSnapshot &snap, 
                          const IndicatorSnapshot &prev_snap)
   {
      // EMA9 cross EMA20
      bool cross_up_9_20 = (prev_snap.ema_9 <= prev_snap.ema_20 && snap.ema_9 > snap.ema_20);
      bool cross_dn_9_20 = (prev_snap.ema_9 >= prev_snap.ema_20 && snap.ema_9 < snap.ema_20);
      
      // EMA20 cross EMA50
      bool cross_up_20_50 = (prev_snap.ema_20 <= prev_snap.ema_50 && snap.ema_20 > snap.ema_50);
      bool cross_dn_20_50 = (prev_snap.ema_20 >= prev_snap.ema_50 && snap.ema_20 < snap.ema_50);
      
      return (cross_up_9_20 || cross_dn_9_20 || cross_up_20_50 || cross_dn_20_50);
   }
   
   //+---------------------------------------------------------------+
   //| P13: RSI Extreme + Reversal                                   |
   //+---------------------------------------------------------------+
   bool CheckP13_RSIExtremeRev(int shift, const IndicatorSnapshot &snap)
   {
      int b = shift + 1;
      
      // Oversold + bullish reversal
      if(snap.rsi_14 < 30 && Bar_IsBull(b)) return true;
      
      // Overbought + bearish reversal
      if(snap.rsi_14 > 70 && Bar_IsBear(b)) return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P15: MACD Zero Cross                                          |
   //+---------------------------------------------------------------+
   bool CheckP15_MACDZeroCross(int shift, const IndicatorSnapshot &snap, 
                                const IndicatorSnapshot &prev_snap)
   {
      bool cross_up = (prev_snap.macd_main <= 0 && snap.macd_main > 0);
      bool cross_dn = (prev_snap.macd_main >= 0 && snap.macd_main < 0);
      return (cross_up || cross_dn);
   }
   
   //+---------------------------------------------------------------+
   //| P16: Stochastic Cross in OB/OS                                |
   //+---------------------------------------------------------------+
   bool CheckP16_StochCross(int shift, const IndicatorSnapshot &snap, 
                             const IndicatorSnapshot &prev_snap)
   {
      bool cross_up = (prev_snap.stoch_k <= prev_snap.stoch_d && snap.stoch_k > snap.stoch_d);
      bool cross_dn = (prev_snap.stoch_k >= prev_snap.stoch_d && snap.stoch_k < snap.stoch_d);
      
      // In oversold zone
      if(cross_up && snap.stoch_k < 30) return true;
      
      // In overbought zone
      if(cross_dn && snap.stoch_k > 70) return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P17: Volume Spike Reversal                                    |
   //+---------------------------------------------------------------+
   bool CheckP17_VolumeSpike(int shift, const IndicatorSnapshot &snap)
   {
      if(!snap.volume_spike) return false;
      
      int b = shift + 1;
      double range = Bar_Range(b);
      double body = Bar_Body(b);
      
      if(range == 0) return false;
      
      // Volume spike + strong reversal candle (large body)
      if((body / range) * 100.0 > 60.0) return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P18: Pivot Bounce                                             |
   //+---------------------------------------------------------------+
   bool CheckP18_PivotBounce(int shift, const IndicatorSnapshot &snap)
   {
      int b = shift + 1;
      double low = Bar_Low(b);
      double high = Bar_High(b);
      double close = Bar_Close(b);
      double tolerance = snap.atr_14 * 0.3;
      
      double pivots[3];
      pivots[0] = snap.pivot_pp;
      pivots[1] = snap.pivot_r1;
      pivots[2] = snap.pivot_s1;
      
      for(int i = 0; i < 3; i++)
      {
         if(pivots[i] == 0) continue;
         
         // Bullish bounce off pivot
         if(MathAbs(low - pivots[i]) < tolerance && close > pivots[i] && Bar_IsBull(b)) return true;
         
         // Bearish rejection at pivot
         if(MathAbs(high - pivots[i]) < tolerance && close < pivots[i] && Bar_IsBear(b)) return true;
      }
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P19: Round Number Bounce                                      |
   //+---------------------------------------------------------------+
   bool CheckP19_RoundNumber(int shift, const IndicatorSnapshot &snap)
   {
      int b = shift + 1;
      double tolerance = m_round_step * 0.1;
      if(snap.distance_to_round > tolerance) return false;
      
      double range = Bar_Range(b);
      if(range == 0) return false;
      
      double low = Bar_Low(b);
      double high = Bar_High(b);
      double close = Bar_Close(b);
      
      // Bullish bounce
      if(low <= snap.nearest_round && close > snap.nearest_round && Bar_IsBull(b)) return true;
      
      // Bearish rejection
      if(high >= snap.nearest_round && close < snap.nearest_round && Bar_IsBear(b)) return true;
      
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P20: Inside Bar Breakout                                      |
   //+---------------------------------------------------------------+
   bool CheckP20_InsideBarBreak(int shift)
   {
      int mother = shift + 2;
      int inside = shift + 1;
      int curr = shift;
      
      // Inside bar: high < mother high AND low > mother low
      if(Bar_High(inside) >= Bar_High(mother)) return false;
      if(Bar_Low(inside) <= Bar_Low(mother)) return false;
      
      // Current bar breaks above or below inside bar range
      double curr_close = Bar_Close(curr);
      
      bool break_up = (curr_close > Bar_High(inside));
      bool break_dn = (curr_close < Bar_Low(inside));
      
      return (break_up || break_dn);
   }
};

#endif  // KMP_PATTERNS_MQH
//+------------------------------------------------------------------+