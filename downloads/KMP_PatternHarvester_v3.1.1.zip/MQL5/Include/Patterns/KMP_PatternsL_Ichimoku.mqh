//+------------------------------------------------------------------+
//|                                  KMP_PatternsL_Ichimoku.mqh    |
//|  CATEGORY L: ICHIMOKU SYSTEM (P136-P142)                        |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Goichi Hosoda — "Ichimoku Kinko Hyo" (1968).                |
//|  [2] Patel, Yang, Patel — "Forecasting BSE-30 daily index using |
//|      Ichimoku Kinko Hyo and SVM" (2015) — academic validation. |
//|                                                                  |
//|  Ichimoku components (from snap.ichimoku_*):                    |
//|    Tenkan = (HH9 + LL9) / 2  — short-term momentum               |
//|    Kijun  = (HH26 + LL26) / 2 — medium-term equilibrium         |
//|    Senkou A = (Tenkan + Kijun) / 2, projected forward 26        |
//|    Senkou B = (HH52 + LL52) / 2, projected forward 26           |
//|    Chikou = current close, plotted 26 bars in the past          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_L_MQH
#define KMP_PATTERNS_L_MQH

#include "../KMP_Structures.mqh"

class CIchimokuPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

public:
   CIchimokuPatterns() : m_symbol(""), m_period(PERIOD_CURRENT) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      if(snap.ichimoku_tenkan == 0 || snap.ichimoku_kijun == 0) return;

      flags.P136_Ichimoku_TK_Cross_Bull    = DetectTKCrossBull(shift);
      flags.P137_Ichimoku_TK_Cross_Bear    = DetectTKCrossBear(shift);
      flags.P138_Ichimoku_Cloud_Break_Bull = DetectCloudBreakBull(shift, snap);
      flags.P139_Ichimoku_Cloud_Break_Bear = DetectCloudBreakBear(shift, snap);
      flags.P140_Ichimoku_Kumo_Twist_Bull  = DetectKumoTwistBull(snap);
      flags.P141_Ichimoku_Kumo_Twist_Bear  = DetectKumoTwistBear(snap);
      flags.P142_Ichimoku_Chikou_Confirm   = DetectChikouConfirm(shift, snap);
   }

private:
   //+---------------------------------------------------------------+
   //| P136 — TK Cross Bull: Tenkan crosses ABOVE Kijun this bar    |
   //+---------------------------------------------------------------+
   bool DetectTKCrossBull(int shift)
   {
      // We need previous bar's Tenkan/Kijun — read directly from indicator
      // via iIchimoku — but it's already captured in snap for this bar.
      // For simplicity, approximate using HH/LL formula directly:
      double t_now  = TenkanAt(shift);
      double k_now  = KijunAt(shift);
      double t_prev = TenkanAt(shift + 1);
      double k_prev = KijunAt(shift + 1);
      return (t_prev <= k_prev) && (t_now > k_now);
   }
   bool DetectTKCrossBear(int shift)
   {
      double t_now  = TenkanAt(shift);
      double k_now  = KijunAt(shift);
      double t_prev = TenkanAt(shift + 1);
      double k_prev = KijunAt(shift + 1);
      return (t_prev >= k_prev) && (t_now < k_now);
   }

   double TenkanAt(int shift)
   {
      // (HH9 + LL9) / 2 ending at shift
      double hh = iHigh(m_symbol, m_period, shift);
      double ll = iLow (m_symbol, m_period, shift);
      for(int i = 1; i < 9; i++)
      {
         double h = iHigh(m_symbol, m_period, shift + i);
         double l = iLow (m_symbol, m_period, shift + i);
         if(h > hh) hh = h;
         if(l < ll) ll = l;
      }
      return (hh + ll) / 2.0;
   }
   double KijunAt(int shift)
   {
      double hh = iHigh(m_symbol, m_period, shift);
      double ll = iLow (m_symbol, m_period, shift);
      for(int i = 1; i < 26; i++)
      {
         double h = iHigh(m_symbol, m_period, shift + i);
         double l = iLow (m_symbol, m_period, shift + i);
         if(h > hh) hh = h;
         if(l < ll) ll = l;
      }
      return (hh + ll) / 2.0;
   }

   //+---------------------------------------------------------------+
   //| P138 — Cloud Break Bull: close above max(SenkouA, SenkouB)   |
   //|  AND prev bar was inside or below cloud.                      |
   //+---------------------------------------------------------------+
   bool DetectCloudBreakBull(int shift, const IndicatorSnapshot &snap)
   {
      double cloud_top    = MathMax(snap.ichimoku_senkou_a, snap.ichimoku_senkou_b);
      double cur_close = iClose(m_symbol, m_period, shift);
      double prev_close = iClose(m_symbol, m_period, shift + 1);
      if(cur_close <= cloud_top) return false;
      if(prev_close > cloud_top) return false;  // need fresh break
      // require bullish bar
      double o = iOpen(m_symbol, m_period, shift);
      return (cur_close > o);
   }

   bool DetectCloudBreakBear(int shift, const IndicatorSnapshot &snap)
   {
      double cloud_top    = MathMax(snap.ichimoku_senkou_a, snap.ichimoku_senkou_b);
      double cloud_bottom = MathMin(snap.ichimoku_senkou_a, snap.ichimoku_senkou_b);
      double cur_close = iClose(m_symbol, m_period, shift);
      double prev_close = iClose(m_symbol, m_period, shift + 1);
      if(cur_close >= cloud_bottom) return false;
      if(prev_close < cloud_bottom) return false;
      double o = iOpen(m_symbol, m_period, shift);
      return (cur_close < o);
   }

   //+---------------------------------------------------------------+
   //| P140 — Kumo Twist Bull: future SenkouA crosses ABOVE SenkouB |
   //+---------------------------------------------------------------+
   bool DetectKumoTwistBull(const IndicatorSnapshot &snap)
   {
      // Future cloud (projected from current bar): A > B = bullish cloud
      // We read SenkouA/B at shift = "future" snapshot (as captured in snap)
      if(snap.ichimoku_future_a == 0 || snap.ichimoku_future_b == 0) return false;
      // For "twist" need to confirm crossover happened — compare with current
      // (non-future) cloud which is the past
      bool future_bull = snap.ichimoku_future_a > snap.ichimoku_future_b;
      bool past_bull   = snap.ichimoku_senkou_a > snap.ichimoku_senkou_b;
      return future_bull && !past_bull;
   }
   bool DetectKumoTwistBear(const IndicatorSnapshot &snap)
   {
      if(snap.ichimoku_future_a == 0 || snap.ichimoku_future_b == 0) return false;
      bool future_bear = snap.ichimoku_future_a < snap.ichimoku_future_b;
      bool past_bear   = snap.ichimoku_senkou_a < snap.ichimoku_senkou_b;
      return future_bear && !past_bear;
   }

   //+---------------------------------------------------------------+
   //| P142 — Chikou Confirm (BOTH dir)                               |
   //|  Chikou span = current close shifted back 26 bars              |
   //|  "Clear space" = above all prior bar highs (bull) or below     |
   //|  all prior lows (bear) within +/-26 window.                    |
   //+---------------------------------------------------------------+
   bool DetectChikouConfirm(int shift, const IndicatorSnapshot &snap)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      // Chikou is plotted at shift+26 (i.e., the close 26 bars ago corresponds
      // to current price plotted there). For "clear space" check, compare
      // current close vs price action AROUND shift+26.
      double max_h = 0, min_l = 0;
      bool init = false;
      for(int i = shift + 22; i <= shift + 30; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow (m_symbol, m_period, i);
         if(!init) { max_h = h; min_l = l; init = true; }
         if(h > max_h) max_h = h;
         if(l < min_l) min_l = l;
      }
      // Clear space = current close strongly above max_h OR strongly below min_l
      double atr = snap.atr_14;
      if(cur_close > max_h + 0.5 * atr) return true;
      if(cur_close < min_l - 0.5 * atr) return true;
      return false;
   }
};

#endif  // KMP_PATTERNS_L_MQH