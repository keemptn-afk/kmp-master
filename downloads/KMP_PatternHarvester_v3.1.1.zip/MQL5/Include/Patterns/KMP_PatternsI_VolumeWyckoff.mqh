//+------------------------------------------------------------------+
//|                              KMP_PatternsI_VolumeWyckoff.mqh    |
//|                                                                  |
//|  CATEGORY I: VOLUME / WYCKOFF / VSA (P98-P107)                   |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Tom Williams — "Master the Markets" (1993). Volume Spread  |
//|      Analysis (VSA) framework: No Demand, No Supply, Stopping   |
//|      Volume, Climactic Volume.                                   |
//|  [2] Richard Wyckoff — "The Richard D. Wyckoff Method of        |
//|      Trading and Investing in Stocks" (1934). Spring/Upthrust   |
//|      tests of the trading range.                                 |
//|  [3] Bookmap / Order-flow research — CVD (Cumulative Volume     |
//|      Delta) divergences. We approximate CVD using directional   |
//|      tick volume (bull bars contribute +V, bear bars -V) since  |
//|      true tick-buy/sell delta is not available in MT5 history. |
//|                                                                  |
//|  All volume references in MT5 are TICK volume (not real volume).|
//|  This is acceptable for FX / crypto / metals on Exness because  |
//|  tick volume strongly correlates with traded contracts.          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_I_MQH
#define KMP_PATTERNS_I_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CVolumeWyckoffPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

   int    m_lookback_bars;
   double m_climax_vol_ratio;       // tick volume vs MA20 to count as climax (default 2.5)
   double m_low_vol_ratio;          // for No-Demand/No-Supply (default 0.6)
   double m_climax_range_atr;       // bar range >= this * ATR for climax (default 2.0)
   int    m_range_lookback;         // Wyckoff trading-range bars (default 30)
   double m_range_max_atr;          // trading-range max width (default 3.0 * ATR)
   int    m_div_lookback;           // CVD divergence swing window (default 30)

public:
   CVolumeWyckoffPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                              m_lookback_bars(50),
                              m_climax_vol_ratio(2.5),
                              m_low_vol_ratio(0.6),
                              m_climax_range_atr(2.0),
                              m_range_lookback(30),
                              m_range_max_atr(3.0),
                              m_div_lookback(30) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int lookback = 50, double climax_vol = 2.5, double low_vol = 0.6,
                  double climax_range = 2.0, int range_lb = 30, double range_max = 3.0,
                  int div_lb = 30)
   {
      m_lookback_bars     = lookback;
      m_climax_vol_ratio  = climax_vol;
      m_low_vol_ratio     = low_vol;
      m_climax_range_atr  = climax_range;
      m_range_lookback    = range_lb;
      m_range_max_atr     = range_max;
      m_div_lookback      = div_lb;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P98_VSA_NoDemand            = DetectNoDemand(shift, snap, atr);
      flags.P99_VSA_NoSupply            = DetectNoSupply(shift, snap, atr);
      flags.P100_VSA_StoppingVol_Bull   = DetectStoppingVolumeBull(shift, snap, atr);
      flags.P101_VSA_ClimacticVol_Bear  = DetectClimacticVolumeBear(shift, snap, atr);
      flags.P102_Wyckoff_Spring         = DetectWyckoffSpring(shift, atr);
      flags.P103_Wyckoff_Upthrust       = DetectWyckoffUpthrust(shift, atr);
      flags.P104_SellingClimax          = DetectSellingClimax(shift, snap, atr);
      flags.P105_BuyingClimax           = DetectBuyingClimax(shift, snap, atr);
      flags.P106_CVD_Div_Bull           = DetectCVDDivBull(shift);
      flags.P107_CVD_Div_Bear           = DetectCVDDivBear(shift);
   }

private:
   //+---------------------------------------------------------------+
   //| Helpers                                                        |
   //+---------------------------------------------------------------+
   double AvgRangeLocal(int shift, int n)
   {
      double sum = 0;
      int count = 0;
      for(int i = shift + 1; i <= shift + n; i++)
      {
         sum += (iHigh(m_symbol, m_period, i) - iLow(m_symbol, m_period, i));
         count++;
      }
      return count > 0 ? sum / count : 0;
   }

   //+---------------------------------------------------------------+
   //| P98 — VSA NO DEMAND                                           |
   //|                                                                |
   //|  Theory (Williams VSA): An UP bar with NARROW spread and LOW  |
   //|  volume in an uptrend = lack of buying interest at higher    |
   //|  prices. Bearish — bull move likely to fail.                  |
   //|                                                                |
   //|  Detection:                                                    |
   //|   - Current bar is bullish (close > open)                      |
   //|   - Range < 60% of avg range                                   |
   //|   - Tick volume ratio < m_low_vol_ratio                        |
   //|   - Prior trend is up (close[shift+1] > close[shift+5])        |
   //+---------------------------------------------------------------+
   bool DetectNoDemand(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close <= cur_open) return false;

      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      double avg_range = AvgRangeLocal(shift, 20);
      if(avg_range <= 0) return false;
      if(range > 0.6 * avg_range) return false;

      // Volume ratio is computed in snap relative to its 20-bar MA at shift.
      if(snap.volume_ratio >= m_low_vol_ratio) return false;

      // Prior trend up
      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 <= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P99 — VSA NO SUPPLY                                           |
   //|                                                                |
   //|  Mirror of No Demand: a DOWN bar with NARROW spread and LOW   |
   //|  volume in a downtrend = lack of selling pressure. Bullish.   |
   //+---------------------------------------------------------------+
   bool DetectNoSupply(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close >= cur_open) return false;

      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      double avg_range = AvgRangeLocal(shift, 20);
      if(avg_range <= 0) return false;
      if(range > 0.6 * avg_range) return false;

      if(snap.volume_ratio >= m_low_vol_ratio) return false;

      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 >= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P100 — STOPPING VOLUME BULL                                   |
   //|                                                                |
   //|  Theory (Williams): A DOWN bar with VERY HIGH volume but a    |
   //|  closing price NEAR the high — institutional absorption of   |
   //|  selling. Bullish reversal signal.                             |
   //|                                                                |
   //|  Detection:                                                    |
   //|   - Bar is bearish (close < open)                              |
   //|   - Volume ratio >= m_climax_vol_ratio                         |
   //|   - Close in upper third of bar range                          |
   //|   - Prior trend down                                            |
   //+---------------------------------------------------------------+
   bool DetectStoppingVolumeBull(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double cur_high  = iHigh(m_symbol, m_period, shift);
      double cur_low   = iLow(m_symbol, m_period, shift);

      if(cur_close >= cur_open) return false;
      if(snap.volume_ratio < m_climax_vol_ratio) return false;

      double range = cur_high - cur_low;
      if(range <= 0) return false;
      double close_pos = (cur_close - cur_low) / range;
      if(close_pos < 0.66) return false;  // close not near high

      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 >= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P101 — CLIMACTIC VOLUME BEAR                                  |
   //|                                                                |
   //|  An UP bar with EXTREME volume and close near the low — sign  |
   //|  of distribution / smart money exiting. Bearish reversal.     |
   //+---------------------------------------------------------------+
   bool DetectClimacticVolumeBear(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double cur_high  = iHigh(m_symbol, m_period, shift);
      double cur_low   = iLow(m_symbol, m_period, shift);

      if(cur_close <= cur_open) return false;
      if(snap.volume_ratio < m_climax_vol_ratio) return false;

      double range = cur_high - cur_low;
      if(range <= 0) return false;
      double close_pos = (cur_close - cur_low) / range;
      if(close_pos > 0.34) return false;  // close not near low

      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 <= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P102 — WYCKOFF SPRING                                          |
   //|                                                                |
   //|  Theory (Wyckoff): Within an established trading range, price |
   //|  briefly breaks BELOW support, then snaps back into the range.|
   //|  Confirms accumulation — bullish.                              |
   //|                                                                |
   //|  Detection:                                                    |
   //|   1. Trading range over last m_range_lookback bars where     |
   //|      (range_high - range_low) <= m_range_max_atr * ATR.       |
   //|   2. In last 5 bars, price made a low BELOW range_low - 0.2*ATR
   //|   3. Current bar closes BACK INSIDE the range (close > range_low)
   //+---------------------------------------------------------------+
   bool DetectWyckoffSpring(int shift, double atr)
   {
      int rs = shift + 6;
      int re = shift + m_range_lookback;
      if(re >= shift + 200) return false;

      double range_high = iHigh(m_symbol, m_period, rs);
      double range_low  = iLow(m_symbol, m_period, rs);
      for(int i = rs + 1; i <= re; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow(m_symbol, m_period, i);
         if(h > range_high) range_high = h;
         if(l < range_low)  range_low  = l;
      }
      if(range_high - range_low > m_range_max_atr * atr) return false;
      if(range_high - range_low < 0.5 * atr) return false;  // too tight, not a real range

      // Sweep below support in last 5 bars
      bool sprung = false;
      for(int j = shift + 1; j <= shift + 5; j++)
      {
         if(iLow(m_symbol, m_period, j) < range_low - 0.2 * atr) { sprung = true; break; }
      }
      if(!sprung) return false;

      // Current closes back inside range
      double cur_close = iClose(m_symbol, m_period, shift);
      return (cur_close > range_low);
   }

   //+---------------------------------------------------------------+
   //| P103 — WYCKOFF UPTHRUST                                        |
   //|                                                                |
   //|  Mirror of Spring: brief break ABOVE resistance, then snap    |
   //|  back into range. Confirms distribution — bearish.            |
   //+---------------------------------------------------------------+
   bool DetectWyckoffUpthrust(int shift, double atr)
   {
      int rs = shift + 6;
      int re = shift + m_range_lookback;
      if(re >= shift + 200) return false;

      double range_high = iHigh(m_symbol, m_period, rs);
      double range_low  = iLow(m_symbol, m_period, rs);
      for(int i = rs + 1; i <= re; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow(m_symbol, m_period, i);
         if(h > range_high) range_high = h;
         if(l < range_low)  range_low  = l;
      }
      if(range_high - range_low > m_range_max_atr * atr) return false;
      if(range_high - range_low < 0.5 * atr) return false;

      bool thrust = false;
      for(int j = shift + 1; j <= shift + 5; j++)
      {
         if(iHigh(m_symbol, m_period, j) > range_high + 0.2 * atr) { thrust = true; break; }
      }
      if(!thrust) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      return (cur_close < range_high);
   }

   //+---------------------------------------------------------------+
   //| P104 — SELLING CLIMAX                                          |
   //|                                                                |
   //|  Theory: Extreme down move on extreme volume. Often marks    |
   //|  capitulation — bullish reversal candidate (long).            |
   //|                                                                |
   //|  Detection:                                                    |
   //|   - Bar is bearish                                             |
   //|   - Range >= m_climax_range_atr * ATR                          |
   //|   - Volume ratio >= m_climax_vol_ratio                         |
   //|   - Recent decline (close[1] < close[5])                       |
   //+---------------------------------------------------------------+
   bool DetectSellingClimax(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double cur_high  = iHigh(m_symbol, m_period, shift);
      double cur_low   = iLow(m_symbol, m_period, shift);

      if(cur_close >= cur_open) return false;

      double range = cur_high - cur_low;
      if(range < m_climax_range_atr * atr) return false;
      if(snap.volume_ratio < m_climax_vol_ratio) return false;

      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 >= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P105 — BUYING CLIMAX                                           |
   //+---------------------------------------------------------------+
   bool DetectBuyingClimax(int shift, const IndicatorSnapshot &snap, double atr)
   {
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double cur_high  = iHigh(m_symbol, m_period, shift);
      double cur_low   = iLow(m_symbol, m_period, shift);

      if(cur_close <= cur_open) return false;

      double range = cur_high - cur_low;
      if(range < m_climax_range_atr * atr) return false;
      if(snap.volume_ratio < m_climax_vol_ratio) return false;

      double c1 = iClose(m_symbol, m_period, shift + 1);
      double c5 = iClose(m_symbol, m_period, shift + 5);
      if(c1 <= c5) return false;

      return true;
   }

   //+---------------------------------------------------------------+
   //| P106 — CVD DIVERGENCE BULL (approximated)                     |
   //|                                                                |
   //|  Theory: True CVD requires bid/ask delta. We approximate as: |
   //|    For each bar i: signed_vol[i] = +tick_vol if bull, else -. |
   //|    Cumulative CVD over a window forms a series.               |
   //|                                                                |
   //|  Bullish divergence: price makes a LOWER low between two      |
   //|  swing lows, but cumulative-signed-volume between those lows  |
   //|  makes a HIGHER low (selling pressure waning).                 |
   //|                                                                |
   //|  Simplified detection: find two recent swing lows; sum of     |
   //|  signed-tick-volume in the window of the SECOND low > sum in |
   //|  the window of the FIRST low (less aggregate selling).        |
   //+---------------------------------------------------------------+
   bool DetectCVDDivBull(int shift)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_div_lookback, 3, 3);
      if(sl2 < 0) return false;

      double l1 = iLow(m_symbol, m_period, sl1);  // newer
      double l2 = iLow(m_symbol, m_period, sl2);  // older
      // Bullish div: newer low LOWER than older low
      if(l1 >= l2) return false;

      // Sum signed tick volume in 5-bar window around each low
      double sum1 = 0, sum2 = 0;
      for(int k = -2; k <= 2; k++)
      {
         int idx1 = sl1 + k;
         int idx2 = sl2 + k;
         if(idx1 >= 1 && idx1 < shift + 200)
         {
            long v = iTickVolume(m_symbol, m_period, idx1);
            double o = iOpen(m_symbol, m_period, idx1);
            double c = iClose(m_symbol, m_period, idx1);
            sum1 += (c >= o ? (double)v : -(double)v);
         }
         if(idx2 >= 1 && idx2 < shift + 200)
         {
            long v = iTickVolume(m_symbol, m_period, idx2);
            double o = iOpen(m_symbol, m_period, idx2);
            double c = iClose(m_symbol, m_period, idx2);
            sum2 += (c >= o ? (double)v : -(double)v);
         }
      }
      // Newer low has higher signed volume = less aggressive selling
      if(sum1 <= sum2) return false;

      // Confirm with bullish current bar
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P107 — CVD DIVERGENCE BEAR (approximated)                     |
   //+---------------------------------------------------------------+
   bool DetectCVDDivBear(int shift)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_div_lookback, 3, 3);
      if(sh2 < 0) return false;

      double h1 = iHigh(m_symbol, m_period, sh1);
      double h2 = iHigh(m_symbol, m_period, sh2);
      if(h1 <= h2) return false;  // newer high higher than older

      double sum1 = 0, sum2 = 0;
      for(int k = -2; k <= 2; k++)
      {
         int idx1 = sh1 + k;
         int idx2 = sh2 + k;
         if(idx1 >= 1 && idx1 < shift + 200)
         {
            long v = iTickVolume(m_symbol, m_period, idx1);
            double o = iOpen(m_symbol, m_period, idx1);
            double c = iClose(m_symbol, m_period, idx1);
            sum1 += (c >= o ? (double)v : -(double)v);
         }
         if(idx2 >= 1 && idx2 < shift + 200)
         {
            long v = iTickVolume(m_symbol, m_period, idx2);
            double o = iOpen(m_symbol, m_period, idx2);
            double c = iClose(m_symbol, m_period, idx2);
            sum2 += (c >= o ? (double)v : -(double)v);
         }
      }
      // Newer high has LOWER signed volume = less aggressive buying
      if(sum1 >= sum2) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (cur_close < cur_open);
   }
};

#endif  // KMP_PATTERNS_I_MQH