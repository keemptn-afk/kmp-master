//+------------------------------------------------------------------+
//|                                  KMP_PatternsH_SMCAdvanced.mqh  |
//|                                                                  |
//|  CATEGORY H: SMART MONEY CONCEPTS — ADVANCED (P89-P97)           |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] ICT (Inner Circle Trader / Michael J. Huddleston) —         |
//|      Optimal Trade Entry, Killzones, Power of 3, PD Array.       |
//|      ICT video curriculum.                                       |
//|                                                                  |
//|  These are time-of-day & retracement-based concepts. Less        |
//|  academically validated than classical TA but widely applied in  |
//|  retail SMC communities. Treat statistical edge with caution.    |
//|                                                                  |
//|  Time conventions: hour_of_day from snapshot is BROKER time      |
//|  (typically GMT+2 / GMT+3). For Exness Pro that means London    |
//|  Killzone of 07:00-10:00 GMT corresponds roughly to 09:00-12:00 |
//|  broker hours, and NY Silver Bullet 14:00-15:00 GMT corresponds |
//|  to 16:00-17:00 broker hours. We use BROKER hours directly to   |
//|  match the harvester data; downstream analysis can shift if      |
//|  needed.                                                          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_H_MQH
#define KMP_PATTERNS_H_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CSMCAdvancedPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

   int    m_lookback_bars;
   double m_ote_lower;       // OTE retracement lower bound (default 0.62)
   double m_ote_upper;       // OTE retracement upper bound (default 0.79)
   int    m_lkz_start_hour;  // London Killzone start (broker hour, default 9)
   int    m_lkz_end_hour;    // London Killzone end (default 12)
   int    m_nysb_start_hour; // NY Silver Bullet start (default 16)
   int    m_nysb_end_hour;   // NY Silver Bullet end (default 17)
   int    m_p3_lookback;     // Power-of-3 dealing range lookback (default 24)

public:
   CSMCAdvancedPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                            m_lookback_bars(50),
                            m_ote_lower(0.62), m_ote_upper(0.79),
                            m_lkz_start_hour(9), m_lkz_end_hour(12),
                            m_nysb_start_hour(16), m_nysb_end_hour(17),
                            m_p3_lookback(24) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int lookback = 50, double ote_lower = 0.62, double ote_upper = 0.79,
                  int lkz_start = 9, int lkz_end = 12,
                  int nysb_start = 16, int nysb_end = 17,
                  int p3_lookback = 24)
   {
      m_lookback_bars  = lookback;
      m_ote_lower      = ote_lower;
      m_ote_upper      = ote_upper;
      m_lkz_start_hour = lkz_start;
      m_lkz_end_hour   = lkz_end;
      m_nysb_start_hour= nysb_start;
      m_nysb_end_hour  = nysb_end;
      m_p3_lookback    = p3_lookback;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P89_OTE_Long       = DetectOTELong(shift, atr);
      flags.P90_OTE_Short      = DetectOTEShort(shift, atr);
      flags.P91_LondonKZ_Long  = DetectLondonKZLong(shift, snap);
      flags.P92_LondonKZ_Short = DetectLondonKZShort(shift, snap);
      flags.P93_NYSB_Long      = DetectNYSBLong(shift, snap);
      flags.P94_NYSB_Short     = DetectNYSBShort(shift, snap);
      flags.P95_PowerOf3_Long  = DetectPowerOf3Long(shift, atr);
      flags.P96_PowerOf3_Short = DetectPowerOf3Short(shift, atr);
      flags.P97_PD_Array_Premium = DetectPDArrayPremium(shift, snap);
   }

private:
   //+---------------------------------------------------------------+
   //| P89 — OPTIMAL TRADE ENTRY LONG (OTE)                          |
   //|                                                                |
   //|  Theory (ICT): identify a recent bullish leg (swing low to    |
   //|  swing high). Optimal long entry is at 62-79% retracement     |
   //|  of that leg.                                                  |
   //|                                                                |
   //|  Detection:                                                    |
   //|   1. Find most recent swing high (SH) and prior swing low (SL)|
   //|      where SH is more recent than SL (an UP leg).             |
   //|   2. Compute leg = SH - SL.                                    |
   //|   3. OTE zone = [SH - leg*0.79, SH - leg*0.62]                |
   //|   4. Current bar's low is in zone AND bar bullish.            |
   //+---------------------------------------------------------------+
   bool DetectOTELong(int shift, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 1, m_lookback_bars, 3, 3);
      if(sh < 0) return false;
      int sl = FindSwingLow(m_symbol, m_period, sh + 1, m_lookback_bars, 3, 3);
      if(sl < 0) return false;
      if(sl <= sh) return false;  // SL must be older (larger shift)

      double swing_high = iHigh(m_symbol, m_period, sh);
      double swing_low  = iLow(m_symbol, m_period, sl);
      double leg = swing_high - swing_low;
      if(leg <= atr * 0.5) return false;  // leg too small

      double ote_high = swing_high - leg * m_ote_lower;  // 62% retrace level (closer to high)
      double ote_low  = swing_high - leg * m_ote_upper;  // 79% retrace level (deeper)

      double cur_low   = iLow(m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);

      bool in_zone = (cur_low >= ote_low - 0.1 * atr) && (cur_low <= ote_high + 0.1 * atr);
      bool bullish = (cur_close > cur_open);

      return in_zone && bullish;
   }

   //+---------------------------------------------------------------+
   //| P90 — OTE SHORT                                               |
   //|  Bearish leg = swing low more recent than swing high.         |
   //+---------------------------------------------------------------+
   bool DetectOTEShort(int shift, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 1, m_lookback_bars, 3, 3);
      if(sl < 0) return false;
      int sh = FindSwingHigh(m_symbol, m_period, sl + 1, m_lookback_bars, 3, 3);
      if(sh < 0) return false;
      if(sh <= sl) return false;  // SH must be older

      double swing_low  = iLow(m_symbol, m_period, sl);
      double swing_high = iHigh(m_symbol, m_period, sh);
      double leg = swing_high - swing_low;
      if(leg <= atr * 0.5) return false;

      double ote_low  = swing_low + leg * m_ote_lower;
      double ote_high = swing_low + leg * m_ote_upper;

      double cur_high  = iHigh(m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);

      bool in_zone = (cur_high >= ote_low - 0.1 * atr) && (cur_high <= ote_high + 0.1 * atr);
      bool bearish = (cur_close < cur_open);

      return in_zone && bearish;
   }

   //+---------------------------------------------------------------+
   //| P91 — LONDON KILLZONE LONG                                    |
   //|                                                                |
   //|  Theory (ICT): The London Killzone is the most volatile       |
   //|  early-session window — institutional liquidity grabs are     |
   //|  expected. We fire on a bullish bar within the broker-hour   |
   //|  window. Pure time-context pattern; downstream filters by    |
   //|  pairing with structure / OB / FVG.                           |
   //+---------------------------------------------------------------+
   bool DetectLondonKZLong(int shift, const IndicatorSnapshot &snap)
   {
      int h = snap.hour_of_day;
      if(h < m_lkz_start_hour || h >= m_lkz_end_hour) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close <= cur_open) return false;
      // Require at least modest bullish body so we don't fire on tiny noise bars
      double body = cur_close - cur_open;
      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(range <= 0) return false;
      return (body / range) >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P92 — LONDON KILLZONE SHORT                                   |
   //+---------------------------------------------------------------+
   bool DetectLondonKZShort(int shift, const IndicatorSnapshot &snap)
   {
      int h = snap.hour_of_day;
      if(h < m_lkz_start_hour || h >= m_lkz_end_hour) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close >= cur_open) return false;
      double body = cur_open - cur_close;
      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(range <= 0) return false;
      return (body / range) >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P93 — NY SILVER BULLET LONG                                   |
   //|                                                                |
   //|  Theory (ICT): NY Silver Bullet is the 10:00-11:00 EST hour  |
   //|  (≈ 14:00-15:00 GMT, ≈ 16:00-17:00 broker for Exness Pro).    |
   //|  Statistically high-probability liquidity window in NY open.  |
   //+---------------------------------------------------------------+
   bool DetectNYSBLong(int shift, const IndicatorSnapshot &snap)
   {
      int h = snap.hour_of_day;
      if(h < m_nysb_start_hour || h >= m_nysb_end_hour) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close <= cur_open) return false;
      double body = cur_close - cur_open;
      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(range <= 0) return false;
      return (body / range) >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P94 — NY SILVER BULLET SHORT                                  |
   //+---------------------------------------------------------------+
   bool DetectNYSBShort(int shift, const IndicatorSnapshot &snap)
   {
      int h = snap.hour_of_day;
      if(h < m_nysb_start_hour || h >= m_nysb_end_hour) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      if(cur_close >= cur_open) return false;
      double body = cur_open - cur_close;
      double range = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(range <= 0) return false;
      return (body / range) >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P95 — POWER OF 3 LONG (Accumulation-Manipulation-Distribution)|
   //|                                                                |
   //|  Theory (ICT): A 3-stage cycle. Accumulation = tight range.   |
   //|  Manipulation = sweep below the accumulation range (stop run).|
   //|  Distribution = strong move higher in the opposite direction. |
   //|                                                                |
   //|  Detection (simplified):                                       |
   //|   1. Identify a tight range over bars [shift+8 .. shift+m_p3] |
   //|      where (range_high - range_low) < 1.5 * ATR.              |
   //|   2. In bars (shift+1 .. shift+7), there was a sweep BELOW    |
   //|      range_low by >= 0.3 * ATR.                                |
   //|   3. Current bar closes back ABOVE range_low + bullish.       |
   //+---------------------------------------------------------------+
   bool DetectPowerOf3Long(int shift, double atr)
   {
      int acc_start = shift + 8;
      int acc_end   = shift + m_p3_lookback;
      if(acc_end >= shift + 200) return false;

      double range_high = iHigh(m_symbol, m_period, acc_start);
      double range_low  = iLow(m_symbol, m_period, acc_start);
      for(int i = acc_start + 1; i <= acc_end; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow(m_symbol, m_period, i);
         if(h > range_high) range_high = h;
         if(l < range_low)  range_low  = l;
      }
      if(range_high - range_low > 1.5 * atr) return false;  // not tight enough

      // Manipulation: sweep below range_low in last 7 bars
      bool swept = false;
      for(int j = shift + 1; j <= shift + 7; j++)
      {
         if(iLow(m_symbol, m_period, j) < range_low - 0.3 * atr) { swept = true; break; }
      }
      if(!swept) return false;

      // Distribution: current bar closes back above range_low and is bullish
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (cur_close > range_low) && (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P96 — POWER OF 3 SHORT                                        |
   //+---------------------------------------------------------------+
   bool DetectPowerOf3Short(int shift, double atr)
   {
      int acc_start = shift + 8;
      int acc_end   = shift + m_p3_lookback;
      if(acc_end >= shift + 200) return false;

      double range_high = iHigh(m_symbol, m_period, acc_start);
      double range_low  = iLow(m_symbol, m_period, acc_start);
      for(int i = acc_start + 1; i <= acc_end; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow(m_symbol, m_period, i);
         if(h > range_high) range_high = h;
         if(l < range_low)  range_low  = l;
      }
      if(range_high - range_low > 1.5 * atr) return false;

      bool swept = false;
      for(int j = shift + 1; j <= shift + 7; j++)
      {
         if(iHigh(m_symbol, m_period, j) > range_high + 0.3 * atr) { swept = true; break; }
      }
      if(!swept) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (cur_close < range_high) && (cur_close < cur_open);
   }

   //+---------------------------------------------------------------+
   //| P97 — PD ARRAY PREMIUM                                        |
   //|                                                                |
   //|  Theory (ICT): Within a "dealing range" (most recent swing    |
   //|  low to swing high), the upper half is the "premium" array — |
   //|  short-biased zone where smart money takes profit / shorts.   |
   //|  The lower half is "discount" — long-biased zone.             |
   //|                                                                |
   //|  This pattern: price is in the PREMIUM half (above 50% of    |
   //|  dealing range) AND showing bearish reaction (bearish bar).   |
   //|  Signals SHORT bias (direction = -1).                         |
   //+---------------------------------------------------------------+
   bool DetectPDArrayPremium(int shift, const IndicatorSnapshot &snap)
   {
      // Use last_swing_high / last_swing_low from snapshot
      double sh = snap.last_swing_high;
      double sl = snap.last_swing_low;
      if(sh <= 0 || sl <= 0) return false;
      if(sh - sl <= 0) return false;

      double mid = (sh + sl) / 2.0;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);

      // Price in premium half AND bearish bar
      return (cur_close > mid) && (cur_close < cur_open);
   }
};

#endif  // KMP_PATTERNS_H_MQH