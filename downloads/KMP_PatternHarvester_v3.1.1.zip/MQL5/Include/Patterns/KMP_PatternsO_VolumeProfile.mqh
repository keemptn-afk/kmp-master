//+------------------------------------------------------------------+
//|                              KMP_PatternsO_VolumeProfile.mqh    |
//|  CATEGORY O: VOLUME PROFILE EXPANDED (P161-P165)                |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Peter Steidlmayer — "Markets and Market Logic" (1986).     |
//|      Value Area, POC, single prints in market profile.           |
//|  [2] James Dalton — "Mind Over Markets" (2007). VAL/VAH         |
//|      acceptance/rejection patterns.                              |
//|                                                                  |
//|  Approximations (real Market Profile not available in MT5):     |
//|    POC ≈ price level with most volume in last 24h               |
//|    Value Area ≈ 70% of volume range around POC                   |
//|    Single Print ≈ low-volume price gap (large bar with low vol) |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_O_MQH
#define KMP_PATTERNS_O_MQH

#include "../KMP_Structures.mqh"

class CVolumeProfilePatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_profile_bars;       // bars to build profile (default 24 = 1 day on H1)

public:
   CVolumeProfilePatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                              m_profile_bars(24) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int profile_bars = 24) { m_profile_bars = profile_bars; }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      // Build approximate Value Area from prior session
      double vah = 0, val = 0, poc = 0;
      ComputeValueArea(shift + 1, m_profile_bars, vah, val, poc);

      flags.P161_VAH_Reject_Short    = DetectVAHReject (shift, vah, atr);
      flags.P162_VAL_Reject_Long     = DetectVALReject (shift, val, atr);
      flags.P163_Single_Print_Fill_Long  = DetectSinglePrintLong (shift, atr);
      flags.P164_Single_Print_Fill_Short = DetectSinglePrintShort(shift, atr);
      flags.P165_POC_Migration_Long  = DetectPOCMigration(shift, atr);
   }

private:
   //+---------------------------------------------------------------+
   //| Compute approximate VAH / VAL / POC                            |
   //|  Use range-weighted by tick volume; bin into 20 price levels. |
   //+---------------------------------------------------------------+
   void ComputeValueArea(int start_shift, int n_bars,
                          double &vah, double &val, double &poc)
   {
      vah = val = poc = 0;
      // Find price range over n_bars
      double hi = iHigh(m_symbol, m_period, start_shift);
      double lo = iLow (m_symbol, m_period, start_shift);
      for(int i = 1; i < n_bars; i++)
      {
         double h = iHigh(m_symbol, m_period, start_shift + i);
         double l = iLow (m_symbol, m_period, start_shift + i);
         if(h > hi) hi = h;
         if(l < lo) lo = l;
      }
      double range = hi - lo;
      if(range <= 0) return;

      // 20 bins, accumulate volume per bin
      const int NB = 20;
      double bin_vol[20];
      ArrayInitialize(bin_vol, 0.0);
      for(int i = 0; i < n_bars; i++)
      {
         double bar_low  = iLow (m_symbol, m_period, start_shift + i);
         double bar_high = iHigh(m_symbol, m_period, start_shift + i);
         long   v        = iTickVolume(m_symbol, m_period, start_shift + i);
         double bar_mid  = (bar_low + bar_high) / 2.0;
         int idx = (int)((bar_mid - lo) / range * NB);
         if(idx < 0) idx = 0;
         if(idx >= NB) idx = NB - 1;
         bin_vol[idx] += (double)v;
      }
      // Find POC = bin with max
      int poc_idx = 0;
      for(int i = 1; i < NB; i++) if(bin_vol[i] > bin_vol[poc_idx]) poc_idx = i;
      poc = lo + ((double)poc_idx + 0.5) * (range / NB);

      // Value area = 70% of total volume around POC (expand outward)
      double total_v = 0;
      for(int i = 0; i < NB; i++) total_v += bin_vol[i];
      double target = total_v * 0.7;
      double accum = bin_vol[poc_idx];
      int lo_i = poc_idx, hi_i = poc_idx;
      while(accum < target && (lo_i > 0 || hi_i < NB - 1))
      {
         double next_lo = (lo_i > 0) ? bin_vol[lo_i - 1] : -1;
         double next_hi = (hi_i < NB - 1) ? bin_vol[hi_i + 1] : -1;
         if(next_hi > next_lo) { hi_i++; accum += bin_vol[hi_i]; }
         else if(next_lo > 0)  { lo_i--; accum += bin_vol[lo_i]; }
         else break;
      }
      val = lo + ((double)lo_i + 0.0) * (range / NB);
      vah = lo + ((double)hi_i + 1.0) * (range / NB);
   }

   //+---------------------------------------------------------------+
   //| P161 — VAH Reject Short: bounce off Value Area High           |
   //+---------------------------------------------------------------+
   bool DetectVAHReject(int shift, double vah, double atr)
   {
      if(vah <= 0) return false;
      double cur_high = iHigh (m_symbol, m_period, shift);
      double cur_open = iOpen (m_symbol, m_period, shift);
      double cur_close= iClose(m_symbol, m_period, shift);
      // High touched/exceeded VAH but close back below
      if(cur_high < vah - 0.1 * atr) return false;
      if(cur_close >= vah) return false;
      return (cur_close < cur_open);
   }

   bool DetectVALReject(int shift, double val, double atr)
   {
      if(val <= 0) return false;
      double cur_low  = iLow  (m_symbol, m_period, shift);
      double cur_open = iOpen (m_symbol, m_period, shift);
      double cur_close= iClose(m_symbol, m_period, shift);
      if(cur_low > val + 0.1 * atr) return false;
      if(cur_close <= val) return false;
      return (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P163/P164 — Single Print Fill                                 |
   //|  Bar with HUGE range but very LOW volume → low-volume gap   |
   //|  Subsequent re-test fills it.                                  |
   //|  Detection (simplified): in last 5 bars, find a bar with     |
   //|  range > 2*ATR AND volume_ratio (vs MA20) < 0.7. Current bar |
   //|  enters that bar's range from outside.                        |
   //+---------------------------------------------------------------+
   bool DetectSinglePrintLong(int shift, double atr)
   {
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow (m_symbol, m_period, i);
         double r = h - l;
         if(r < 2.0 * atr) continue;
         long v_now = iTickVolume(m_symbol, m_period, i);
         long v_avg = 0;
         for(int j = i + 1; j <= i + 20; j++) v_avg += iTickVolume(m_symbol, m_period, j);
         double vavg = (double)v_avg / 20.0;
         if(vavg <= 0) continue;
         if((double)v_now / vavg > 0.7) continue;  // not low-vol enough
         // Current bar must be entering the SP zone from below
         double cur_low = iLow (m_symbol, m_period, shift);
         double cur_close = iClose(m_symbol, m_period, shift);
         double o = iOpen(m_symbol, m_period, shift);
         if(cur_low < l) return false;            // already below
         if(cur_close > h) return false;          // already above
         if(cur_close <= o) return false;
         return true;
      }
      return false;
   }

   bool DetectSinglePrintShort(int shift, double atr)
   {
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         double l = iLow (m_symbol, m_period, i);
         double r = h - l;
         if(r < 2.0 * atr) continue;
         long v_now = iTickVolume(m_symbol, m_period, i);
         long v_avg = 0;
         for(int j = i + 1; j <= i + 20; j++) v_avg += iTickVolume(m_symbol, m_period, j);
         double vavg = (double)v_avg / 20.0;
         if(vavg <= 0) continue;
         if((double)v_now / vavg > 0.7) continue;
         double cur_high = iHigh(m_symbol, m_period, shift);
         double cur_close = iClose(m_symbol, m_period, shift);
         double o = iOpen(m_symbol, m_period, shift);
         if(cur_high > h) return false;
         if(cur_close < l) return false;
         if(cur_close >= o) return false;
         return true;
      }
      return false;
   }

   //+---------------------------------------------------------------+
   //| P165 — POC Migration Long                                     |
   //|  POC has trended UP 3 days in a row → bullish acceptance      |
   //+---------------------------------------------------------------+
   bool DetectPOCMigration(int shift, double atr)
   {
      double v0a, v0l, p0;
      double v1a, v1l, p1;
      double v2a, v2l, p2;
      ComputeValueArea(shift + 1,                m_profile_bars, v0a, v0l, p0);
      ComputeValueArea(shift + 1 + m_profile_bars,  m_profile_bars, v1a, v1l, p1);
      ComputeValueArea(shift + 1 + 2 * m_profile_bars, m_profile_bars, v2a, v2l, p2);
      if(p0 == 0 || p1 == 0 || p2 == 0) return false;
      // 3 successive higher POCs
      if(!(p0 > p1 && p1 > p2)) return false;
      // Current bullish bar
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }
};

#endif  // KMP_PATTERNS_O_MQH