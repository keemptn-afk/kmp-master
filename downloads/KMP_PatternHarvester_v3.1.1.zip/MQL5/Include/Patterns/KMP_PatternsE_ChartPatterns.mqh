//+------------------------------------------------------------------+
//|                                  KMP_PatternsE_ChartPatterns.mqh|
//|                                                                  |
//|  CATEGORY E: CLASSICAL CHART PATTERNS (P61-P70)                  |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Edwards & Magee "Technical Analysis of Stock Trends"        |
//|      ISBN 1466557559 (the foundational text, since 1948)        |
//|  [2] Thomas Bulkowski "Encyclopedia of Chart Patterns"          |
//|      ISBN 0471264458 (statistical performance database)         |
//|      Bulkowski's stats: thepatternsite.com                       |
//|                                                                  |
//|  IMPORTANT NOTE ON CHART PATTERNS:                               |
//|  Real chart patterns (e.g., Head&Shoulders) need many bars to   |
//|  form (often 20-100+) and have subjective elements. Algorithmic |
//|  detection is approximate. Use with caution and combine with    |
//|  other categories for confluence.                                |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_E_MQH
#define KMP_PATTERNS_E_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CChartPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_lookback_bars;
   double m_tolerance_atr;
   int    m_min_pattern_bars;
   
public:
   CChartPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                      m_lookback_bars(80),
                      m_tolerance_atr(0.5),
                      m_min_pattern_bars(8) {}
   
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }
   
   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      
      flags.P61_Double_Bottom = DetectDoubleBottom(shift, atr);
      flags.P62_Double_Top = DetectDoubleTop(shift, atr);
      flags.P63_Triple_Bottom = DetectTripleBottom(shift, atr);
      flags.P64_Triple_Top = DetectTripleTop(shift, atr);
      flags.P65_Head_Shoulders_Bear = DetectHeadShouldersBear(shift, atr);
      flags.P66_Head_Shoulders_Bull = DetectHeadShouldersBull(shift, atr);
      flags.P67_Triangle_Ascending = DetectAscendingTriangle(shift, atr);
      flags.P68_Triangle_Descending = DetectDescendingTriangle(shift, atr);
      flags.P69_Bull_Flag = DetectBullFlag(shift, atr);
      flags.P70_Bear_Flag = DetectBearFlag(shift, atr);
   }
   
private:
   //+---------------------------------------------------------------+
   //| P61 — DOUBLE BOTTOM (W-pattern)                              |
   //|                                                                |
   //|  Theory (Edwards & Magee ch. 6): Two distinct lows at        |
   //|  approximately the same level, separated by a peak in        |
   //|  between. Confirms when price breaks above the peak.         |
   //|                                                                |
   //|  Bulkowski stats: ~85% reliable when fully formed (broken).  |
   //|                                                                |
   //|  Detection:                                                    |
   //|  1. Find 2 swing lows with similar price (within tolerance)  |
   //|  2. Find peak between them                                     |
   //|  3. Current price has broken above peak                        |
   //+---------------------------------------------------------------+
   bool DetectDoubleBottom(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sl2 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      // Lows should be similar (within tolerance)
      if(MathAbs(l1 - l2) > m_tolerance_atr * atr) return false;
      
      // Find peak between them
      int peak_idx = -1;
      double peak_high = 0;
      for(int i = sl1 + 1; i < sl2; i++)
      {
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(h > peak_high) { peak_high = h; peak_idx = i; }
      }
      if(peak_idx < 0) return false;
      
      // Peak should be reasonably above lows
      double avg_low = (l1 + l2) / 2.0;
      if(peak_high - avg_low < atr * 1.5) return false;
      
      // Current closed above peak (breakout confirmation)
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close > peak_high;
   }
   
   //+---------------------------------------------------------------+
   //| P62 — DOUBLE TOP                                              |
   //+---------------------------------------------------------------+
   bool DetectDoubleTop(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      if(MathAbs(h1 - h2) > m_tolerance_atr * atr) return false;
      
      int trough_idx = -1;
      double trough_low = 999999;
      for(int i = sh1 + 1; i < sh2; i++)
      {
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(l < trough_low) { trough_low = l; trough_idx = i; }
      }
      if(trough_idx < 0) return false;
      
      double avg_high = (h1 + h2) / 2.0;
      if(avg_high - trough_low < atr * 1.5) return false;
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close < trough_low;
   }
   
   //+---------------------------------------------------------------+
   //| P63 — TRIPLE BOTTOM                                           |
   //|                                                                |
   //|  Theory: Three lows at similar level, more reliable than     |
   //|  double. Bulkowski: ~85-90% accuracy.                         |
   //+---------------------------------------------------------------+
   bool DetectTripleBottom(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sl2 < 0) return false;
      int sl3 = FindSwingLow(m_symbol, m_period, sl2 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sl3 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      double l3 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl3);
      
      double max_diff = MathMax(MathAbs(l1 - l2), MathAbs(MathMax(l2, l3) - MathMin(l2, l3)));
      max_diff = MathMax(max_diff, MathAbs(l1 - l3));
      
      if(max_diff > m_tolerance_atr * atr) return false;
      
      // Find resistance line (max high between lows)
      double resistance = 0;
      for(int i = sl1 + 1; i < sl3; i++)
      {
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(h > resistance) resistance = h;
      }
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close > resistance;
   }
   
   //+---------------------------------------------------------------+
   //| P64 — TRIPLE TOP                                              |
   //+---------------------------------------------------------------+
   bool DetectTripleTop(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sh2 < 0) return false;
      int sh3 = FindSwingHigh(m_symbol, m_period, sh2 + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(sh3 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      double h3 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh3);
      
      double max_diff = MathMax(MathAbs(h1 - h2), MathAbs(h2 - h3));
      max_diff = MathMax(max_diff, MathAbs(h1 - h3));
      
      if(max_diff > m_tolerance_atr * atr) return false;
      
      double support = 999999;
      for(int i = sh1 + 1; i < sh3; i++)
      {
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(l < support) support = l;
      }
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close < support;
   }
   
   //+---------------------------------------------------------------+
   //| P65 — HEAD AND SHOULDERS (BEARISH)                            |
   //|                                                                |
   //|  Theory (Edwards & Magee ch. 6): Three peaks where middle    |
   //|  (head) is highest. Two outer peaks (shoulders) are at       |
   //|  similar height. Neckline = lows between peaks.              |
   //|  Confirms when price breaks below neckline.                   |
   //|                                                                |
   //|  Bulkowski stats: H&S top is ~93% reliable (one of best!)   |
   //+---------------------------------------------------------------+
   bool DetectHeadShouldersBear(int shift, double atr)
   {
      // Find 3 swing highs: shoulder R, head, shoulder L
      int shoulder_R = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(shoulder_R < 0) return false;
      int head = FindSwingHigh(m_symbol, m_period, shoulder_R + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(head < 0) return false;
      int shoulder_L = FindSwingHigh(m_symbol, m_period, head + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(shoulder_L < 0) return false;
      
      double sR = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shoulder_R);
      double h  = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, head);
      double sL = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shoulder_L);
      
      // Head must be higher than both shoulders
      if(h <= sR || h <= sL) return false;
      // Head significantly higher (at least 0.5×ATR)
      if(h - MathMax(sR, sL) < atr * 0.5) return false;
      
      // Shoulders similar height (within tolerance)
      if(MathAbs(sR - sL) > m_tolerance_atr * atr) return false;
      
      // Find neckline (lowest low between shoulders)
      double neckline = 999999;
      for(int i = shoulder_R; i <= shoulder_L; i++)
      {
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(l < neckline) neckline = l;
      }
      
      // Current closed below neckline = confirmed
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close < neckline;
   }
   
   //+---------------------------------------------------------------+
   //| P66 — INVERTED HEAD AND SHOULDERS (BULLISH)                   |
   //+---------------------------------------------------------------+
   bool DetectHeadShouldersBull(int shift, double atr)
   {
      int shoulder_R = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(shoulder_R < 0) return false;
      int head = FindSwingLow(m_symbol, m_period, shoulder_R + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(head < 0) return false;
      int shoulder_L = FindSwingLow(m_symbol, m_period, head + m_min_pattern_bars, m_lookback_bars, 3, 3);
      if(shoulder_L < 0) return false;
      
      double sR = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shoulder_R);
      double h  = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, head);
      double sL = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shoulder_L);
      
      if(h >= sR || h >= sL) return false;
      if(MathMin(sR, sL) - h < atr * 0.5) return false;
      if(MathAbs(sR - sL) > m_tolerance_atr * atr) return false;
      
      double neckline = 0;
      for(int i = shoulder_R; i <= shoulder_L; i++)
      {
         double hh = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(hh > neckline) neckline = hh;
      }
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close > neckline;
   }
   
   //+---------------------------------------------------------------+
   //| P67 — ASCENDING TRIANGLE                                      |
   //|                                                                |
   //|  Theory (Bulkowski): Horizontal resistance + rising support  |
   //|  trendline. Bullish breakout typical (~70% according to     |
   //|  Bulkowski).                                                   |
   //|                                                                |
   //|  Detection:                                                    |
   //|  - Last 2-3 highs at similar level                             |
   //|  - Last 2-3 lows ascending                                     |
   //|  - Current breaks above the resistance                         |
   //+---------------------------------------------------------------+
   bool DetectAscendingTriangle(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars, 3, 3);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      // Highs at similar level
      if(MathAbs(h1 - h2) > m_tolerance_atr * atr) return false;
      double resistance = MathMax(h1, h2);
      
      // Lows ascending
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars, 3, 3);
      if(sl2 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      if(l1 <= l2) return false;  // need l1 (recent) > l2 (older)
      
      // Current breaks above resistance
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close > resistance + atr * 0.1;
   }
   
   //+---------------------------------------------------------------+
   //| P68 — DESCENDING TRIANGLE                                     |
   //+---------------------------------------------------------------+
   bool DetectDescendingTriangle(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars, 3, 3);
      if(sl2 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      if(MathAbs(l1 - l2) > m_tolerance_atr * atr) return false;
      double support = MathMin(l1, l2);
      
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars, 3, 3);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      if(h1 >= h2) return false;  // descending highs
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close < support - atr * 0.1;
   }
   
   //+---------------------------------------------------------------+
   //| P69 — BULL FLAG                                               |
   //|                                                                |
   //|  Theory (Edwards & Magee ch. 7): Strong upward "pole",       |
   //|  followed by a small downward-sloping consolidation (flag).  |
   //|  Breakout above flag = continuation.                          |
   //|                                                                |
   //|  Detection:                                                    |
   //|  1. Recent strong move up (3-5 bars, > 3×ATR cumulative)     |
   //|  2. Followed by 3-5 bars of mild pullback (< 50% of pole)    |
   //|  3. Current breaks above flag high                            |
   //+---------------------------------------------------------------+
   bool DetectBullFlag(int shift, double atr)
   {
      // Pole: bars from shift+8 to shift+5 should show strong rise
      double pole_start = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift + 8);
      double pole_end = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift + 5);
      double pole_size = pole_end - pole_start;
      
      if(pole_size < 3 * atr) return false;
      
      // Flag: bars from shift+5 to shift+1 should be mild pullback
      double flag_high = 0;
      double flag_low = 999999;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(h > flag_high) flag_high = h;
         if(l < flag_low) flag_low = l;
      }
      
      double flag_size = flag_high - flag_low;
      if(flag_size > pole_size * 0.5) return false;  // pullback < 50% of pole
      
      // Current breaks above flag_high
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close > flag_high;
   }
   
   //+---------------------------------------------------------------+
   //| P70 — BEAR FLAG                                               |
   //+---------------------------------------------------------------+
   bool DetectBearFlag(int shift, double atr)
   {
      double pole_start = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift + 8);
      double pole_end = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift + 5);
      double pole_size = pole_start - pole_end;
      
      if(pole_size < 3 * atr) return false;
      
      double flag_high = 0;
      double flag_low = 999999;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(h > flag_high) flag_high = h;
         if(l < flag_low) flag_low = l;
      }
      
      double flag_size = flag_high - flag_low;
      if(flag_size > pole_size * 0.5) return false;
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      return current_close < flag_low;
   }
};

#endif  // KMP_PATTERNS_E_MQH