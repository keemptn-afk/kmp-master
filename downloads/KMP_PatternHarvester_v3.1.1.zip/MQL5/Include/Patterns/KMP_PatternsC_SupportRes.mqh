//+------------------------------------------------------------------+
//|                                  KMP_PatternsC_SupportRes.mqh   |
//|                                                                  |
//|  CATEGORY C: SUPPORT/RESISTANCE & ORDER BLOCKS (P41-P50)         |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Sam Seiden's "Supply and Demand" methodology                |
//|      (Online Trading Academy curriculum)                         |
//|  [2] ICT (Inner Circle Trader) "Order Block" concept            |
//|      Defined: last opposite candle before strong impulsive move |
//|  [3] Wyckoff method - Accumulation/Distribution zones            |
//|      Richard D. Wyckoff (1873-1934)                             |
//|  [4] Edwards & Magee "Technical Analysis of Stock Trends"        |
//|      Chapter on support/resistance and trendlines               |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_C_MQH
#define KMP_PATTERNS_C_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

//+------------------------------------------------------------------+
//| Support/Resistance & Order Block Detector                       |
//+------------------------------------------------------------------+
class CSupportResistancePatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_lookback_bars;       // bars to scan for zones
   double m_zone_proximity_atr;  // how close to zone = "test"
   double m_strong_move_atr;     // body size for "strong move"
   
public:
   CSupportResistancePatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                                   m_lookback_bars(50),
                                   m_zone_proximity_atr(0.3),
                                   m_strong_move_atr(2.0) {}
   
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }
   
   void SetParams(int lookback, double proximity_atr, double strong_atr)
   {
      m_lookback_bars = lookback;
      m_zone_proximity_atr = proximity_atr;
      m_strong_move_atr = strong_atr;
   }
   
   //+---------------------------------------------------------------+
   //| Detect all Category C patterns                               |
   //+---------------------------------------------------------------+
   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      
      CandleAnatomy c0;
      c0.Capture(m_symbol, m_period, shift);
      
      // === Order Blocks ===
      flags.P43_Bullish_Order_Block = DetectBullishOrderBlock(shift, atr);
      flags.P44_Bearish_Order_Block = DetectBearishOrderBlock(shift, atr);
      
      // === Supply/Demand zones ===
      flags.P41_Supply_Zone_Reject = DetectSupplyZoneReject(shift, c0, atr);
      flags.P42_Demand_Zone_Reject = DetectDemandZoneReject(shift, c0, atr);
      
      // === S/R Flip ===
      flags.P47_SR_Flip_Long = DetectSRFlipLong(shift, c0, atr);
      flags.P48_SR_Flip_Short = DetectSRFlipShort(shift, c0, atr);
      
      // === Trendline bounce ===
      flags.P49_Trendline_Bounce_Long = DetectTrendlineBounceLong(shift, c0, atr);
      flags.P50_Trendline_Bounce_Short = DetectTrendlineBounceShort(shift, c0, atr);
      
      // === Breaker Blocks ===
      flags.P45_Breaker_Block_Bull = DetectBreakerBlockBull(shift, c0, atr);
      flags.P46_Breaker_Block_Bear = DetectBreakerBlockBear(shift, c0, atr);
   }
   
private:
   //+---------------------------------------------------------------+
   //| P43 — BULLISH ORDER BLOCK                                     |
   //|                                                                |
   //|  Theory (ICT): "The last bearish candle before an impulsive   |
   //|  bullish move." When price returns to this candle, bullish    |
   //|  reaction is expected (institutional orders left there).      |
   //|                                                                |
   //|  Detection logic:                                              |
   //|  1. Find a bearish candle in last N bars                       |
   //|  2. Check that the next 3 candles produced strong bullish     |
   //|     move (cumulative body > 2×ATR)                            |
   //|  3. Check that current price is within OB range (proximity)   |
   //+---------------------------------------------------------------+
   bool DetectBullishOrderBlock(int shift, double atr)
   {
      double current_price = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      // Scan back to find OB candidates
      for(int i = shift + 4; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double c = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         // Must be bearish candle (the "OB")
         if(c >= o) continue;
         
         double ob_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double ob_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         // Check next 3 candles produced strong bullish move
         double next_3_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 3);
         double impulse = next_3_close - c;
         
         if(impulse < m_strong_move_atr * atr) continue;
         
         // Check current price returning to OB zone
         double dist_to_ob = MathAbs(current_price - ob_low);
         if(dist_to_ob > m_zone_proximity_atr * atr) continue;
         if(current_price < ob_low - atr * 0.5) continue;  // not too far below
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P44 — BEARISH ORDER BLOCK                                     |
   //+---------------------------------------------------------------+
   bool DetectBearishOrderBlock(int shift, double atr)
   {
      double current_price = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      for(int i = shift + 4; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double c = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         if(c <= o) continue;  // must be bullish OB
         
         double ob_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double ob_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         double next_3_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 3);
         double impulse = c - next_3_close;
         
         if(impulse < m_strong_move_atr * atr) continue;
         
         double dist_to_ob = MathAbs(current_price - ob_high);
         if(dist_to_ob > m_zone_proximity_atr * atr) continue;
         if(current_price > ob_high + atr * 0.5) continue;
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P41 — SUPPLY ZONE REJECT                                      |
   //|                                                                |
   //|  Theory (Sam Seiden): Supply zone = origin of strong drop.    |
   //|  Identified by: small base of candles, then strong drop.      |
   //|  When price returns to this zone, expect rejection (sell).   |
   //|                                                                |
   //|  Simplified detection:                                         |
   //|  - Find a recent swing high                                    |
   //|  - Confirm strong move down followed (impulse > 2×ATR)        |
   //|  - Current price near that high (within proximity)            |
   //|  - Current candle shows rejection (upper wick or bear close) |
   //+---------------------------------------------------------------+
   bool DetectSupplyZoneReject(int shift, const CandleAnatomy &c, double atr)
   {
      // Find swing high in last N bars
      int swing_idx = FindSwingHigh(m_symbol, m_period, shift + 1, m_lookback_bars, 3, 3);
      if(swing_idx < 0) return false;
      
      double swing_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, swing_idx);
      
      // Verify strong drop after swing (>= 3 bars later, drop > 2×ATR)
      double drop_check = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, swing_idx - 3);
      double drop_size = swing_high - drop_check;
      if(drop_size < m_strong_move_atr * atr) return false;
      
      // Current price near zone
      double dist = MathAbs(c.high - swing_high);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      // Rejection: upper wick > body OR bearish close
      bool rejection = c.upper_wick > c.body || c.is_bear;
      
      return rejection;
   }
   
   //+---------------------------------------------------------------+
   //| P42 — DEMAND ZONE REJECT (mirror)                             |
   //+---------------------------------------------------------------+
   bool DetectDemandZoneReject(int shift, const CandleAnatomy &c, double atr)
   {
      int swing_idx = FindSwingLow(m_symbol, m_period, shift + 1, m_lookback_bars, 3, 3);
      if(swing_idx < 0) return false;
      
      double swing_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, swing_idx);
      
      double rise_check = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, swing_idx - 3);
      double rise_size = rise_check - swing_low;
      if(rise_size < m_strong_move_atr * atr) return false;
      
      double dist = MathAbs(c.low - swing_low);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      bool rejection = c.lower_wick > c.body || c.is_bull;
      
      return rejection;
   }
   
   //+---------------------------------------------------------------+
   //| P47 — S/R FLIP LONG                                           |
   //|                                                                |
   //|  Theory (Edwards & Magee): When price breaks above            |
   //|  resistance and returns to it, that resistance becomes        |
   //|  support. "Polarity principle".                                |
   //|                                                                |
   //|  Detection:                                                    |
   //|  1. Find old resistance (swing high in past)                   |
   //|  2. Confirm price broke above it recently                      |
   //|  3. Current price returning to test that level                 |
   //|  4. Bullish rejection                                          |
   //+---------------------------------------------------------------+
   bool DetectSRFlipLong(int shift, const CandleAnatomy &c, double atr)
   {
      // Find swing high more than 10 bars ago
      int old_high_idx = FindSwingHigh(m_symbol, m_period, shift + 10, m_lookback_bars - 10, 3, 3);
      if(old_high_idx < 0) return false;
      
      double old_resistance = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, old_high_idx);
      
      // Verify price broke above (look for any close > old_resistance between old_high_idx and shift)
      bool broke_above = false;
      for(int i = old_high_idx - 1; i > shift; i--)
      {
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(cl > old_resistance + atr * 0.5)
         {
            broke_above = true;
            break;
         }
      }
      if(!broke_above) return false;
      
      // Current testing the level
      double dist = MathAbs(c.low - old_resistance);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      // Bullish rejection
      bool bullish_test = c.lower_wick > c.body * 0.5 || c.is_bull;
      
      return bullish_test;
   }
   
   //+---------------------------------------------------------------+
   //| P48 — S/R FLIP SHORT (mirror)                                 |
   //+---------------------------------------------------------------+
   bool DetectSRFlipShort(int shift, const CandleAnatomy &c, double atr)
   {
      int old_low_idx = FindSwingLow(m_symbol, m_period, shift + 10, m_lookback_bars - 10, 3, 3);
      if(old_low_idx < 0) return false;
      
      double old_support = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, old_low_idx);
      
      bool broke_below = false;
      for(int i = old_low_idx - 1; i > shift; i--)
      {
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(cl < old_support - atr * 0.5)
         {
            broke_below = true;
            break;
         }
      }
      if(!broke_below) return false;
      
      double dist = MathAbs(c.high - old_support);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      bool bearish_test = c.upper_wick > c.body * 0.5 || c.is_bear;
      
      return bearish_test;
   }
   
   //+---------------------------------------------------------------+
   //| P49 — TRENDLINE BOUNCE LONG                                   |
   //|                                                                |
   //|  Theory (Edwards & Magee): A line connecting two or more      |
   //|  swing lows projects support. Bounce off the projected line   |
   //|  in uptrend = bullish entry.                                   |
   //|                                                                |
   //|  Simplified: connect last 2 swing lows, project to current.   |
   //+---------------------------------------------------------------+
   bool DetectTrendlineBounceLong(int shift, const CandleAnatomy &c, double atr)
   {
      // Find 2 most recent swing lows
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 5, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars - sl1 + shift, 3, 3);
      if(sl2 < 0) return false;
      
      double low1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double low2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      // For uptrend: low1 (more recent) > low2 (older) — rising lows
      if(low1 <= low2) return false;
      
      // Slope per bar
      int bars_between = sl2 - sl1;  // sl2 is older (larger shift)
      if(bars_between == 0) return false;
      double slope = (low1 - low2) / bars_between;
      
      // Project trendline to current bar
      int bars_to_current = sl1 - shift;
      double projected = low1 + slope * bars_to_current;
      
      // Current price near projected line
      double dist = MathAbs(c.low - projected);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      bool bullish_test = c.lower_wick > c.body * 0.5 || c.is_bull;
      
      return bullish_test;
   }
   
   //+---------------------------------------------------------------+
   //| P50 — TRENDLINE BOUNCE SHORT                                  |
   //+---------------------------------------------------------------+
   bool DetectTrendlineBounceShort(int shift, const CandleAnatomy &c, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 5, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars - sh1 + shift, 3, 3);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      if(h1 >= h2) return false;  // falling highs needed
      
      int bars_between = sh2 - sh1;
      if(bars_between == 0) return false;
      double slope = (h1 - h2) / bars_between;
      
      int bars_to_current = sh1 - shift;
      double projected = h1 + slope * bars_to_current;
      
      double dist = MathAbs(c.high - projected);
      if(dist > m_zone_proximity_atr * atr) return false;
      
      bool bearish_test = c.upper_wick > c.body * 0.5 || c.is_bear;
      
      return bearish_test;
   }
   
   //+---------------------------------------------------------------+
   //| P45 — BREAKER BLOCK BULL                                      |
   //|                                                                |
   //|  Theory (ICT): A "failed" bearish OB. Originally was a       |
   //|  resistance/supply level, but price broke through and is now |
   //|  acting as support on retest. Key SMC concept.                |
   //|                                                                |
   //|  Detection:                                                    |
   //|  1. Find a bearish OB candidate                                |
   //|  2. Verify price BROKE ABOVE it (didn't respect it)           |
   //|  3. Now retesting from above                                   |
   //+---------------------------------------------------------------+
   bool DetectBreakerBlockBull(int shift, const CandleAnatomy &c, double atr)
   {
      // Find a recent bullish OB candidate that turned into resistance and was broken
      // For breaker bull: look for FAILED bearish OB (was supposed to push price down, didn't)
      
      // Look for a bearish candle in past
      for(int i = shift + 5; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         if(cl >= o) continue;  // need bearish candle
         
         double ob_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         // Check if subsequent price BROKE ABOVE this OB high
         // (which would invalidate it as resistance)
         bool broke_above = false;
         for(int j = i - 1; j > shift; j--)
         {
            double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, j);
            if(h > ob_high + atr * 0.5) { broke_above = true; break; }
         }
         if(!broke_above) continue;
         
         // Now retesting from above (current low near ob_high)
         double dist = MathAbs(c.low - ob_high);
         if(dist > m_zone_proximity_atr * atr) continue;
         if(c.low < ob_high - atr * 0.5) continue;  // shouldn't be far below
         
         // Bullish reaction
         if(c.is_bull || c.lower_wick > c.body * 0.5) return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P46 — BREAKER BLOCK BEAR (mirror)                             |
   //+---------------------------------------------------------------+
   bool DetectBreakerBlockBear(int shift, const CandleAnatomy &c, double atr)
   {
      for(int i = shift + 5; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         if(cl <= o) continue;  // need bullish candle
         
         double ob_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         bool broke_below = false;
         for(int j = i - 1; j > shift; j--)
         {
            double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, j);
            if(l < ob_low - atr * 0.5) { broke_below = true; break; }
         }
         if(!broke_below) continue;
         
         double dist = MathAbs(c.high - ob_low);
         if(dist > m_zone_proximity_atr * atr) continue;
         if(c.high > ob_low + atr * 0.5) continue;
         
         if(c.is_bear || c.upper_wick > c.body * 0.5) return true;
      }
      return false;
   }
};

#endif  // KMP_PATTERNS_C_MQH