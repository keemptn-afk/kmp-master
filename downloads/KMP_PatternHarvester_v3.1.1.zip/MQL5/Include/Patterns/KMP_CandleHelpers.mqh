//+------------------------------------------------------------------+
//|                                          KMP_CandleHelpers.mqh  |
//|                                                                  |
//|  Generic candle measurement utilities used by all pattern        |
//|  detectors. Reference: Steve Nison "Japanese Candlestick         |
//|  Charting Techniques" - chapter on candle anatomy.              |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_CANDLEHELPERS_MQH
#define KMP_CANDLEHELPERS_MQH

//+------------------------------------------------------------------+
//| Candle measurements                                              |
//+------------------------------------------------------------------+
struct CandleAnatomy
{
   double open;
   double high;
   double low;
   double close;
   double body;          // |close - open|
   double upper_wick;    // high - max(open, close)
   double lower_wick;    // min(open, close) - low
   double total_range;   // high - low
   double body_pct;      // body / total_range × 100
   double upper_wick_pct;
   double lower_wick_pct;
   bool   is_bull;       // close > open
   bool   is_bear;       // close < open
   
   void Capture(string symbol, int timeframe, int shift)
   {
      open  = iOpen(symbol, (ENUM_TIMEFRAMES)timeframe, shift);
      high  = iHigh(symbol, (ENUM_TIMEFRAMES)timeframe, shift);
      low   = iLow(symbol, (ENUM_TIMEFRAMES)timeframe, shift);
      close = iClose(symbol, (ENUM_TIMEFRAMES)timeframe, shift);
      
      body = MathAbs(close - open);
      total_range = high - low;
      upper_wick = high - MathMax(open, close);
      lower_wick = MathMin(open, close) - low;
      
      if(total_range > 0)
      {
         body_pct = body / total_range * 100;
         upper_wick_pct = upper_wick / total_range * 100;
         lower_wick_pct = lower_wick / total_range * 100;
      }
      else
      {
         body_pct = 0;
         upper_wick_pct = 0;
         lower_wick_pct = 0;
      }
      
      is_bull = (close > open);
      is_bear = (close < open);
   }
};

//+------------------------------------------------------------------+
//| Get average body size over N bars (excluding current)           |
//+------------------------------------------------------------------+
double AvgBodySize(string symbol, int timeframe, int shift, int n_bars)
{
   double total = 0;
   int count = 0;
   for(int i = shift + 1; i < shift + 1 + n_bars; i++)
   {
      double o = iOpen(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      double c = iClose(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      total += MathAbs(c - o);
      count++;
   }
   return count > 0 ? total / count : 0;
}

//+------------------------------------------------------------------+
//| Get average range (high-low) over N bars                        |
//+------------------------------------------------------------------+
double AvgRange(string symbol, int timeframe, int shift, int n_bars)
{
   double total = 0;
   int count = 0;
   for(int i = shift + 1; i < shift + 1 + n_bars; i++)
   {
      double h = iHigh(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      double l = iLow(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      total += (h - l);
      count++;
   }
   return count > 0 ? total / count : 0;
}

//+------------------------------------------------------------------+
//| Find swing high in last N bars (returns shift, -1 if none)      |
//| Swing high = bar with higher high than n_left and n_right bars  |
//+------------------------------------------------------------------+
int FindSwingHigh(string symbol, int timeframe, int start_shift, 
                   int look_back, int n_left = 3, int n_right = 3)
{
   for(int i = start_shift + n_right; i < start_shift + look_back; i++)
   {
      double h = iHigh(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      bool is_swing = true;
      
      for(int j = 1; j <= n_left && is_swing; j++)
      {
         if(iHigh(symbol, (ENUM_TIMEFRAMES)timeframe, i + j) >= h)
            is_swing = false;
      }
      for(int j = 1; j <= n_right && is_swing; j++)
      {
         if(iHigh(symbol, (ENUM_TIMEFRAMES)timeframe, i - j) >= h)
            is_swing = false;
      }
      
      if(is_swing) return i;
   }
   return -1;
}

//+------------------------------------------------------------------+
//| Find swing low in last N bars                                   |
//+------------------------------------------------------------------+
int FindSwingLow(string symbol, int timeframe, int start_shift,
                  int look_back, int n_left = 3, int n_right = 3)
{
   for(int i = start_shift + n_right; i < start_shift + look_back; i++)
   {
      double l = iLow(symbol, (ENUM_TIMEFRAMES)timeframe, i);
      bool is_swing = true;
      
      for(int j = 1; j <= n_left && is_swing; j++)
      {
         if(iLow(symbol, (ENUM_TIMEFRAMES)timeframe, i + j) <= l)
            is_swing = false;
      }
      for(int j = 1; j <= n_right && is_swing; j++)
      {
         if(iLow(symbol, (ENUM_TIMEFRAMES)timeframe, i - j) <= l)
            is_swing = false;
      }
      
      if(is_swing) return i;
   }
   return -1;
}

//+------------------------------------------------------------------+
//| GetHTF — return higher-timeframe enum for given current TF       |
//|   Used by Phase 3 Cat K (Multi-TF Confluence) patterns.          |
//+------------------------------------------------------------------+
ENUM_TIMEFRAMES GetHTF(ENUM_TIMEFRAMES current)
{
   if(current == PERIOD_M1)  return PERIOD_M15;
   if(current == PERIOD_M5)  return PERIOD_H1;
   if(current == PERIOD_M15) return PERIOD_H1;
   if(current == PERIOD_M30) return PERIOD_H4;
   if(current == PERIOD_H1)  return PERIOD_H4;
   if(current == PERIOD_H4)  return PERIOD_D1;
   if(current == PERIOD_D1)  return PERIOD_W1;
   return current;
}

//+------------------------------------------------------------------+
//| Convert LTF shift to HTF shift (which HTF bar contains it)       |
//+------------------------------------------------------------------+
int LTFtoHTFShift(string symbol, ENUM_TIMEFRAMES ltf, ENUM_TIMEFRAMES htf, int ltf_shift)
{
   datetime ltf_time = iTime(symbol, ltf, ltf_shift);
   if(ltf_time == 0) return -1;
   int htf_shift = iBarShift(symbol, htf, ltf_time, false);
   return htf_shift;
}

//+------------------------------------------------------------------+
//| Get HTF EMA alignment (ALL_BULL/ALL_BEAR/MIXED) at current bar   |
//+------------------------------------------------------------------+
string GetHTFEMAAlignment(string symbol, ENUM_TIMEFRAMES htf, int htf_shift)
{
   double c20  = iClose(symbol, htf, htf_shift);
   // Use simple price-vs-MA check via iMA call would need handles; instead
   // compare consecutive closes as a rough trend proxy
   double c10 = iClose(symbol, htf, htf_shift + 10);
   double c30 = iClose(symbol, htf, htf_shift + 30);
   double c50 = iClose(symbol, htf, htf_shift + 50);
   if(c20 > c10 && c10 > c30 && c30 > c50) return "ALL_BULL";
   if(c20 < c10 && c10 < c30 && c30 < c50) return "ALL_BEAR";
   return "MIXED";
}

#endif  // KMP_CANDLEHELPERS_MQH