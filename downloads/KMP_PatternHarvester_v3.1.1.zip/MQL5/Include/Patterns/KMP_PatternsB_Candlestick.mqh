//+------------------------------------------------------------------+
//|                                  KMP_PatternsB_Candlestick.mqh  |
//|                                                                  |
//|  CATEGORY B: CANDLESTICK PATTERNS (P21-P40)                      |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Steve Nison "Japanese Candlestick Charting Techniques"     |
//|      ISBN 0735201811 (the original western text on candlesticks)|
//|  [2] Thomas Bulkowski "Encyclopedia of Candlestick Charts"      |
//|      ISBN 0470182997 (statistical analysis of patterns)         |
//|  [3] Bulkowski's website: thepatternsite.com                    |
//|                                                                  |
//|  Each pattern definition in this file follows Nison's strict    |
//|  definitions. Where Bulkowski refines criteria, we note both.   |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_B_MQH
#define KMP_PATTERNS_B_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

//+------------------------------------------------------------------+
//| Candlestick Patterns Detector                                   |
//+------------------------------------------------------------------+
class CCandlestickPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   double m_doji_body_pct;       // body % below this = doji (Nison: very small body)
   double m_long_wick_pct;       // wick % above this = "long wick"
   double m_marubozu_body_pct;   // body % above this = marubozu
   
public:
   CCandlestickPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                            m_doji_body_pct(5.0),
                            m_long_wick_pct(60.0),
                            m_marubozu_body_pct(95.0) {}
   
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }
   
   void SetParams(double doji_body_pct, double long_wick_pct, double marubozu_body_pct)
   {
      m_doji_body_pct = doji_body_pct;
      m_long_wick_pct = long_wick_pct;
      m_marubozu_body_pct = marubozu_body_pct;
   }
   
   //+---------------------------------------------------------------+
   //| Detect all Category B patterns                               |
   //+---------------------------------------------------------------+
   void DetectAll(int shift, PatternFlags &flags)
   {
      CandleAnatomy c0;  // current closed bar
      c0.Capture(m_symbol, m_period, shift);
      
      CandleAnatomy c1;  // 1 bar before
      c1.Capture(m_symbol, m_period, shift + 1);
      
      CandleAnatomy c2;  // 2 bars before
      c2.Capture(m_symbol, m_period, shift + 2);
      
      // Skip if data missing
      if(c0.total_range <= 0) return;
      
      double avg_body = AvgBodySize(m_symbol, m_period, shift, 20);
      double avg_range = AvgRange(m_symbol, m_period, shift, 20);
      
      // === SINGLE-CANDLE PATTERNS ===
      flags.P21_Doji              = DetectDoji(c0);
      flags.P22_Dragonfly_Doji    = DetectDragonflyDoji(c0);
      flags.P23_Gravestone_Doji   = DetectGravestoneDoji(c0);
      flags.P24_Hammer            = DetectHammer(c0, c1, avg_range);
      flags.P25_Inverted_Hammer   = DetectInvertedHammer(c0, c1, avg_range);
      flags.P26_Hanging_Man       = DetectHangingMan(c0, c1, avg_range);
      flags.P27_Shooting_Star     = DetectShootingStar(c0, c1, avg_range);
      flags.P40_Marubozu          = DetectMarubozu(c0, avg_body);
      
      // === TWO-CANDLE PATTERNS ===
      flags.P28_Bullish_Engulfing = DetectBullishEngulfing(c0, c1);
      flags.P29_Bearish_Engulfing = DetectBearishEngulfing(c0, c1);
      flags.P30_Piercing_Line     = DetectPiercingLine(c0, c1);
      flags.P31_Dark_Cloud_Cover  = DetectDarkCloudCover(c0, c1);
      flags.P32_Bullish_Harami    = DetectBullishHarami(c0, c1);
      flags.P33_Bearish_Harami    = DetectBearishHarami(c0, c1);
      flags.P38_Tweezer_Bottom    = DetectTweezerBottom(c0, c1);
      flags.P39_Tweezer_Top       = DetectTweezerTop(c0, c1);
      
      // === THREE-CANDLE PATTERNS ===
      flags.P34_Morning_Star      = DetectMorningStar(c0, c1, c2, avg_body);
      flags.P35_Evening_Star      = DetectEveningStar(c0, c1, c2, avg_body);
      flags.P36_Three_White_Soldiers = DetectThreeWhiteSoldiers(c0, c1, c2);
      flags.P37_Three_Black_Crows = DetectThreeBlackCrows(c0, c1, c2);
   }
   
private:
   //+---------------------------------------------------------------+
   //| P21 — DOJI                                                    |
   //|                                                                |
   //|  Theory (Nison ch. 8): "When a market opens and closes at     |
   //|  the same level, it forms a doji line." Body should be very   |
   //|  small relative to range. Indicates indecision/equilibrium.   |
   //|                                                                |
   //|  Definition: body_pct < 5% of total range                     |
   //+---------------------------------------------------------------+
   bool DetectDoji(const CandleAnatomy &c)
   {
      if(c.total_range <= 0) return false;
      return c.body_pct < m_doji_body_pct;
   }
   
   //+---------------------------------------------------------------+
   //| P22 — DRAGONFLY DOJI                                          |
   //|                                                                |
   //|  Theory (Nison ch. 8): "Forms when open, high, and close are  |
   //|  the same (or nearly so), and a long lower wick exists.       |
   //|  Bullish reversal at bottoms."                                 |
   //|                                                                |
   //|  Definition:                                                   |
   //|    - body very small (< 5%)                                    |
   //|    - upper wick very small (< 10%)                             |
   //|    - lower wick large (> 70%)                                  |
   //+---------------------------------------------------------------+
   bool DetectDragonflyDoji(const CandleAnatomy &c)
   {
      if(c.total_range <= 0) return false;
      return c.body_pct < m_doji_body_pct &&
             c.upper_wick_pct < 10.0 &&
             c.lower_wick_pct > 70.0;
   }
   
   //+---------------------------------------------------------------+
   //| P23 — GRAVESTONE DOJI                                         |
   //|                                                                |
   //|  Theory (Nison ch. 8): Mirror of dragonfly. Open, low, close  |
   //|  near same level with long upper wick. Bearish reversal.      |
   //+---------------------------------------------------------------+
   bool DetectGravestoneDoji(const CandleAnatomy &c)
   {
      if(c.total_range <= 0) return false;
      return c.body_pct < m_doji_body_pct &&
             c.lower_wick_pct < 10.0 &&
             c.upper_wick_pct > 70.0;
   }
   
   //+---------------------------------------------------------------+
   //| P24 — HAMMER                                                  |
   //|                                                                |
   //|  Theory (Nison ch. 4): "Has a small real body at the upper    |
   //|  end of the trading range, with a long lower wick (at least  |
   //|  twice the body) and little to no upper wick. Forms during    |
   //|  a downtrend."                                                 |
   //|                                                                |
   //|  Definition:                                                   |
   //|    - body_pct < 35%                                            |
   //|    - lower_wick > 2 × body                                     |
   //|    - upper_wick < body                                         |
   //|    - prior bar was bearish (downtrend context)                 |
   //+---------------------------------------------------------------+
   bool DetectHammer(const CandleAnatomy &c, const CandleAnatomy &prev, double avg_range)
   {
      if(c.total_range <= 0 || c.body <= 0) return false;
      
      bool small_body = c.body_pct < 35.0;
      bool long_lower = c.lower_wick > 2.0 * c.body;
      bool small_upper = c.upper_wick < c.body;
      bool downtrend = prev.is_bear;
      bool meaningful_size = c.total_range > avg_range * 0.5;
      
      return small_body && long_lower && small_upper && downtrend && meaningful_size;
   }
   
   //+---------------------------------------------------------------+
   //| P25 — INVERTED HAMMER                                         |
   //|                                                                |
   //|  Theory (Nison ch. 5): Like a hammer but with long upper wick.|
   //|  Appears at bottoms, indicates potential reversal. Less       |
   //|  reliable than hammer (Bulkowski stats: ~60% accuracy).      |
   //+---------------------------------------------------------------+
   bool DetectInvertedHammer(const CandleAnatomy &c, const CandleAnatomy &prev, double avg_range)
   {
      if(c.total_range <= 0 || c.body <= 0) return false;
      
      bool small_body = c.body_pct < 35.0;
      bool long_upper = c.upper_wick > 2.0 * c.body;
      bool small_lower = c.lower_wick < c.body;
      bool downtrend = prev.is_bear;
      bool meaningful_size = c.total_range > avg_range * 0.5;
      
      return small_body && long_upper && small_lower && downtrend && meaningful_size;
   }
   
   //+---------------------------------------------------------------+
   //| P26 — HANGING MAN                                             |
   //|                                                                |
   //|  Theory (Nison ch. 4): Same shape as hammer but appears in   |
   //|  uptrend. Bearish reversal warning.                           |
   //+---------------------------------------------------------------+
   bool DetectHangingMan(const CandleAnatomy &c, const CandleAnatomy &prev, double avg_range)
   {
      if(c.total_range <= 0 || c.body <= 0) return false;
      
      bool small_body = c.body_pct < 35.0;
      bool long_lower = c.lower_wick > 2.0 * c.body;
      bool small_upper = c.upper_wick < c.body;
      bool uptrend = prev.is_bull;
      bool meaningful_size = c.total_range > avg_range * 0.5;
      
      return small_body && long_lower && small_upper && uptrend && meaningful_size;
   }
   
   //+---------------------------------------------------------------+
   //| P27 — SHOOTING STAR                                           |
   //|                                                                |
   //|  Theory (Nison ch. 5): Mirror of inverted hammer in uptrend. |
   //|  Long upper wick = rejection of higher prices. Bearish.      |
   //+---------------------------------------------------------------+
   bool DetectShootingStar(const CandleAnatomy &c, const CandleAnatomy &prev, double avg_range)
   {
      if(c.total_range <= 0 || c.body <= 0) return false;
      
      bool small_body = c.body_pct < 35.0;
      bool long_upper = c.upper_wick > 2.0 * c.body;
      bool small_lower = c.lower_wick < c.body;
      bool uptrend = prev.is_bull;
      bool meaningful_size = c.total_range > avg_range * 0.5;
      
      return small_body && long_upper && small_lower && uptrend && meaningful_size;
   }
   
   //+---------------------------------------------------------------+
   //| P28 — BULLISH ENGULFING                                       |
   //|                                                                |
   //|  Theory (Nison ch. 6): "First a small black candle, then a   |
   //|  large white body that fully envelops the prior body."        |
   //|                                                                |
   //|  Strict definition (Nison):                                    |
   //|    - prev candle bearish, current candle bullish               |
   //|    - current open <= prev close                                |
   //|    - current close >= prev open (engulfs body)                 |
   //+---------------------------------------------------------------+
   bool DetectBullishEngulfing(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bear || !curr.is_bull) return false;
      if(prev.body <= 0) return false;
      
      // Current opens below prev close, closes above prev open
      bool engulfs = (curr.open <= prev.close) && (curr.close >= prev.open);
      bool meaningful = curr.body > prev.body * 0.8;  // at least 80% of prev
      
      return engulfs && meaningful;
   }
   
   //+---------------------------------------------------------------+
   //| P29 — BEARISH ENGULFING                                       |
   //+---------------------------------------------------------------+
   bool DetectBearishEngulfing(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bull || !curr.is_bear) return false;
      if(prev.body <= 0) return false;
      
      bool engulfs = (curr.open >= prev.close) && (curr.close <= prev.open);
      bool meaningful = curr.body > prev.body * 0.8;
      
      return engulfs && meaningful;
   }
   
   //+---------------------------------------------------------------+
   //| P30 — PIERCING LINE                                           |
   //|                                                                |
   //|  Theory (Nison ch. 6): "First a strong black candle, then    |
   //|  white candle opens below black's low and closes above the    |
   //|  midpoint of the black candle's body."                        |
   //+---------------------------------------------------------------+
   bool DetectPiercingLine(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bear || !curr.is_bull) return false;
      if(prev.body <= 0) return false;
      
      double prev_midpoint = (prev.open + prev.close) / 2.0;
      
      bool gap_down = curr.open < prev.low;
      bool penetrates = curr.close > prev_midpoint && curr.close < prev.open;
      
      return gap_down && penetrates;
   }
   
   //+---------------------------------------------------------------+
   //| P31 — DARK CLOUD COVER                                        |
   //|                                                                |
   //|  Theory: Mirror of piercing line.                              |
   //+---------------------------------------------------------------+
   bool DetectDarkCloudCover(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bull || !curr.is_bear) return false;
      if(prev.body <= 0) return false;
      
      double prev_midpoint = (prev.open + prev.close) / 2.0;
      
      bool gap_up = curr.open > prev.high;
      bool penetrates = curr.close < prev_midpoint && curr.close > prev.open;
      
      return gap_up && penetrates;
   }
   
   //+---------------------------------------------------------------+
   //| P32 — BULLISH HARAMI                                          |
   //|                                                                |
   //|  Theory (Nison ch. 6): "Harami means 'pregnant' in Japanese. |
   //|  Small candle is fully contained within the previous large    |
   //|  candle's body."                                               |
   //+---------------------------------------------------------------+
   bool DetectBullishHarami(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bear) return false;  // prev is large bearish
      if(prev.body <= 0) return false;
      
      // Current body fully contained within prev body
      double curr_body_high = MathMax(curr.open, curr.close);
      double curr_body_low = MathMin(curr.open, curr.close);
      
      bool contained = curr_body_high < prev.open && curr_body_low > prev.close;
      bool small_curr = curr.body < prev.body * 0.6;
      bool curr_bullish = curr.is_bull;
      
      return contained && small_curr && curr_bullish;
   }
   
   //+---------------------------------------------------------------+
   //| P33 — BEARISH HARAMI                                          |
   //+---------------------------------------------------------------+
   bool DetectBearishHarami(const CandleAnatomy &curr, const CandleAnatomy &prev)
   {
      if(!prev.is_bull) return false;
      if(prev.body <= 0) return false;
      
      double curr_body_high = MathMax(curr.open, curr.close);
      double curr_body_low = MathMin(curr.open, curr.close);
      
      bool contained = curr_body_high < prev.close && curr_body_low > prev.open;
      bool small_curr = curr.body < prev.body * 0.6;
      bool curr_bearish = curr.is_bear;
      
      return contained && small_curr && curr_bearish;
   }
   
   //+---------------------------------------------------------------+
   //| P34 — MORNING STAR (3-candle bullish reversal)                |
   //|                                                                |
   //|  Theory (Nison ch. 7): "Three-candle reversal at bottoms.    |
   //|  1) Long bearish candle. 2) Small candle (star) gapping       |
   //|  down. 3) Long bullish candle that closes well into the      |
   //|  first candle's body."                                         |
   //+---------------------------------------------------------------+
   bool DetectMorningStar(const CandleAnatomy &c0, const CandleAnatomy &c1,
                            const CandleAnatomy &c2, double avg_body)
   {
      // c2 = first (oldest), c1 = middle (star), c0 = third (newest)
      if(!c2.is_bear) return false;                  // first must be bearish
      if(c2.body < avg_body * 0.8) return false;     // first must be substantial
      if(c1.body > c2.body * 0.5) return false;      // star must be small
      if(!c0.is_bull) return false;                   // third must be bullish
      if(c0.body < avg_body * 0.8) return false;     // third must be substantial
      
      double c2_midpoint = (c2.open + c2.close) / 2.0;
      bool penetrates = c0.close > c2_midpoint;
      
      return penetrates;
   }
   
   //+---------------------------------------------------------------+
   //| P35 — EVENING STAR (3-candle bearish reversal)                |
   //+---------------------------------------------------------------+
   bool DetectEveningStar(const CandleAnatomy &c0, const CandleAnatomy &c1,
                            const CandleAnatomy &c2, double avg_body)
   {
      if(!c2.is_bull) return false;
      if(c2.body < avg_body * 0.8) return false;
      if(c1.body > c2.body * 0.5) return false;
      if(!c0.is_bear) return false;
      if(c0.body < avg_body * 0.8) return false;
      
      double c2_midpoint = (c2.open + c2.close) / 2.0;
      bool penetrates = c0.close < c2_midpoint;
      
      return penetrates;
   }
   
   //+---------------------------------------------------------------+
   //| P36 — THREE WHITE SOLDIERS                                    |
   //|                                                                |
   //|  Theory (Nison ch. 7): Three consecutive long bullish candles |
   //|  with each closing higher and opening within prior body.      |
   //+---------------------------------------------------------------+
   bool DetectThreeWhiteSoldiers(const CandleAnatomy &c0, const CandleAnatomy &c1,
                                    const CandleAnatomy &c2)
   {
      // All three bullish
      if(!c0.is_bull || !c1.is_bull || !c2.is_bull) return false;
      
      // Each closes higher than the last
      if(c0.close <= c1.close || c1.close <= c2.close) return false;
      
      // Each opens within previous body (not gap up)
      bool c1_within_c2 = (c1.open >= c2.open && c1.open <= c2.close);
      bool c0_within_c1 = (c0.open >= c1.open && c0.open <= c1.close);
      
      // Bodies should be substantial
      bool good_body_c2 = c2.body_pct > 60;
      bool good_body_c1 = c1.body_pct > 60;
      bool good_body_c0 = c0.body_pct > 60;
      
      return c1_within_c2 && c0_within_c1 && good_body_c0 && good_body_c1 && good_body_c2;
   }
   
   //+---------------------------------------------------------------+
   //| P37 — THREE BLACK CROWS                                       |
   //+---------------------------------------------------------------+
   bool DetectThreeBlackCrows(const CandleAnatomy &c0, const CandleAnatomy &c1,
                                const CandleAnatomy &c2)
   {
      if(!c0.is_bear || !c1.is_bear || !c2.is_bear) return false;
      if(c0.close >= c1.close || c1.close >= c2.close) return false;
      
      bool c1_within_c2 = (c1.open <= c2.open && c1.open >= c2.close);
      bool c0_within_c1 = (c0.open <= c1.open && c0.open >= c1.close);
      
      bool good_body_c2 = c2.body_pct > 60;
      bool good_body_c1 = c1.body_pct > 60;
      bool good_body_c0 = c0.body_pct > 60;
      
      return c1_within_c2 && c0_within_c1 && good_body_c0 && good_body_c1 && good_body_c2;
   }
   
   //+---------------------------------------------------------------+
   //| P38 — TWEEZER BOTTOM                                          |
   //|                                                                |
   //|  Theory (Nison ch. 6): Two candles with same/very close lows  |
   //|  forming a "tweezer" pattern at support. Bullish reversal.   |
   //|                                                                |
   //|  Definition: |c0.low - c1.low| < 10% of avg_range             |
   //+---------------------------------------------------------------+
   bool DetectTweezerBottom(const CandleAnatomy &c0, const CandleAnatomy &c1)
   {
      double tolerance = (c0.total_range + c1.total_range) / 2.0 * 0.10;
      bool same_low = MathAbs(c0.low - c1.low) < tolerance;
      
      // First bear, second bull (reversal)
      bool reversal = c1.is_bear && c0.is_bull;
      
      return same_low && reversal;
   }
   
   //+---------------------------------------------------------------+
   //| P39 — TWEEZER TOP                                             |
   //+---------------------------------------------------------------+
   bool DetectTweezerTop(const CandleAnatomy &c0, const CandleAnatomy &c1)
   {
      double tolerance = (c0.total_range + c1.total_range) / 2.0 * 0.10;
      bool same_high = MathAbs(c0.high - c1.high) < tolerance;
      
      bool reversal = c1.is_bull && c0.is_bear;
      
      return same_high && reversal;
   }
   
   //+---------------------------------------------------------------+
   //| P40 — MARUBOZU                                                |
   //|                                                                |
   //|  Theory (Nison ch. 3): "Bald" or "shaven" candle with no     |
   //|  wicks (or very tiny). Indicates strong continuation.         |
   //|                                                                |
   //|  Definition: body > 95% of total range                         |
   //|              total range > 80% of avg range (substantial)     |
   //+---------------------------------------------------------------+
   bool DetectMarubozu(const CandleAnatomy &c, double avg_body)
   {
      if(c.total_range <= 0) return false;
      bool full_body = c.body_pct > m_marubozu_body_pct;
      bool substantial = c.body > avg_body * 1.2;
      return full_body && substantial;
   }
};

#endif  // KMP_PATTERNS_B_MQH