//+------------------------------------------------------------------+
//|                                  KMP_PatternsF_SmartMoney.mqh   |
//|                                                                  |
//|  CATEGORY F: SMART MONEY CONCEPTS (P71-P80)                      |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] ICT (Inner Circle Trader) — Michael J. Huddleston           |
//|      Concepts: Fair Value Gap (FVG), Liquidity, Mitigation      |
//|      Reference: Michael J. Huddleston's video curriculum         |
//|  [2] Markets in Profile — James Dalton                           |
//|      Reference: ISBN 0470039094 - Volume Profile / POC          |
//|  [3] "Trading in the Zone" — Mark Douglas                        |
//|      Smart money flow concepts                                   |
//|                                                                  |
//|  NOTE: SMC concepts are popular but less academically validated |
//|  than classical TA. Use as confluence with other categories.    |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_F_MQH
#define KMP_PATTERNS_F_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CSmartMoneyPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_lookback_bars;
   double m_min_fvg_atr;          // FVG must be at least this size
   double m_equal_level_atr;       // tolerance for "equal" highs/lows
   
public:
   CSmartMoneyPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                           m_lookback_bars(50),
                           m_min_fvg_atr(0.3),
                           m_equal_level_atr(0.15) {}
   
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }
   
   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      
      flags.P71_Fair_Value_Gap_Bull = DetectFVGBull(shift, atr);
      flags.P72_Fair_Value_Gap_Bear = DetectFVGBear(shift, atr);
      flags.P73_Liquidity_Grab_Bull = DetectLiquidityGrabBull(shift, atr);
      flags.P74_Liquidity_Grab_Bear = DetectLiquidityGrabBear(shift, atr);
      flags.P75_Equal_Highs_Sweep = DetectEqualHighsSweep(shift, atr);
      flags.P76_Equal_Lows_Sweep = DetectEqualLowsSweep(shift, atr);
      flags.P77_Mitigation_Block_Bull = DetectMitigationBull(shift, atr);
      flags.P78_Mitigation_Block_Bear = DetectMitigationBear(shift, atr);
      flags.P79_POC_Bounce_Long = DetectPOCBounceLong(shift, atr);
      flags.P80_POC_Bounce_Short = DetectPOCBounceShort(shift, atr);
   }
   
private:
   //+---------------------------------------------------------------+
   //| P71 — FAIR VALUE GAP BULL (FVG)                              |
   //|                                                                |
   //|  Theory (ICT): A 3-candle pattern where there is a "gap" or  |
   //|  imbalance between candle 1 and candle 3.                    |
   //|                                                                |
   //|  Bullish FVG: high of candle 1 < low of candle 3              |
   //|    (price moved so fast that no trades happened between)      |
   //|                                                                |
   //|  When price returns to fill the FVG, expect bullish reaction.|
   //|                                                                |
   //|  Detection:                                                    |
   //|  - Look back 5-30 bars                                         |
   //|  - Find FVG (high[i+2] < low[i])                               |
   //|  - Verify FVG is meaningful size (> 0.3×ATR)                  |
   //|  - Current price has returned to the gap                       |
   //+---------------------------------------------------------------+
   bool DetectFVGBull(int shift, double atr)
   {
      double current_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      // Scan for FVG in last lookback bars (need 3 consecutive bars)
      for(int i = shift + 3; i < shift + m_lookback_bars; i++)
      {
         // FVG bull: gap between bar i (older) and bar i-2 (newer)
         double older_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double newer_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 2);
         
         if(newer_low <= older_high) continue;  // no gap
         
         double gap_size = newer_low - older_high;
         if(gap_size < m_min_fvg_atr * atr) continue;  // too small
         
         // FVG zone: between older_high and newer_low
         // Current price returning to the gap (within or just below newer_low)
         if(current_low > newer_low + atr * 0.1) continue;  // not yet returned
         if(current_high < older_high - atr * 0.5) continue;  // gone too far below
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P72 — FAIR VALUE GAP BEAR                                     |
   //+---------------------------------------------------------------+
   bool DetectFVGBear(int shift, double atr)
   {
      double current_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      for(int i = shift + 3; i < shift + m_lookback_bars; i++)
      {
         double older_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double newer_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 2);
         
         if(newer_high >= older_low) continue;  // no gap
         
         double gap_size = older_low - newer_high;
         if(gap_size < m_min_fvg_atr * atr) continue;
         
         if(current_high < newer_high - atr * 0.1) continue;
         if(current_low > older_low + atr * 0.5) continue;
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P73 — LIQUIDITY GRAB BULL                                     |
   //|                                                                |
   //|  Theory (ICT): "Stop hunt below an obvious low" then         |
   //|  reverse. Different from sweep — this is more aggressive    |
   //|  with bigger reversal candle.                                  |
   //|                                                                |
   //|  Detection: low of recent bars went below previous swing low |
   //|  by significant margin (>0.5×ATR), then current bar is       |
   //|  strongly bullish.                                            |
   //+---------------------------------------------------------------+
   bool DetectLiquidityGrabBull(int shift, double atr)
   {
      // Find a swing low at least 5 bars ago
      int sl = FindSwingLow(m_symbol, m_period, shift + 5, m_lookback_bars, 3, 3);
      if(sl < 0) return false;
      
      double swing_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl);
      
      // Check if any of the last 5 bars dipped >0.5×ATR below swing_low
      bool grabbed = false;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(l < swing_low - 0.5 * atr) { grabbed = true; break; }
      }
      if(!grabbed) return false;
      
      // Current bar strong bullish (closes above swing_low + 0.3×ATR)
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      bool strong_bull = current_close > current_open && 
                         current_close > swing_low + 0.3 * atr;
      
      return strong_bull;
   }
   
   //+---------------------------------------------------------------+
   //| P74 — LIQUIDITY GRAB BEAR                                     |
   //+---------------------------------------------------------------+
   bool DetectLiquidityGrabBear(int shift, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 5, m_lookback_bars, 3, 3);
      if(sh < 0) return false;
      
      double swing_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh);
      
      bool grabbed = false;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(h > swing_high + 0.5 * atr) { grabbed = true; break; }
      }
      if(!grabbed) return false;
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      bool strong_bear = current_close < current_open && 
                         current_close < swing_high - 0.3 * atr;
      
      return strong_bear;
   }
   
   //+---------------------------------------------------------------+
   //| P75 — EQUAL HIGHS SWEEP                                       |
   //|                                                                |
   //|  Theory (ICT): When 2+ swing highs cluster at the same level,|
   //|  stops accumulate above. Sweep = price spikes above and       |
   //|  reverses, indicating institutional liquidity grab.          |
   //+---------------------------------------------------------------+
   bool DetectEqualHighsSweep(int shift, double atr)
   {
      // Find 2 swing highs at similar level
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 5, m_lookback_bars, 3, 3);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      // Equal highs (within tight tolerance)
      if(MathAbs(h1 - h2) > m_equal_level_atr * atr) return false;
      
      double level = MathMax(h1, h2);
      
      // Current bar swept above + reversed
      double current_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      bool swept = current_high > level + 0.1 * atr;
      bool reversed = current_close < level;
      
      return swept && reversed;
   }
   
   //+---------------------------------------------------------------+
   //| P76 — EQUAL LOWS SWEEP                                        |
   //+---------------------------------------------------------------+
   bool DetectEqualLowsSweep(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_lookback_bars, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 5, m_lookback_bars, 3, 3);
      if(sl2 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      if(MathAbs(l1 - l2) > m_equal_level_atr * atr) return false;
      
      double level = MathMin(l1, l2);
      
      double current_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      bool swept = current_low < level - 0.1 * atr;
      bool reversed = current_close > level;
      
      return swept && reversed;
   }
   
   //+---------------------------------------------------------------+
   //| P77 — MITIGATION BLOCK BULL                                   |
   //|                                                                |
   //|  Theory (ICT): "Mitigation" = price returns to a level where |
   //|  institutional orders were placed. Mitigation block bull =   |
   //|  return to the origin of a strong bullish move (where stops |
   //|  were taken from prior structure).                            |
   //|                                                                |
   //|  Simplified: Find a strong bullish impulse origin candle,    |
   //|  check if current price returned to that origin range.        |
   //+---------------------------------------------------------------+
   bool DetectMitigationBull(int shift, double atr)
   {
      double current_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      // Find strong bullish impulse origin in last N bars
      for(int i = shift + 5; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double l = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         // Origin must be bullish with strong body
         if(cl <= o) continue;
         if(cl - o < 1.5 * atr) continue;
         
         // Verify subsequent move was strong bullish
         double next_3_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 3);
         if(next_3_high - cl < 2 * atr) continue;
         
         // Current price returned to origin's low
         if(MathAbs(current_low - l) > 0.5 * atr) continue;
         if(current_close < l - atr) continue;  // not too far below
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P78 — MITIGATION BLOCK BEAR                                   |
   //+---------------------------------------------------------------+
   bool DetectMitigationBear(int shift, double atr)
   {
      double current_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      for(int i = shift + 5; i < shift + m_lookback_bars; i++)
      {
         double o = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         double h = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         
         if(cl >= o) continue;
         if(o - cl < 1.5 * atr) continue;
         
         double next_3_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, i - 3);
         if(cl - next_3_low < 2 * atr) continue;
         
         if(MathAbs(current_high - h) > 0.5 * atr) continue;
         if(current_close > h + atr) continue;
         
         return true;
      }
      return false;
   }
   
   //+---------------------------------------------------------------+
   //| P79 — POINT OF CONTROL (POC) BOUNCE LONG                     |
   //|                                                                |
   //|  Theory (Volume Profile / Markets in Profile):                |
   //|  POC = price level with the most trading volume in a session.|
   //|  Acts as magnet/support. Bounces off POC are tradeable.      |
   //|                                                                |
   //|  Simplified detection: find the bar with highest tick volume |
   //|  in last N bars. Use its midpoint as approximate POC.         |
   //|  Current price near POC + bullish = bounce long.              |
   //+---------------------------------------------------------------+
   bool DetectPOCBounceLong(int shift, double atr)
   {
      // Find highest-volume bar in last 30 bars
      long max_volume = 0;
      int max_idx = -1;
      for(int i = shift + 1; i < shift + 30 && i < shift + m_lookback_bars; i++)
      {
         long v = iTickVolume(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(v > max_volume) { max_volume = v; max_idx = i; }
      }
      if(max_idx < 0) return false;
      
      double poc_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, max_idx);
      double poc_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, max_idx);
      double poc = (poc_open + poc_close) / 2.0;
      
      // Current price near POC
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      // Within 0.3×ATR of POC + bullish bar
      bool near_poc = MathAbs(current_low - poc) < 0.3 * atr;
      bool bullish = current_close > current_open;
      
      return near_poc && bullish;
   }
   
   //+---------------------------------------------------------------+
   //| P80 — POC BOUNCE SHORT                                        |
   //+---------------------------------------------------------------+
   bool DetectPOCBounceShort(int shift, double atr)
   {
      long max_volume = 0;
      int max_idx = -1;
      for(int i = shift + 1; i < shift + 30 && i < shift + m_lookback_bars; i++)
      {
         long v = iTickVolume(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(v > max_volume) { max_volume = v; max_idx = i; }
      }
      if(max_idx < 0) return false;
      
      double poc_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, max_idx);
      double poc_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, max_idx);
      double poc = (poc_open + poc_close) / 2.0;
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      double current_open = iOpen(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      bool near_poc = MathAbs(current_high - poc) < 0.3 * atr;
      bool bearish = current_close < current_open;
      
      return near_poc && bearish;
   }
};

#endif  // KMP_PATTERNS_F_MQH