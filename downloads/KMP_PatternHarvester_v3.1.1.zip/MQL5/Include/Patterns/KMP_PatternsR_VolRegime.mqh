//+------------------------------------------------------------------+
//|                                  KMP_PatternsR_VolRegime.mqh   |
//|  CATEGORY R: VOLATILITY REGIME (P175-P177)                       |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] John Bollinger — "Bollinger on Bollinger Bands" (2001).    |
//|      Squeeze (low BB width) → expansion breakout.                |
//|  [2] Tony Crabel — "Day Trading with Short Term Price Patterns" |
//|      (1990). Volatility cycle: contraction → expansion.          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_R_MQH
#define KMP_PATTERNS_R_MQH

#include "../KMP_Structures.mqh"

class CVolRegimePatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

public:
   CVolRegimePatterns() : m_symbol(""), m_period(PERIOD_CURRENT) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap,
                   const IndicatorSnapshot &prev_snap, bool prev_valid)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P175_BB_Squeeze_Breakout_Long  = DetectBBSqueezeLong (shift, snap, prev_snap, prev_valid);
      flags.P176_BB_Squeeze_Breakout_Short = DetectBBSqueezeShort(shift, snap, prev_snap, prev_valid);
      flags.P177_ATR_Expansion             = DetectATRExpansion  (shift, snap, prev_snap, prev_valid);
   }

private:
   //+---------------------------------------------------------------+
   //| P175 — BB Squeeze Breakout Long                               |
   //|  Prior bar was in BB Squeeze (snap.bb_squeeze=true) AND       |
   //|  current bar closes ABOVE BB middle band + bullish.           |
   //+---------------------------------------------------------------+
   bool DetectBBSqueezeLong(int shift, const IndicatorSnapshot &snap,
                             const IndicatorSnapshot &prev_snap, bool prev_valid)
   {
      if(!prev_valid) return false;
      if(!prev_snap.bb_squeeze) return false;          // previous needs squeeze
      if(snap.bb_squeeze) return false;                // current must have BROKEN out
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close <= snap.bb_middle) return false;
      return (cur_close > cur_open);
   }

   bool DetectBBSqueezeShort(int shift, const IndicatorSnapshot &snap,
                               const IndicatorSnapshot &prev_snap, bool prev_valid)
   {
      if(!prev_valid) return false;
      if(!prev_snap.bb_squeeze) return false;
      if(snap.bb_squeeze) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close >= snap.bb_middle) return false;
      return (cur_close < cur_open);
   }

   //+---------------------------------------------------------------+
   //| P177 — ATR Expansion (BOTH directions)                         |
   //|  ATR ratio (atr_14 / atr_50) jumps from below 1.0 to above 2.0|
   //|  in current bar — sudden volatility regime change.             |
   //+---------------------------------------------------------------+
   bool DetectATRExpansion(int shift, const IndicatorSnapshot &snap,
                            const IndicatorSnapshot &prev_snap, bool prev_valid)
   {
      if(!prev_valid) return false;
      if(snap.atr_ratio < 2.0) return false;
      if(prev_snap.atr_ratio >= 1.5) return false;     // need fresh expansion
      // Confirm with bar that has body (not just wick)
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      double h = iHigh (m_symbol, m_period, shift);
      double l = iLow  (m_symbol, m_period, shift);
      double range = h - l;
      double body  = MathAbs(c - o);
      if(range <= 0) return false;
      return body / range >= 0.4;  // meaningful body
   }
};

#endif  // KMP_PATTERNS_R_MQH