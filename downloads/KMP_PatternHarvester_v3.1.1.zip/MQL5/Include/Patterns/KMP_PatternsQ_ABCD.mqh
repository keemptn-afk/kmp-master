//+------------------------------------------------------------------+
//|                                  KMP_PatternsQ_ABCD.mqh         |
//|  CATEGORY Q: ABCD / THREE DRIVES (P171-P174)                     |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Scott Carney — "Harmonic Trading Vol.2" (2010). ABCD as    |
//|      simplified harmonic without strict Fib on AB/BC.           |
//|  [2] Larry Connors — "Street Smarts" (1995). Three Drives        |
//|      pattern — 3 successive HL/LH then sharp reversal.          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_Q_MQH
#define KMP_PATTERNS_Q_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CABCDPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_swing_lookback;

public:
   CABCDPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                     m_swing_lookback(50) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int swing_lb = 50) { m_swing_lookback = swing_lb; }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      flags.P171_ABCD_Bull         = DetectABCDBull(shift, atr);
      flags.P172_ABCD_Bear         = DetectABCDBear(shift, atr);
      flags.P173_Three_Drives_Bull = DetectThreeDrivesBull(shift, atr);
      flags.P174_Three_Drives_Bear = DetectThreeDrivesBear(shift, atr);
   }

private:
   //+---------------------------------------------------------------+
   //| P171 — ABCD Bull (4-leg, simplified harmonic)                 |
   //|  A=swing high, B=swing low after A, C=swing high after B,    |
   //|  D=current = swing low. Require CD ≈ AB (within 30% of AB).  |
   //+---------------------------------------------------------------+
   bool DetectABCDBull(int shift, double atr)
   {
      // Find recent swing low candidate D = shift area
      // Walk back: C = swing high before, B = swing low before C, A = swing high before B
      int c_idx = FindSwingHigh(m_symbol, m_period, shift + 2, m_swing_lookback, 2, 2);
      if(c_idx < 0) return false;
      int b_idx = FindSwingLow (m_symbol, m_period, c_idx + 4, m_swing_lookback, 2, 2);
      if(b_idx < 0) return false;
      int a_idx = FindSwingHigh(m_symbol, m_period, b_idx + 4, m_swing_lookback, 2, 2);
      if(a_idx < 0) return false;
      double A = iHigh(m_symbol, m_period, a_idx);
      double B = iLow (m_symbol, m_period, b_idx);
      double C = iHigh(m_symbol, m_period, c_idx);
      double D = iLow (m_symbol, m_period, shift);
      double AB = A - B;
      double CD = C - D;
      if(AB <= 1.0 * atr || CD <= 1.0 * atr) return false;
      // CD ≈ AB (within ±30%)
      double ratio = CD / AB;
      if(ratio < 0.7 || ratio > 1.3) return false;
      // D must be at or near a meaningful low + bullish bar
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectABCDBear(int shift, double atr)
   {
      int c_idx = FindSwingLow (m_symbol, m_period, shift + 2, m_swing_lookback, 2, 2);
      if(c_idx < 0) return false;
      int b_idx = FindSwingHigh(m_symbol, m_period, c_idx + 4, m_swing_lookback, 2, 2);
      if(b_idx < 0) return false;
      int a_idx = FindSwingLow (m_symbol, m_period, b_idx + 4, m_swing_lookback, 2, 2);
      if(a_idx < 0) return false;
      double A = iLow (m_symbol, m_period, a_idx);
      double B = iHigh(m_symbol, m_period, b_idx);
      double C = iLow (m_symbol, m_period, c_idx);
      double D = iHigh(m_symbol, m_period, shift);
      double AB = B - A;
      double CD = D - C;
      if(AB <= 1.0 * atr || CD <= 1.0 * atr) return false;
      double ratio = CD / AB;
      if(ratio < 0.7 || ratio > 1.3) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }

   //+---------------------------------------------------------------+
   //| P173 — Three Drives Bull                                      |
   //|  3 successive LOWER lows (3 drives down to a bottom), then    |
   //|  current bar reverses bullish. = "Three drives to a bottom".  |
   //+---------------------------------------------------------------+
   bool DetectThreeDrivesBull(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 1, m_swing_lookback, 2, 2);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_swing_lookback, 2, 2);
      if(sl2 < 0) return false;
      int sl3 = FindSwingLow(m_symbol, m_period, sl2 + 4, m_swing_lookback, 2, 2);
      if(sl3 < 0) return false;
      double l1 = iLow(m_symbol, m_period, sl1);  // newest
      double l2 = iLow(m_symbol, m_period, sl2);
      double l3 = iLow(m_symbol, m_period, sl3);  // oldest
      // Three drives: each lower than previous (bearish exhaustion)
      // For Bull pattern: 3 successive LOWER LOWS then bullish reversal
      if(!(l1 < l2 && l2 < l3)) return false;
      // Spacing similar (within 50%)
      int gap1 = sl2 - sl1;
      int gap2 = sl3 - sl2;
      if(gap1 <= 0 || gap2 <= 0) return false;
      double gap_ratio = (double)gap1 / (double)gap2;
      if(gap_ratio < 0.5 || gap_ratio > 2.0) return false;
      // Current bar bullish (reversal)
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectThreeDrivesBear(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 1, m_swing_lookback, 2, 2);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_swing_lookback, 2, 2);
      if(sh2 < 0) return false;
      int sh3 = FindSwingHigh(m_symbol, m_period, sh2 + 4, m_swing_lookback, 2, 2);
      if(sh3 < 0) return false;
      double h1 = iHigh(m_symbol, m_period, sh1);
      double h2 = iHigh(m_symbol, m_period, sh2);
      double h3 = iHigh(m_symbol, m_period, sh3);
      if(!(h1 > h2 && h2 > h3)) return false;
      int gap1 = sh2 - sh1;
      int gap2 = sh3 - sh2;
      if(gap1 <= 0 || gap2 <= 0) return false;
      double gap_ratio = (double)gap1 / (double)gap2;
      if(gap_ratio < 0.5 || gap_ratio > 2.0) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }
};

#endif  // KMP_PATTERNS_Q_MQH