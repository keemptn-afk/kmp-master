//+------------------------------------------------------------------+
//|                                  KMP_PatternsD_Structure.mqh    |
//|                                                                  |
//|  CATEGORY D: PRICE ACTION & MARKET STRUCTURE (P51-P60)           |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Al Brooks "Trading Price Action" (3-volume series)         |
//|      ISBN 1118066669 (Trends), 1118066685 (Reversals)           |
//|  [2] ICT (Inner Circle Trader) Market Structure concepts        |
//|      - Break of Structure (BOS)                                  |
//|      - Change of Character (CHoCH)                               |
//|      - Liquidity sweeps                                          |
//|  [3] Wyckoff Phases (Accumulation/Distribution)                 |
//|  [4] Edwards & Magee — Dow Theory (higher highs / lower lows)   |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_D_MQH
#define KMP_PATTERNS_D_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CStructurePatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_lookback_bars;
   int    m_swing_left;       // bars left of pivot (Brooks: 3-5 typical)
   int    m_swing_right;
   double m_sweep_pip_atr;    // how far to sweep beyond level
   
public:
   CStructurePatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                          m_lookback_bars(50),
                          m_swing_left(3), m_swing_right(3),
                          m_sweep_pip_atr(0.2) {}
   
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }
   
   void SetParams(int lookback, int swing_left, int swing_right, double sweep_atr)
   {
      m_lookback_bars = lookback;
      m_swing_left = swing_left;
      m_swing_right = swing_right;
      m_sweep_pip_atr = sweep_atr;
   }
   
   //+---------------------------------------------------------------+
   //| Detect all Cat D patterns                                    |
   //+---------------------------------------------------------------+
   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;
      
      CandleAnatomy c0;
      c0.Capture(m_symbol, m_period, shift);
      
      flags.P51_Higher_High_Higher_Low = DetectHHHL(shift);
      flags.P52_Lower_High_Lower_Low = DetectLHLL(shift);
      flags.P53_Break_Of_Structure_Bull = DetectBOSBull(shift, atr);
      flags.P54_Break_Of_Structure_Bear = DetectBOSBear(shift, atr);
      flags.P55_Change_Of_Character_Bull = DetectCHoCHBull(shift, atr);
      flags.P56_Change_Of_Character_Bear = DetectCHoCHBear(shift, atr);
      flags.P57_Liquidity_Sweep_Long = DetectLiquiditySweepLong(shift, c0, atr);
      flags.P58_Liquidity_Sweep_Short = DetectLiquiditySweepShort(shift, c0, atr);
      flags.P59_Failed_Breakout_Long = DetectFailedBreakoutLong(shift, atr);
      flags.P60_Failed_Breakout_Short = DetectFailedBreakoutShort(shift, atr);
   }
   
private:
   //+---------------------------------------------------------------+
   //| P51 — HIGHER HIGH + HIGHER LOW (Bullish Structure)            |
   //|                                                                |
   //|  Theory (Dow Theory + Brooks): Bullish trend = sequence of   |
   //|  higher highs and higher lows. Both must hold.                |
   //|                                                                |
   //|  Detection: last 2 swing highs ascending + last 2 swing lows |
   //|             ascending                                          |
   //+---------------------------------------------------------------+
   bool DetectHHHL(int shift)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars - sh1 + shift, m_swing_left, m_swing_right);
      if(sh2 < 0) return false;
      
      int sl1 = FindSwingLow(m_symbol, m_period, shift, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars - sl1 + shift, m_swing_left, m_swing_right);
      if(sl2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      // sh1 is more recent (lower index), sh2 is older
      // For HHHL: h1 > h2 (recent > old) AND l1 > l2
      return (h1 > h2) && (l1 > l2);
   }
   
   //+---------------------------------------------------------------+
   //| P52 — LOWER HIGH + LOWER LOW (Bearish Structure)              |
   //+---------------------------------------------------------------+
   bool DetectLHLL(int shift)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars - sh1 + shift, m_swing_left, m_swing_right);
      if(sh2 < 0) return false;
      
      int sl1 = FindSwingLow(m_symbol, m_period, shift, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars - sl1 + shift, m_swing_left, m_swing_right);
      if(sl2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      return (h1 < h2) && (l1 < l2);
   }
   
   //+---------------------------------------------------------------+
   //| P53 — BREAK OF STRUCTURE BULL (BOS)                           |
   //|                                                                |
   //|  Theory (ICT): Price breaks above the most recent swing      |
   //|  high in an uptrend, confirming continuation.                 |
   //|                                                                |
   //|  Detection: Current close > last swing high, where last      |
   //|  swing high was within bullish trend context.                 |
   //+---------------------------------------------------------------+
   bool DetectBOSBull(int shift, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh < 0) return false;
      
      double swing_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      // Current close broke above swing high (with confirmation buffer)
      if(current_close <= swing_high + atr * 0.1) return false;
      
      // Confirm bullish context: prior swing low must be HIGHER than older one
      int sl = FindSwingLow(m_symbol, m_period, sh + 2, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl < 0) return true;  // can't verify, but BOS still valid
      int sl_older = FindSwingLow(m_symbol, m_period, sl + 4, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl_older < 0) return true;
      
      double l_recent = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl);
      double l_older = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl_older);
      
      return l_recent > l_older;  // bullish structure
   }
   
   //+---------------------------------------------------------------+
   //| P54 — BREAK OF STRUCTURE BEAR                                 |
   //+---------------------------------------------------------------+
   bool DetectBOSBear(int shift, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl < 0) return false;
      
      double swing_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl);
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      
      if(current_close >= swing_low - atr * 0.1) return false;
      
      int sh = FindSwingHigh(m_symbol, m_period, sl + 2, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh < 0) return true;
      int sh_older = FindSwingHigh(m_symbol, m_period, sh + 4, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh_older < 0) return true;
      
      double h_recent = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh);
      double h_older = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh_older);
      
      return h_recent < h_older;  // bearish structure
   }
   
   //+---------------------------------------------------------------+
   //| P55 — CHANGE OF CHARACTER BULL (CHoCH)                        |
   //|                                                                |
   //|  Theory (ICT): The FIRST break of structure in the OPPOSITE  |
   //|  direction. Signals trend change.                             |
   //|                                                                |
   //|  CHoCH bullish: was in downtrend (LH+LL), then close breaks  |
   //|  above last LOWER HIGH → first sign of bullish reversal.    |
   //+---------------------------------------------------------------+
   bool DetectCHoCHBull(int shift, double atr)
   {
      // Find recent swing highs
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh2 < 0) return false;
      
      double h1 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh1);
      double h2 = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh2);
      
      // Was downtrend: h1 < h2
      if(h1 >= h2) return false;
      
      // Current close breaks above h1 (the "lower high")
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      if(current_close <= h1 + atr * 0.1) return false;
      
      // But hasn't broken above h2 yet (otherwise full BOS, not CHoCH)
      if(current_close > h2) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P56 — CHANGE OF CHARACTER BEAR                                |
   //+---------------------------------------------------------------+
   bool DetectCHoCHBear(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl2 < 0) return false;
      
      double l1 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl1);
      double l2 = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl2);
      
      if(l1 <= l2) return false;  // was uptrend: l1 > l2
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      if(current_close >= l1 - atr * 0.1) return false;
      
      if(current_close < l2) return false;
      
      return true;
   }
   
   //+---------------------------------------------------------------+
   //| P57 — LIQUIDITY SWEEP LONG                                    |
   //|                                                                |
   //|  Theory (ICT): Price briefly breaks below a key swing low    |
   //|  (where stops are clustered), then quickly reverses up.       |
   //|  "Stop hunt then reversal" — classic institutional move.     |
   //|                                                                |
   //|  Detection:                                                    |
   //|  1. Find recent swing low                                      |
   //|  2. Current bar's LOW must dip below it (at least 0.2×ATR)   |
   //|  3. But CLOSE must be back above the swing low                |
   //|  4. Strong lower wick (rejection)                              |
   //+---------------------------------------------------------------+
   bool DetectLiquiditySweepLong(int shift, const CandleAnatomy &c, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl < 0) return false;
      
      double swing_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl);
      
      // Current low dipped below swing low
      bool dipped = c.low < swing_low - m_sweep_pip_atr * atr;
      if(!dipped) return false;
      
      // But closed back above
      bool reclaimed = c.close > swing_low;
      if(!reclaimed) return false;
      
      // Strong lower wick = rejection
      bool rejection = c.lower_wick > c.body;
      
      return rejection;
   }
   
   //+---------------------------------------------------------------+
   //| P58 — LIQUIDITY SWEEP SHORT                                   |
   //+---------------------------------------------------------------+
   bool DetectLiquiditySweepShort(int shift, const CandleAnatomy &c, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 1, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh < 0) return false;
      
      double swing_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh);
      
      bool spiked = c.high > swing_high + m_sweep_pip_atr * atr;
      if(!spiked) return false;
      
      bool reclaimed = c.close < swing_high;
      if(!reclaimed) return false;
      
      bool rejection = c.upper_wick > c.body;
      
      return rejection;
   }
   
   //+---------------------------------------------------------------+
   //| P59 — FAILED BREAKOUT LONG                                    |
   //|                                                                |
   //|  Theory (Brooks): A "fake" break below support that fails.  |
   //|  Different from sweep: failed breakout closes back above     |
   //|  the level over several bars, signals reversal.              |
   //|                                                                |
   //|  Detection:                                                    |
   //|  - Recent bar (shift+1 to shift+5) closed BELOW swing low    |
   //|  - Current bar closed back ABOVE the swing low                |
   //+---------------------------------------------------------------+
   bool DetectFailedBreakoutLong(int shift, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 6, m_lookback_bars, m_swing_left, m_swing_right);
      if(sl < 0) return false;
      
      double swing_low = iLow(m_symbol, (ENUM_TIMEFRAMES)m_period, sl);
      
      // Find a bar in last 5 that closed below swing low
      bool broke_down = false;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(cl < swing_low - atr * 0.1) { broke_down = true; break; }
      }
      if(!broke_down) return false;
      
      // Current closed back above
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      bool recovered = current_close > swing_low + atr * 0.1;
      
      return recovered;
   }
   
   //+---------------------------------------------------------------+
   //| P60 — FAILED BREAKOUT SHORT                                   |
   //+---------------------------------------------------------------+
   bool DetectFailedBreakoutShort(int shift, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 6, m_lookback_bars, m_swing_left, m_swing_right);
      if(sh < 0) return false;
      
      double swing_high = iHigh(m_symbol, (ENUM_TIMEFRAMES)m_period, sh);
      
      bool broke_up = false;
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double cl = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, i);
         if(cl > swing_high + atr * 0.1) { broke_up = true; break; }
      }
      if(!broke_up) return false;
      
      double current_close = iClose(m_symbol, (ENUM_TIMEFRAMES)m_period, shift);
      bool recovered = current_close < swing_high - atr * 0.1;
      
      return recovered;
   }
};

#endif  // KMP_PATTERNS_D_MQH