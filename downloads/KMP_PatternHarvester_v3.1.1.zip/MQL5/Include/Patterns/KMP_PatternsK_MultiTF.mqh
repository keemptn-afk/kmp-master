//+------------------------------------------------------------------+
//|                                    KMP_PatternsK_MultiTF.mqh    |
//|  CATEGORY K: MULTI-TIMEFRAME CONFLUENCE (P126-P135)             |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] ICT MTF hierarchy — institutional approach: HTF defines    |
//|      bias, LTF triggers entry. Most institutional trading flows |
//|      respect HTF context.                                        |
//|  [2] Classical "trade with the trend" — verified in Bulkowski's |
//|      Encyclopedia (chart patterns in alignment with primary trend|
//|      have +10-15% accuracy boost).                               |
//|                                                                  |
//|  HTF mapping (auto):                                             |
//|    M1→M15, M5/M15→H1, M30/H1→H4, H4→D1, D1→W1                  |
//|  Triple TF stack: D1 + H4 + H1 (regardless of current TF)       |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_K_MQH
#define KMP_PATTERNS_K_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CMultiTFPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

public:
   CMultiTFPatterns() : m_symbol(""), m_period(PERIOD_CURRENT) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      ENUM_TIMEFRAMES htf = GetHTF(m_period);
      int htf_shift = LTFtoHTFShift(m_symbol, m_period, htf, shift);
      if(htf_shift < 0) return;

      string htf_align = GetHTFEMAAlignment(m_symbol, htf, htf_shift);

      flags.P126_HTF_Bias_Long  = DetectHTFBiasLong(shift, snap, htf_align);
      flags.P127_HTF_Bias_Short = DetectHTFBiasShort(shift, snap, htf_align);
      flags.P128_MTF_FVG_Aligned_Long  = DetectMTFFVGLong (shift, snap, htf, htf_shift, atr);
      flags.P129_MTF_FVG_Aligned_Short = DetectMTFFVGShort(shift, snap, htf, htf_shift, atr);
      flags.P130_MTF_OB_Aligned_Long   = DetectMTFOBLong  (shift, snap, htf, htf_shift, atr);
      flags.P131_MTF_OB_Aligned_Short  = DetectMTFOBShort (shift, snap, htf, htf_shift, atr);
      flags.P132_Daily_Bias_Intraday_Long  = DetectDailyBiasLong (shift);
      flags.P133_Daily_Bias_Intraday_Short = DetectDailyBiasShort(shift);
      flags.P134_Triple_TF_Aligned_Long  = DetectTripleTFLong (shift);
      flags.P135_Triple_TF_Aligned_Short = DetectTripleTFShort(shift);
   }

private:
   //+---------------------------------------------------------------+
   //| P126 — HTF Bias Long: HTF EMA-aligned bullish + LTF bull bar  |
   //+---------------------------------------------------------------+
   bool DetectHTFBiasLong(int shift, const IndicatorSnapshot &snap, string htf_align)
   {
      if(htf_align != "ALL_BULL") return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      double h = iHigh (m_symbol, m_period, shift);
      double l = iLow  (m_symbol, m_period, shift);
      if(c <= o) return false;
      double range = h - l;
      if(range <= 0) return false;
      return (c - o) / range >= 0.5;  // body >= 50%
   }

   bool DetectHTFBiasShort(int shift, const IndicatorSnapshot &snap, string htf_align)
   {
      if(htf_align != "ALL_BEAR") return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      double h = iHigh (m_symbol, m_period, shift);
      double l = iLow  (m_symbol, m_period, shift);
      if(c >= o) return false;
      double range = h - l;
      if(range <= 0) return false;
      return (o - c) / range >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P128 — MTF FVG Aligned Long                                   |
   //|  HTF has bullish FVG (gap between bar n-1 high and n+1 low),  |
   //|  current LTF bar's low is INSIDE that gap, and bullish.       |
   //+---------------------------------------------------------------+
   bool FindHTFBullFVG(ENUM_TIMEFRAMES htf, int htf_start, int max_lookback,
                       double &fvg_low, double &fvg_high)
   {
      // Bullish FVG: low[i] > high[i+2]
      for(int i = htf_start; i < htf_start + max_lookback; i++)
      {
         double low_i  = iLow (m_symbol, htf, i);
         double high_i2 = iHigh(m_symbol, htf, i + 2);
         if(low_i > high_i2)
         {
            fvg_low  = high_i2;
            fvg_high = low_i;
            return true;
         }
      }
      return false;
   }
   bool FindHTFBearFVG(ENUM_TIMEFRAMES htf, int htf_start, int max_lookback,
                       double &fvg_low, double &fvg_high)
   {
      for(int i = htf_start; i < htf_start + max_lookback; i++)
      {
         double high_i = iHigh(m_symbol, htf, i);
         double low_i2 = iLow (m_symbol, htf, i + 2);
         if(high_i < low_i2)
         {
            fvg_low  = high_i;
            fvg_high = low_i2;
            return true;
         }
      }
      return false;
   }

   bool DetectMTFFVGLong(int shift, const IndicatorSnapshot &snap,
                          ENUM_TIMEFRAMES htf, int htf_shift, double atr)
   {
      double fvg_low, fvg_high;
      if(!FindHTFBullFVG(htf, htf_shift, 30, fvg_low, fvg_high)) return false;
      double cur_low = iLow(m_symbol, m_period, shift);
      if(cur_low < fvg_low - 0.1 * atr) return false;
      if(cur_low > fvg_high + 0.1 * atr) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectMTFFVGShort(int shift, const IndicatorSnapshot &snap,
                           ENUM_TIMEFRAMES htf, int htf_shift, double atr)
   {
      double fvg_low, fvg_high;
      if(!FindHTFBearFVG(htf, htf_shift, 30, fvg_low, fvg_high)) return false;
      double cur_high = iHigh(m_symbol, m_period, shift);
      if(cur_high > fvg_high + 0.1 * atr) return false;
      if(cur_high < fvg_low - 0.1 * atr) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }

   //+---------------------------------------------------------------+
   //| P130 — MTF Order Block Aligned Long                          |
   //|  HTF has bullish Order Block: last bear candle before bull   |
   //|  impulse leg ≥ 1.5 × ATR. Current LTF entry inside that OB.   |
   //+---------------------------------------------------------------+
   bool FindHTFBullOB(ENUM_TIMEFRAMES htf, int htf_start, int max_lb,
                      double &ob_low, double &ob_high, double atr_htf)
   {
      for(int i = htf_start; i < htf_start + max_lb; i++)
      {
         double o = iOpen (m_symbol, htf, i);
         double c = iClose(m_symbol, htf, i);
         if(c >= o) continue;  // need bearish OB candle
         // Check next bar is bullish impulse
         double o1 = iOpen (m_symbol, htf, i - 1);
         double c1 = iClose(m_symbol, htf, i - 1);
         if(c1 <= o1) continue;
         if(c1 - o1 < 1.5 * atr_htf) continue;
         ob_low  = iLow (m_symbol, htf, i);
         ob_high = iHigh(m_symbol, htf, i);
         return true;
      }
      return false;
   }
   bool FindHTFBearOB(ENUM_TIMEFRAMES htf, int htf_start, int max_lb,
                       double &ob_low, double &ob_high, double atr_htf)
   {
      for(int i = htf_start; i < htf_start + max_lb; i++)
      {
         double o = iOpen (m_symbol, htf, i);
         double c = iClose(m_symbol, htf, i);
         if(c <= o) continue;
         double o1 = iOpen (m_symbol, htf, i - 1);
         double c1 = iClose(m_symbol, htf, i - 1);
         if(c1 >= o1) continue;
         if(o1 - c1 < 1.5 * atr_htf) continue;
         ob_low  = iLow (m_symbol, htf, i);
         ob_high = iHigh(m_symbol, htf, i);
         return true;
      }
      return false;
   }

   bool DetectMTFOBLong(int shift, const IndicatorSnapshot &snap,
                        ENUM_TIMEFRAMES htf, int htf_shift, double atr)
   {
      double ob_low, ob_high;
      // Approximate HTF ATR using current ATR scaled by tf ratio (rough)
      double atr_htf = atr * 4.0;  // assume HTF ≈ 4x current
      if(!FindHTFBullOB(htf, htf_shift, 25, ob_low, ob_high, atr_htf)) return false;
      double cur_low = iLow(m_symbol, m_period, shift);
      if(cur_low < ob_low - 0.1 * atr) return false;
      if(cur_low > ob_high + 0.1 * atr) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectMTFOBShort(int shift, const IndicatorSnapshot &snap,
                          ENUM_TIMEFRAMES htf, int htf_shift, double atr)
   {
      double ob_low, ob_high;
      double atr_htf = atr * 4.0;
      if(!FindHTFBearOB(htf, htf_shift, 25, ob_low, ob_high, atr_htf)) return false;
      double cur_high = iHigh(m_symbol, m_period, shift);
      if(cur_high > ob_high + 0.1 * atr) return false;
      if(cur_high < ob_low - 0.1 * atr) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }

   //+---------------------------------------------------------------+
   //| P132 — Daily Bias + Intraday Long                             |
   //|  D1 yesterday close > D1 yesterday open AND current bar bull. |
   //|  Larry Williams "Long-term Secrets to Short-term Trading"    |
   //+---------------------------------------------------------------+
   bool DetectDailyBiasLong(int shift)
   {
      double d_open  = iOpen (m_symbol, PERIOD_D1, 1);  // yesterday
      double d_close = iClose(m_symbol, PERIOD_D1, 1);
      if(d_close <= d_open) return false;
      // intraday confirm
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      double h = iHigh (m_symbol, m_period, shift);
      double l = iLow  (m_symbol, m_period, shift);
      if(c <= o) return false;
      double range = h - l;
      if(range <= 0) return false;
      // close in upper half
      return ((c - l) / range) >= 0.5;
   }

   bool DetectDailyBiasShort(int shift)
   {
      double d_open  = iOpen (m_symbol, PERIOD_D1, 1);
      double d_close = iClose(m_symbol, PERIOD_D1, 1);
      if(d_close >= d_open) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      double h = iHigh (m_symbol, m_period, shift);
      double l = iLow  (m_symbol, m_period, shift);
      if(c >= o) return false;
      double range = h - l;
      if(range <= 0) return false;
      return ((h - c) / range) >= 0.5;
   }

   //+---------------------------------------------------------------+
   //| P134 — Triple TF Aligned Long                                  |
   //|  D1 + H4 + H1 ทุก TF EMA-stack = bullish (close higher        |
   //|  than 10/30/50 bars ago — proxy for EMA alignment).           |
   //+---------------------------------------------------------------+
   bool TFIsBullish(ENUM_TIMEFRAMES tf)
   {
      double c0  = iClose(m_symbol, tf, 0);
      double c10 = iClose(m_symbol, tf, 10);
      double c30 = iClose(m_symbol, tf, 30);
      double c50 = iClose(m_symbol, tf, 50);
      return (c0 > c10) && (c10 > c30) && (c30 > c50);
   }
   bool TFIsBearish(ENUM_TIMEFRAMES tf)
   {
      double c0  = iClose(m_symbol, tf, 0);
      double c10 = iClose(m_symbol, tf, 10);
      double c30 = iClose(m_symbol, tf, 30);
      double c50 = iClose(m_symbol, tf, 50);
      return (c0 < c10) && (c10 < c30) && (c30 < c50);
   }

   bool DetectTripleTFLong(int shift)
   {
      if(!TFIsBullish(PERIOD_D1)) return false;
      if(!TFIsBullish(PERIOD_H4)) return false;
      if(!TFIsBullish(PERIOD_H1)) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectTripleTFShort(int shift)
   {
      if(!TFIsBearish(PERIOD_D1)) return false;
      if(!TFIsBearish(PERIOD_H4)) return false;
      if(!TFIsBearish(PERIOD_H1)) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }
};

#endif  // KMP_PATTERNS_K_MQH