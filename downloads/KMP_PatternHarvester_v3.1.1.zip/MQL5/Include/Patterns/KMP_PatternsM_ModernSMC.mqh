//+------------------------------------------------------------------+
//|                                  KMP_PatternsM_ModernSMC.mqh   |
//|  CATEGORY M: MODERN SMC (P143-P150)                              |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] ICT advanced curriculum — Inducement (IFC), Internal vs    |
//|      External liquidity hierarchy.                               |
//|  [2] Larry Williams "Long-term Secrets to Short-term Trading"   |
//|      (1999) — Turtle Soup (20-day breakout failure pattern).    |
//|  [3] Order flow theory — aggressor flip + stop run reversal.    |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_M_MQH
#define KMP_PATTERNS_M_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CModernSMCPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_swing_lookback;
   int    m_external_lookback;
   int    m_donchian_period;
   double m_volume_climax;

public:
   CModernSMCPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                          m_swing_lookback(20),
                          m_external_lookback(50),
                          m_donchian_period(20),
                          m_volume_climax(2.0) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int swing_lb = 20, int external_lb = 50,
                  int donchian = 20, double vol_climax = 2.0)
   {
      m_swing_lookback    = swing_lb;
      m_external_lookback = external_lb;
      m_donchian_period   = donchian;
      m_volume_climax     = vol_climax;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P143_Inducement_Bull        = DetectInducementBull(shift, atr);
      flags.P144_Inducement_Bear        = DetectInducementBear(shift, atr);
      flags.P145_Turtle_Soup_Long       = DetectTurtleSoupLong(shift, atr);
      flags.P146_Turtle_Soup_Short      = DetectTurtleSoupShort(shift, atr);
      flags.P147_Stop_Run_Reversal_Bull = DetectStopRunBull(shift, snap, atr);
      flags.P148_Stop_Run_Reversal_Bear = DetectStopRunBear(shift, snap, atr);
      flags.P149_Internal_Liq_Sweep_Long = DetectInternalLiqLong(shift, atr);
      flags.P150_External_Liq_Sweep_Long = DetectExternalLiqLong(shift, atr);
   }

private:
   //+---------------------------------------------------------------+
   //| P143 — Inducement Bull (IFC)                                  |
   //|  Pre-existing minor swing low gets briefly broken (fake low) |
   //|  in same bar or recent bars, then immediate strong rejection. |
   //|  Different from Liq Grab: focuses on FRESH same-bar reversal. |
   //+---------------------------------------------------------------+
   bool DetectInducementBull(int shift, double atr)
   {
      // Find minor swing low within last 20 bars (excluding very recent)
      int sl = FindSwingLow(m_symbol, m_period, shift + 5, m_swing_lookback, 2, 2);
      if(sl < 0) return false;
      double sl_price = iLow(m_symbol, m_period, sl);

      // Current bar's low must dip below it (fake breakdown) but close back above
      double cur_low   = iLow  (m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);

      if(cur_low > sl_price - 0.1 * atr) return false;     // didn't breach
      if(cur_close <= sl_price) return false;              // didn't reclaim
      if(cur_close <= cur_open) return false;              // not bullish

      // Wick must be substantial (rejection signature)
      double range = iHigh(m_symbol, m_period, shift) - cur_low;
      double lower_wick = cur_close > cur_open ? cur_open - cur_low : cur_close - cur_low;
      if(range > 0 && lower_wick / range < 0.3) return false;
      return true;
   }

   bool DetectInducementBear(int shift, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 5, m_swing_lookback, 2, 2);
      if(sh < 0) return false;
      double sh_price = iHigh(m_symbol, m_period, sh);

      double cur_high  = iHigh (m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);

      if(cur_high < sh_price + 0.1 * atr) return false;
      if(cur_close >= sh_price) return false;
      if(cur_close >= cur_open) return false;

      double range = cur_high - iLow(m_symbol, m_period, shift);
      double upper_wick = cur_close < cur_open ? cur_high - cur_open : cur_high - cur_close;
      if(range > 0 && upper_wick / range < 0.3) return false;
      return true;
   }

   //+---------------------------------------------------------------+
   //| P145 — Turtle Soup Long (Larry Williams)                      |
   //|  20-day Donchian high broken in last 1-2 bars but close back  |
   //|  BELOW it on current bar + bullish reaction (long entry).     |
   //|  Wait — for LONG, classic Turtle Soup is FAILED LOW BREAK.    |
   //|  20-day low broken (fake breakdown), then close back above.   |
   //+---------------------------------------------------------------+
   bool DetectTurtleSoupLong(int shift, double atr)
   {
      // Compute 20-day Donchian low BEFORE recent break
      double donch_low = iLow(m_symbol, m_period, shift + 3);
      for(int i = shift + 4; i <= shift + 3 + m_donchian_period; i++)
      {
         double l = iLow(m_symbol, m_period, i);
         if(l < donch_low) donch_low = l;
      }
      // Need: in last 1-2 bars, low broke below donch_low
      bool broke = false;
      for(int j = shift + 1; j <= shift + 2; j++)
      {
         if(iLow(m_symbol, m_period, j) < donch_low - 0.1 * atr) { broke = true; break; }
      }
      if(!broke) return false;
      // Current bar closes back ABOVE the Donchian low + bullish
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close <= donch_low) return false;
      return (cur_close > cur_open);
   }

   bool DetectTurtleSoupShort(int shift, double atr)
   {
      double donch_high = iHigh(m_symbol, m_period, shift + 3);
      for(int i = shift + 4; i <= shift + 3 + m_donchian_period; i++)
      {
         double h = iHigh(m_symbol, m_period, i);
         if(h > donch_high) donch_high = h;
      }
      bool broke = false;
      for(int j = shift + 1; j <= shift + 2; j++)
      {
         if(iHigh(m_symbol, m_period, j) > donch_high + 0.1 * atr) { broke = true; break; }
      }
      if(!broke) return false;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);
      if(cur_close >= donch_high) return false;
      return (cur_close < cur_open);
   }

   //+---------------------------------------------------------------+
   //| P147 — Stop Run Reversal Bull                                 |
   //|  Different from Liq Grab: needs HIGH VOLUME on the same bar  |
   //|  + close in upper third → aggressor flip signature.           |
   //+---------------------------------------------------------------+
   bool DetectStopRunBull(int shift, const IndicatorSnapshot &snap, double atr)
   {
      // Recent S/R level approximated as last swing low
      int sl = FindSwingLow(m_symbol, m_period, shift + 1, m_swing_lookback, 2, 2);
      if(sl < 0) return false;
      double sl_price = iLow(m_symbol, m_period, sl);

      double cur_low   = iLow  (m_symbol, m_period, shift);
      double cur_high  = iHigh (m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);

      // Must sweep
      if(cur_low >= sl_price - 0.3 * atr) return false;
      // Must have high volume
      if(snap.volume_ratio < m_volume_climax) return false;
      // Close in upper third
      double range = cur_high - cur_low;
      if(range <= 0) return false;
      double pos = (cur_close - cur_low) / range;
      return pos >= 0.66;
   }

   bool DetectStopRunBear(int shift, const IndicatorSnapshot &snap, double atr)
   {
      int sh = FindSwingHigh(m_symbol, m_period, shift + 1, m_swing_lookback, 2, 2);
      if(sh < 0) return false;
      double sh_price = iHigh(m_symbol, m_period, sh);

      double cur_high  = iHigh (m_symbol, m_period, shift);
      double cur_low   = iLow  (m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);

      if(cur_high <= sh_price + 0.3 * atr) return false;
      if(snap.volume_ratio < m_volume_climax) return false;
      double range = cur_high - cur_low;
      if(range <= 0) return false;
      double pos = (cur_close - cur_low) / range;
      return pos <= 0.34;
   }

   //+---------------------------------------------------------------+
   //| P149 — Internal Liquidity Sweep Long                          |
   //|  Sweep of MINOR swing low within last 20 bars (internal)     |
   //+---------------------------------------------------------------+
   bool DetectInternalLiqLong(int shift, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 1, m_swing_lookback, 2, 2);
      if(sl < 0) return false;
      // Must be within 20 bars (internal range)
      if(sl > shift + 20) return false;
      double sl_price = iLow(m_symbol, m_period, sl);

      double cur_low   = iLow  (m_symbol, m_period, shift);
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);

      if(cur_low >= sl_price - 0.1 * atr) return false;
      if(cur_close <= sl_price) return false;
      return (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P150 — External Liquidity Sweep Long                          |
   //|  Sweep of MAJOR swing low (50+ bars back) — stronger signal  |
   //+---------------------------------------------------------------+
   bool DetectExternalLiqLong(int shift, double atr)
   {
      int sl = FindSwingLow(m_symbol, m_period, shift + 50, m_external_lookback, 3, 3);
      if(sl < 0) return false;
      double sl_price = iLow(m_symbol, m_period, sl);

      // Find lowest in last 5 bars
      double recent_low = iLow(m_symbol, m_period, shift);
      for(int i = shift + 1; i <= shift + 5; i++)
      {
         double l = iLow(m_symbol, m_period, i);
         if(l < recent_low) recent_low = l;
      }

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen (m_symbol, m_period, shift);

      // Sweep occurred recently
      if(recent_low >= sl_price - 0.2 * atr) return false;
      // Now reclaiming
      if(cur_close <= sl_price) return false;
      return (cur_close > cur_open);
   }
};

#endif  // KMP_PATTERNS_M_MQH