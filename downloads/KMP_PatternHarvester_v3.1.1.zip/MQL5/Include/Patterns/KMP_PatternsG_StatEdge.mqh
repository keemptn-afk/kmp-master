//+------------------------------------------------------------------+
//|                                    KMP_PatternsG_StatEdge.mqh   |
//|                                                                  |
//|  CATEGORY G: STATISTICAL EDGE PATTERNS (P81-P88)                |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Tony Crabel — "Day Trading with Short Term Price Patterns"  |
//|      (1990) — origin of NR4/NR7 narrow-range setups.             |
//|  [2] Concretum Group — "Beat the Market Maker" (2023) ORB study  |
//|      published evidence that ORB strategies retain edge.         |
//|  [3] John Bollinger — "Bollinger on Bollinger Bands" (2001) for  |
//|      %B formulation and mean-reversion at band extremes.         |
//|  [4] QuantConnect / AQR research on Z-score mean reversion in    |
//|      sub-daily timeframes.                                       |
//|                                                                  |
//|  These patterns are quantitative & statistically motivated; less |
//|  about chart shape, more about price extremes vs distribution.   |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_G_MQH
#define KMP_PATTERNS_G_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CStatEdgePatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;

   // Z-Score parameters
   int    m_zscore_lookback;       // bars used to compute mean & std (default 20)
   double m_zscore_threshold;      // |Z| >= threshold to fire (default 2.0)

   // ORB parameters
   int    m_orb_range_bars;        // bars defining "opening range" (default 4)
   double m_orb_break_atr;         // break magnitude in ATR (default 0.1)

   // NR parameters — handled inline (4 and 7 bar windows)

public:
   CStatEdgePatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                         m_zscore_lookback(20),
                         m_zscore_threshold(2.0),
                         m_orb_range_bars(4),
                         m_orb_break_atr(0.1) {}

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;
   }

   void SetParams(int zscore_lookback = 20, double zscore_threshold = 2.0,
                  int orb_range_bars = 4, double orb_break_atr = 0.1)
   {
      m_zscore_lookback = zscore_lookback;
      m_zscore_threshold = zscore_threshold;
      m_orb_range_bars = orb_range_bars;
      m_orb_break_atr = orb_break_atr;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P81_ZScore_MeanRev_Long  = DetectZScoreMRLong(shift);
      flags.P82_ZScore_MeanRev_Short = DetectZScoreMRShort(shift);
      flags.P83_ORB_Long             = DetectORBLong(shift, atr, snap.hour_of_day);
      flags.P84_ORB_Short            = DetectORBShort(shift, atr, snap.hour_of_day);
      flags.P85_NR4                  = DetectNR4(shift);
      flags.P86_NR7                  = DetectNR7(shift);
      flags.P87_BB_PctB_Extreme_Long = DetectBBPctBLong(shift, snap);
      flags.P88_BB_PctB_Extreme_Short= DetectBBPctBShort(shift, snap);
   }

private:
   //+---------------------------------------------------------------+
   //| P81 — Z-SCORE MEAN REVERSION LONG                             |
   //|                                                                |
   //|  Theory: When price closes >= Z standard deviations below the |
   //|  rolling mean of closes, statistical mean reversion is        |
   //|  expected (regression to the mean). Common in sub-daily TFs   |
   //|  for ranging instruments.                                      |
   //|                                                                |
   //|  Detection:                                                    |
   //|   1. Compute mean and stdev of last m_zscore_lookback closes   |
   //|      (excluding current bar).                                  |
   //|   2. Z = (close[shift] - mean) / std                           |
   //|   3. Long if Z <= -threshold (default -2)                      |
   //|   4. Confirm current bar is bullish (closed above its open)   |
   //+---------------------------------------------------------------+
   bool DetectZScoreMRLong(int shift)
   {
      double sum = 0, sum_sq = 0;
      int n = m_zscore_lookback;
      for(int i = shift + 1; i <= shift + n; i++)
      {
         double c = iClose(m_symbol, m_period, i);
         sum += c;
         sum_sq += c * c;
      }
      if(n <= 1) return false;

      double mean = sum / n;
      double variance = (sum_sq / n) - (mean * mean);
      if(variance <= 0) return false;
      double std = MathSqrt(variance);
      if(std <= 0) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double z = (cur_close - mean) / std;

      // Mean-revert long: close is below mean by threshold AND bar bullish
      return (z <= -m_zscore_threshold) && (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P82 — Z-SCORE MEAN REVERSION SHORT                            |
   //+---------------------------------------------------------------+
   bool DetectZScoreMRShort(int shift)
   {
      double sum = 0, sum_sq = 0;
      int n = m_zscore_lookback;
      for(int i = shift + 1; i <= shift + n; i++)
      {
         double c = iClose(m_symbol, m_period, i);
         sum += c;
         sum_sq += c * c;
      }
      if(n <= 1) return false;

      double mean = sum / n;
      double variance = (sum_sq / n) - (mean * mean);
      if(variance <= 0) return false;
      double std = MathSqrt(variance);
      if(std <= 0) return false;

      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      double z = (cur_close - mean) / std;

      return (z >= m_zscore_threshold) && (cur_close < cur_open);
   }

   //+---------------------------------------------------------------+
   //| P83 — OPENING RANGE BREAKOUT LONG (ORB)                       |
   //|                                                                |
   //|  Theory (Crabel/Concretum): Define the "opening range" as     |
   //|  the high-low of the first N bars of the trading session.    |
   //|  A close above the OR high signals breakout long; momentum    |
   //|  edge is statistically positive in equity-index intraday data.|
   //|                                                                |
   //|  Implementation note: timeframe-agnostic version. We use the |
   //|  hour-of-day from the snapshot to identify session start.    |
   //|  For 24/7 instruments (BTC, XAU, EUR via MT5), session start  |
   //|  is approximated as 00:00 broker time. The "opening range"   |
   //|  is the high-low of the first m_orb_range_bars at that day's |
   //|  start. We identify the OR by walking back to most recent    |
   //|  midnight bar and taking the next m_orb_range_bars.          |
   //|  Fires if current bar closes above OR_high + break_atr*ATR.  |
   //+---------------------------------------------------------------+
   bool DetectORBLong(int shift, double atr, int /*hour_unused*/)
   {
      // Find the bar at or after midnight (hour=0) within last 200 bars
      int or_start = -1;
      MqlDateTime dt;
      for(int i = shift + 1; i < shift + 200; i++)
      {
         datetime t = iTime(m_symbol, m_period, i);
         if(t == 0) break;
         TimeToStruct(t, dt);
         if(dt.hour == 0)
         {
            // walk forward to the FIRST bar of that day (lowest i with same date)
            int j = i;
            while(j > shift + 1)
            {
               datetime tn = iTime(m_symbol, m_period, j - 1);
               MqlDateTime dn;
               TimeToStruct(tn, dn);
               if(dn.day == dt.day && dn.mon == dt.mon && dn.year == dt.year && dn.hour == 0)
                  j--;
               else
                  break;
            }
            or_start = j;
            break;
         }
      }
      if(or_start < 0) return false;
      if(or_start - m_orb_range_bars < shift) return false;  // not enough bars after OR yet

      // OR high = max high of [or_start .. or_start - m_orb_range_bars + 1]
      double or_high = iHigh(m_symbol, m_period, or_start);
      for(int k = 1; k < m_orb_range_bars; k++)
      {
         double h = iHigh(m_symbol, m_period, or_start - k);
         if(h > or_high) or_high = h;
      }

      // Breakout long: current close above OR high by break_atr * ATR
      double cur_close = iClose(m_symbol, m_period, shift);
      if(cur_close <= or_high + m_orb_break_atr * atr) return false;

      // Avoid firing every subsequent bar — require previous bar's close
      // was at or below or_high (this is the breakout bar)
      double prev_close = iClose(m_symbol, m_period, shift + 1);
      return (prev_close <= or_high + m_orb_break_atr * atr * 0.5);
   }

   //+---------------------------------------------------------------+
   //| P84 — OPENING RANGE BREAKOUT SHORT                            |
   //+---------------------------------------------------------------+
   bool DetectORBShort(int shift, double atr, int /*hour_unused*/)
   {
      int or_start = -1;
      MqlDateTime dt;
      for(int i = shift + 1; i < shift + 200; i++)
      {
         datetime t = iTime(m_symbol, m_period, i);
         if(t == 0) break;
         TimeToStruct(t, dt);
         if(dt.hour == 0)
         {
            int j = i;
            while(j > shift + 1)
            {
               datetime tn = iTime(m_symbol, m_period, j - 1);
               MqlDateTime dn;
               TimeToStruct(tn, dn);
               if(dn.day == dt.day && dn.mon == dt.mon && dn.year == dt.year && dn.hour == 0)
                  j--;
               else
                  break;
            }
            or_start = j;
            break;
         }
      }
      if(or_start < 0) return false;
      if(or_start - m_orb_range_bars < shift) return false;

      double or_low = iLow(m_symbol, m_period, or_start);
      for(int k = 1; k < m_orb_range_bars; k++)
      {
         double l = iLow(m_symbol, m_period, or_start - k);
         if(l < or_low) or_low = l;
      }

      double cur_close = iClose(m_symbol, m_period, shift);
      if(cur_close >= or_low - m_orb_break_atr * atr) return false;

      double prev_close = iClose(m_symbol, m_period, shift + 1);
      return (prev_close >= or_low - m_orb_break_atr * atr * 0.5);
   }

   //+---------------------------------------------------------------+
   //| P85 — NARROW RANGE 4 (NR4)                                    |
   //|                                                                |
   //|  Theory (Crabel): Today's range is the smallest of the last  |
   //|  4 days/bars. Volatility contraction → expansion likely.      |
   //|  Direction-agnostic — fire on either side of subsequent bar.  |
   //|                                                                |
   //|  Detection: range[shift] < range[i] for i in shift+1..shift+3 |
   //+---------------------------------------------------------------+
   bool DetectNR4(int shift)
   {
      double r0 = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(r0 <= 0) return false;
      for(int i = shift + 1; i <= shift + 3; i++)
      {
         double ri = iHigh(m_symbol, m_period, i) - iLow(m_symbol, m_period, i);
         if(ri <= r0) return false;
      }
      return true;
   }

   //+---------------------------------------------------------------+
   //| P86 — NARROW RANGE 7 (NR7) — stronger NR signal               |
   //+---------------------------------------------------------------+
   bool DetectNR7(int shift)
   {
      double r0 = iHigh(m_symbol, m_period, shift) - iLow(m_symbol, m_period, shift);
      if(r0 <= 0) return false;
      for(int i = shift + 1; i <= shift + 6; i++)
      {
         double ri = iHigh(m_symbol, m_period, i) - iLow(m_symbol, m_period, i);
         if(ri <= r0) return false;
      }
      return true;
   }

   //+---------------------------------------------------------------+
   //| P87 — BB %B EXTREME LONG (mean-reversion at lower band)       |
   //|                                                                |
   //|  Theory (Bollinger): %B = (close - lower) / (upper - lower).  |
   //|  When %B <= 0 the close is at or below the lower band — an    |
   //|  extreme; reversal back into bands is statistically common.   |
   //|                                                                |
   //|  Detection: %B[shift] <= 5 (i.e. very near or below lower)    |
   //|  AND current bar bullish.                                     |
   //|                                                                |
   //|  Note: snap.bb_position_pct is computed at shift; we also     |
   //|  cross-check with a small bullish confirmation.               |
   //+---------------------------------------------------------------+
   bool DetectBBPctBLong(int shift, const IndicatorSnapshot &snap)
   {
      if(snap.bb_width <= 0) return false;
      double pctb = snap.bb_position_pct;  // already %B-like (0-100 within band)
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (pctb <= 5.0) && (cur_close > cur_open);
   }

   //+---------------------------------------------------------------+
   //| P88 — BB %B EXTREME SHORT                                     |
   //+---------------------------------------------------------------+
   bool DetectBBPctBShort(int shift, const IndicatorSnapshot &snap)
   {
      if(snap.bb_width <= 0) return false;
      double pctb = snap.bb_position_pct;
      double cur_close = iClose(m_symbol, m_period, shift);
      double cur_open  = iOpen(m_symbol, m_period, shift);
      return (pctb >= 95.0) && (cur_close < cur_open);
   }
};

#endif  // KMP_PATTERNS_G_MQH