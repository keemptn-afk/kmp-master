//+------------------------------------------------------------------+
//|                                  KMP_PatternsN_Momentum.mqh    |
//|  CATEGORY N: MOMENTUM + HIDDEN DIVERGENCE (P151-P160)            |
//|                                                                  |
//|  Theory References:                                              |
//|  [1] Al Brooks — "Trading Price Action Trends" (2012). Pullback |
//|      to MA in established trend = high-probability continuation. |
//|  [2] Constance Brown — "Technical Analysis for the Trading      |
//|      Professional" (1999). Hidden divergence = continuation     |
//|      signal (opposite of regular div which is reversal).         |
//|  [3] Bulkowski Encyclopedia — trendline 3rd-touch validated.    |
//|                                                                  |
//|  Hidden Div explained:                                           |
//|    BULLISH HIDDEN DIV: price = HIGHER low, RSI = LOWER low      |
//|      → in uptrend, buyers still strong, momentum hidden          |
//|    BEARISH HIDDEN DIV: price = LOWER high, RSI = HIGHER high    |
//|      → in downtrend, sellers still strong                        |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"
#ifndef KMP_PATTERNS_N_MQH
#define KMP_PATTERNS_N_MQH

#include "../KMP_Structures.mqh"
#include "KMP_CandleHelpers.mqh"

class CMomentumPatterns
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   int    m_swing_lookback;
   int    m_div_lookback;

   // We need previous bars' RSI values for divergence — read via handle
   int    h_rsi14;
   int    h_macd;

public:
   CMomentumPatterns() : m_symbol(""), m_period(PERIOD_CURRENT),
                         m_swing_lookback(50),
                         m_div_lookback(30),
                         h_rsi14(INVALID_HANDLE),
                         h_macd(INVALID_HANDLE) {}

   ~CMomentumPatterns() { Deinit(); }

   void Deinit()
   {
      if(h_rsi14 != INVALID_HANDLE) { IndicatorRelease(h_rsi14); h_rsi14 = INVALID_HANDLE; }
      if(h_macd  != INVALID_HANDLE) { IndicatorRelease(h_macd);  h_macd  = INVALID_HANDLE; }
   }

   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      // Release any prior handles (in case Init called twice)
      Deinit();
      m_symbol = symbol;
      m_period = period;
      h_rsi14 = iRSI(symbol, period, 14, PRICE_CLOSE);
      h_macd  = iMACD(symbol, period, 12, 26, 9, PRICE_CLOSE);
   }

   void SetParams(int swing_lb = 50, int div_lb = 30)
   {
      m_swing_lookback = swing_lb;
      m_div_lookback   = div_lb;
   }

   void DetectAll(int shift, PatternFlags &flags, const IndicatorSnapshot &snap)
   {
      double atr = snap.atr_14;
      if(atr <= 0) return;

      flags.P151_Pullback_EMA20_Long  = DetectPullbackEMALong (shift, snap, snap.ema_20, atr);
      flags.P152_Pullback_EMA20_Short = DetectPullbackEMAShort(shift, snap, snap.ema_20, atr);
      flags.P153_Pullback_EMA50_Long  = DetectPullbackEMALong (shift, snap, snap.ema_50, atr);
      flags.P154_Pullback_EMA50_Short = DetectPullbackEMAShort(shift, snap, snap.ema_50, atr);
      flags.P155_Three_Touch_Trendline_Long  = DetectTrendline3Long (shift, atr);
      flags.P156_Three_Touch_Trendline_Short = DetectTrendline3Short(shift, atr);
      flags.P157_Hidden_Div_Bull_RSI  = DetectHiddenDivBullRSI(shift, atr);
      flags.P158_Hidden_Div_Bear_RSI  = DetectHiddenDivBearRSI(shift, atr);
      flags.P159_Hidden_Div_Bull_MACD = DetectHiddenDivBullMACD(shift, atr);
      flags.P160_Hidden_Div_Bear_MACD = DetectHiddenDivBearMACD(shift, atr);
   }

private:
   double GetRSI(int shift)
   {
      if(h_rsi14 == INVALID_HANDLE) return 0;
      double v[];
      ArraySetAsSeries(v, true);
      if(CopyBuffer(h_rsi14, 0, shift, 1, v) <= 0) return 0;
      return v[0];
   }
   double GetMACDHist(int shift)
   {
      if(h_macd == INVALID_HANDLE) return 0;
      double main[], sig[];
      ArraySetAsSeries(main, true);
      ArraySetAsSeries(sig, true);
      if(CopyBuffer(h_macd, 0, shift, 1, main) <= 0) return 0;
      if(CopyBuffer(h_macd, 1, shift, 1, sig)  <= 0) return 0;
      return main[0] - sig[0];
   }

   //+---------------------------------------------------------------+
   //| P151/P153 — Pullback to EMA Long                              |
   //|  trend_regime=STRONG_UP + low touches EMA + bullish bar       |
   //+---------------------------------------------------------------+
   bool DetectPullbackEMALong(int shift, const IndicatorSnapshot &snap,
                               double ema_value, double atr)
   {
      if(ema_value <= 0) return false;
      // Trend filter: STRONG_UP or WEAK_UP
      if(snap.trend_regime != "STRONG_UP" && snap.trend_regime != "WEAK_UP") return false;
      // Low must be near EMA
      double cur_low = iLow(m_symbol, m_period, shift);
      if(cur_low > ema_value + 0.1 * atr) return false;  // didn't reach EMA
      if(cur_low < ema_value - 0.5 * atr) return false;  // overshot too much
      // Bullish bar
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o) && (c > ema_value);  // close back above EMA
   }

   bool DetectPullbackEMAShort(int shift, const IndicatorSnapshot &snap,
                                double ema_value, double atr)
   {
      if(ema_value <= 0) return false;
      if(snap.trend_regime != "STRONG_DOWN" && snap.trend_regime != "WEAK_DOWN") return false;
      double cur_high = iHigh(m_symbol, m_period, shift);
      if(cur_high < ema_value - 0.1 * atr) return false;
      if(cur_high > ema_value + 0.5 * atr) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o) && (c < ema_value);
   }

   //+---------------------------------------------------------------+
   //| P155 — 3-Touch Trendline Long                                 |
   //|  Find 2 swing lows; project trendline; current bar = 3rd touch|
   //+---------------------------------------------------------------+
   bool DetectTrendline3Long(int shift, double atr)
   {
      // Find 2 most recent swing lows
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 3, m_swing_lookback, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_swing_lookback, 3, 3);
      if(sl2 < 0) return false;
      double l1 = iLow(m_symbol, m_period, sl1);
      double l2 = iLow(m_symbol, m_period, sl2);
      // Need: l1 > l2 (uptrend trendline ascending)
      if(l1 <= l2) return false;
      // Slope = (l1 - l2) / (sl2 - sl1) bars per unit price
      double slope = (l1 - l2) / (double)(sl2 - sl1);
      // Project to current bar
      double projected = l1 + slope * (sl1 - shift);
      // Current bar low must be near the line
      double cur_low = iLow(m_symbol, m_period, shift);
      if(MathAbs(cur_low - projected) > 0.3 * atr) return false;
      // Bullish reaction
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectTrendline3Short(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 3, m_swing_lookback, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_swing_lookback, 3, 3);
      if(sh2 < 0) return false;
      double h1 = iHigh(m_symbol, m_period, sh1);
      double h2 = iHigh(m_symbol, m_period, sh2);
      if(h1 >= h2) return false;
      double slope = (h2 - h1) / (double)(sh2 - sh1);
      double projected = h1 - slope * (sh1 - shift);
      double cur_high = iHigh(m_symbol, m_period, shift);
      if(MathAbs(cur_high - projected) > 0.3 * atr) return false;
      double o = iOpen(m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }

   //+---------------------------------------------------------------+
   //| P157 — Hidden Bull Div RSI                                    |
   //|  In uptrend: price HL + RSI LL → continuation                 |
   //+---------------------------------------------------------------+
   bool DetectHiddenDivBullRSI(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_div_lookback, 3, 3);
      if(sl2 < 0) return false;
      double p1 = iLow(m_symbol, m_period, sl1);  // newer
      double p2 = iLow(m_symbol, m_period, sl2);  // older
      if(p1 <= p2) return false;  // need higher low (newer > older)
      double r1 = GetRSI(sl1);
      double r2 = GetRSI(sl2);
      if(r1 >= r2) return false;  // need lower low in RSI
      // Confirm with bullish current bar
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectHiddenDivBearRSI(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_div_lookback, 3, 3);
      if(sh2 < 0) return false;
      double p1 = iHigh(m_symbol, m_period, sh1);
      double p2 = iHigh(m_symbol, m_period, sh2);
      if(p1 >= p2) return false;  // need lower high
      double r1 = GetRSI(sh1);
      double r2 = GetRSI(sh2);
      if(r1 <= r2) return false;  // need higher high in RSI
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }

   bool DetectHiddenDivBullMACD(int shift, double atr)
   {
      int sl1 = FindSwingLow(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sl1 < 0) return false;
      int sl2 = FindSwingLow(m_symbol, m_period, sl1 + 4, m_div_lookback, 3, 3);
      if(sl2 < 0) return false;
      double p1 = iLow(m_symbol, m_period, sl1);
      double p2 = iLow(m_symbol, m_period, sl2);
      if(p1 <= p2) return false;
      double m1 = GetMACDHist(sl1);
      double m2 = GetMACDHist(sl2);
      if(m1 >= m2) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c > o);
   }

   bool DetectHiddenDivBearMACD(int shift, double atr)
   {
      int sh1 = FindSwingHigh(m_symbol, m_period, shift + 1, m_div_lookback, 3, 3);
      if(sh1 < 0) return false;
      int sh2 = FindSwingHigh(m_symbol, m_period, sh1 + 4, m_div_lookback, 3, 3);
      if(sh2 < 0) return false;
      double p1 = iHigh(m_symbol, m_period, sh1);
      double p2 = iHigh(m_symbol, m_period, sh2);
      if(p1 >= p2) return false;
      double m1 = GetMACDHist(sh1);
      double m2 = GetMACDHist(sh2);
      if(m1 <= m2) return false;
      double o = iOpen (m_symbol, m_period, shift);
      double c = iClose(m_symbol, m_period, shift);
      return (c < o);
   }
};

#endif  // KMP_PATTERNS_N_MQH