//+------------------------------------------------------------------+
//|                                                KMP_Patterns.mqh |
//|                                                                  |
//|  MASTER PATTERN AGGREGATOR                                       |
//|  Combines all 10 pattern category detectors into single class.  |
//|                                                                  |
//|  PHASE 1 (P1-P80)                                                |
//|    A: Original Strategy   (P1-P20)  — existing patterns         |
//|    B: Candlestick         (P21-P40) — Nison/Bulkowski           |
//|    C: Support/Resistance  (P41-P50) — Seiden/ICT/Wyckoff        |
//|    D: Structure           (P51-P60) — Brooks/ICT                |
//|    E: Chart Patterns      (P61-P70) — Edwards & Magee/Bulkowski|
//|    F: Smart Money         (P71-P80) — ICT/Volume Profile       |
//|                                                                  |
//|  PHASE 2 (P81-P125)                                              |
//|    G: Stat-Edge           (P81-P88)  — Crabel/Concretum/BB %B   |
//|    H: SMC Advanced        (P89-P97)  — ICT OTE/KZ/PO3/PD Array  |
//|    I: Volume / Wyckoff    (P98-P107) — Williams VSA/Wyckoff/CVD |
//|    J: Harmonic + Special  (P108-P125)— Carney/Bulkowski/Brooks  |
//|                                                                  |
//|  Total: 125 patterns, all with theory references                |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERNS_MASTER_MQH
#define KMP_PATTERNS_MASTER_MQH

#include "KMP_Structures.mqh"
#include "Patterns/KMP_CandleHelpers.mqh"
#include "Patterns/KMP_PatternsA_Original.mqh"
#include "Patterns/KMP_PatternsB_Candlestick.mqh"
#include "Patterns/KMP_PatternsC_SupportRes.mqh"
#include "Patterns/KMP_PatternsD_Structure.mqh"
#include "Patterns/KMP_PatternsE_ChartPatterns.mqh"
#include "Patterns/KMP_PatternsF_SmartMoney.mqh"
#include "Patterns/KMP_PatternsG_StatEdge.mqh"
#include "Patterns/KMP_PatternsH_SMCAdvanced.mqh"
#include "Patterns/KMP_PatternsI_VolumeWyckoff.mqh"
#include "Patterns/KMP_PatternsJ_Harmonic.mqh"
#include "Patterns/KMP_PatternsK_MultiTF.mqh"
#include "Patterns/KMP_PatternsL_Ichimoku.mqh"
#include "Patterns/KMP_PatternsM_ModernSMC.mqh"
#include "Patterns/KMP_PatternsN_Momentum.mqh"
#include "Patterns/KMP_PatternsO_VolumeProfile.mqh"
#include "Patterns/KMP_PatternsP_Range.mqh"
#include "Patterns/KMP_PatternsQ_ABCD.mqh"
#include "Patterns/KMP_PatternsR_VolRegime.mqh"

//+------------------------------------------------------------------+
//| Master Pattern Detector                                          |
//|                                                                  |
//| Usage:                                                           |
//|   CMasterPatternDetector det;                                    |
//|   det.Init(Symbol(), _Period);                                   |
//|   PatternFlags flags;                                            |
//|   det.DetectAll(1, flags, snap, prev_snap);                      |
//+------------------------------------------------------------------+
class CMasterPatternDetector
{
private:
   string m_symbol;
   ENUM_TIMEFRAMES m_period;
   
   // Sub-detectors (one per category)
   CPatternDetector            m_cat_A;  // Original
   CCandlestickPatterns        m_cat_B;  // Candlesticks
   CSupportResistancePatterns  m_cat_C;  // S/R
   CStructurePatterns          m_cat_D;  // Structure
   CChartPatterns              m_cat_E;  // Chart patterns
   CSmartMoneyPatterns         m_cat_F;  // SMC
   // Phase 2 sub-detectors
   CStatEdgePatterns           m_cat_G;  // Stat-Edge
   CSMCAdvancedPatterns        m_cat_H;  // SMC Advanced
   CVolumeWyckoffPatterns      m_cat_I;  // Volume/Wyckoff/VSA
   CHarmonicPatterns           m_cat_J;  // Harmonic + Specialized
   // Phase 3 sub-detectors
   CMultiTFPatterns            m_cat_K;  // Multi-Timeframe Confluence
   CIchimokuPatterns           m_cat_L;  // Ichimoku System
   CModernSMCPatterns          m_cat_M;  // Modern SMC
   CMomentumPatterns           m_cat_N;  // Momentum + Hidden Div
   CVolumeProfilePatterns      m_cat_O;  // Volume Profile expanded
   CRangeReversionPatterns     m_cat_P;  // Range / Reversion
   CABCDPatterns               m_cat_Q;  // ABCD / Three Drives
   CVolRegimePatterns          m_cat_R;  // Volatility Regime

   // Cat R needs previous snapshot for squeeze/expansion detection
   IndicatorSnapshot           m_prev_snap;
   bool                        m_prev_snap_valid;

public:
   CMasterPatternDetector() : m_symbol(""), m_period(PERIOD_CURRENT) {}

   //+---------------------------------------------------------------+
   //| Initialize all sub-detectors                                  |
   //+---------------------------------------------------------------+
   void Init(string symbol, ENUM_TIMEFRAMES period)
   {
      m_symbol = symbol;
      m_period = period;

      m_cat_A.Init(symbol, period);
      m_cat_B.Init(symbol, period);
      m_cat_C.Init(symbol, period);
      m_cat_D.Init(symbol, period);
      m_cat_E.Init(symbol, period);
      m_cat_F.Init(symbol, period);
      m_cat_G.Init(symbol, period);
      m_cat_H.Init(symbol, period);
      m_cat_I.Init(symbol, period);
      m_cat_J.Init(symbol, period);
      m_cat_K.Init(symbol, period);
      m_cat_L.Init(symbol, period);
      m_cat_M.Init(symbol, period);
      m_cat_N.Init(symbol, period);
      m_cat_O.Init(symbol, period);
      m_cat_P.Init(symbol, period);
      m_cat_Q.Init(symbol, period);
      m_cat_R.Init(symbol, period);

      m_prev_snap.Reset();
      m_prev_snap_valid = false;
   }
   
   //+---------------------------------------------------------------+
   //| Set Cat A parameters (original patterns - WRB/wick/etc)       |
   //+---------------------------------------------------------------+
   void SetCatAParams(double wrb_mult, double wick_pct, double body_pct,
                       int multi_rej_min, double pin_wick_pct)
   {
      m_cat_A.SetParams(wrb_mult, wick_pct, body_pct, multi_rej_min, pin_wick_pct);
   }
   
   //+---------------------------------------------------------------+
   //| Set Cat B parameters (candlestick)                            |
   //+---------------------------------------------------------------+
   void SetCatBParams(double doji_body_pct = 5.0, 
                       double long_wick_pct = 60.0,
                       double marubozu_body_pct = 95.0)
   {
      m_cat_B.SetParams(doji_body_pct, long_wick_pct, marubozu_body_pct);
   }
   
   //+---------------------------------------------------------------+
   //| Set Cat C parameters (S/R)                                    |
   //+---------------------------------------------------------------+
   void SetCatCParams(int lookback = 50, double proximity_atr = 0.3,
                       double strong_atr = 2.0)
   {
      m_cat_C.SetParams(lookback, proximity_atr, strong_atr);
   }
   
   //+---------------------------------------------------------------+
   //| Set Cat D parameters (structure)                              |
   //+---------------------------------------------------------------+
   void SetCatDParams(int lookback = 50, int swing_left = 3, 
                       int swing_right = 3, double sweep_atr = 0.2)
   {
      m_cat_D.SetParams(lookback, swing_left, swing_right, sweep_atr);
   }

   //+---------------------------------------------------------------+
   //| Set Cat G parameters (Stat-Edge)                              |
   //+---------------------------------------------------------------+
   void SetCatGParams(int zscore_lookback = 20, double zscore_threshold = 2.0,
                       int orb_range_bars = 4, double orb_break_atr = 0.1)
   {
      m_cat_G.SetParams(zscore_lookback, zscore_threshold, orb_range_bars, orb_break_atr);
   }

   //+---------------------------------------------------------------+
   //| Set Cat H parameters (SMC Advanced)                           |
   //+---------------------------------------------------------------+
   void SetCatHParams(int lookback = 50,
                       double ote_lower = 0.62, double ote_upper = 0.79,
                       int lkz_start = 9,  int lkz_end = 12,
                       int nysb_start = 16, int nysb_end = 17,
                       int p3_lookback = 24)
   {
      m_cat_H.SetParams(lookback, ote_lower, ote_upper,
                        lkz_start, lkz_end, nysb_start, nysb_end, p3_lookback);
   }

   //+---------------------------------------------------------------+
   //| Set Cat I parameters (Volume / Wyckoff / VSA)                 |
   //+---------------------------------------------------------------+
   void SetCatIParams(int lookback = 50,
                       double climax_vol = 2.5, double low_vol = 0.6,
                       double climax_range = 2.0,
                       int range_lb = 30, double range_max = 3.0,
                       int div_lb = 30)
   {
      m_cat_I.SetParams(lookback, climax_vol, low_vol, climax_range,
                        range_lb, range_max, div_lb);
   }

   //+---------------------------------------------------------------+
   //| Set Cat J parameters (Harmonic + Specialized)                 |
   //+---------------------------------------------------------------+
   void SetCatJParams(int swing_lookback = 80,
                       int swing_left = 3, int swing_right = 3,
                       int asian_start = 0,  int asian_end = 8,
                       int london_start = 9, int london_end = 13)
   {
      m_cat_J.SetParams(swing_lookback, swing_left, swing_right,
                        asian_start, asian_end, london_start, london_end);
   }

   //+---------------------------------------------------------------+
   //| Set Cat M parameters (Modern SMC)                              |
   //+---------------------------------------------------------------+
   void SetCatMParams(int swing_lb = 20, int external_lb = 50,
                       int donchian = 20, double vol_climax = 2.0)
   {
      m_cat_M.SetParams(swing_lb, external_lb, donchian, vol_climax);
   }

   //+---------------------------------------------------------------+
   //| Set Cat N parameters (Momentum + Hidden Div)                   |
   //+---------------------------------------------------------------+
   void SetCatNParams(int swing_lb = 50, int div_lb = 30)
   {
      m_cat_N.SetParams(swing_lb, div_lb);
   }

   //+---------------------------------------------------------------+
   //| Set Cat O parameters (Volume Profile)                          |
   //+---------------------------------------------------------------+
   void SetCatOParams(int profile_bars = 24)
   {
      m_cat_O.SetParams(profile_bars);
   }

   //+---------------------------------------------------------------+
   //| Set Cat P parameters (Range / Reversion)                       |
   //+---------------------------------------------------------------+
   void SetCatPParams(int range_lb = 50)
   {
      m_cat_P.SetParams(range_lb);
   }

   //+---------------------------------------------------------------+
   //| Set Cat Q parameters (ABCD / Three Drives)                     |
   //+---------------------------------------------------------------+
   void SetCatQParams(int swing_lb = 50)
   {
      m_cat_Q.SetParams(swing_lb);
   }
   
   //+---------------------------------------------------------------+
   //| Detect ALL 177 patterns at given shift                       |
   //|                                                                |
   //|  shift: bar index (1 = last closed bar)                       |
   //|  flags: output - all 177 pattern flags                        |
   //|  snap:  current indicator snapshot                            |
   //|  prev_snap: previous bar's snapshot (for indicator patterns) |
   //|  prev_valid: whether prev_snap is valid                       |
   //+---------------------------------------------------------------+
   void DetectAll(int shift, PatternFlags &flags, 
                   const IndicatorSnapshot &snap,
                   const IndicatorSnapshot &prev_snap,
                   bool prev_valid)
   {
      flags.Reset();

      // Phase 1
      m_cat_A.DetectAll(shift, flags);
      if(prev_valid)
         m_cat_A.SetIndicatorPatterns(shift, flags, snap, prev_snap);
      m_cat_B.DetectAll(shift, flags);
      m_cat_C.DetectAll(shift, flags, snap);
      m_cat_D.DetectAll(shift, flags, snap);
      m_cat_E.DetectAll(shift, flags, snap);
      m_cat_F.DetectAll(shift, flags, snap);

      // Phase 2
      m_cat_G.DetectAll(shift, flags, snap);
      m_cat_H.DetectAll(shift, flags, snap);
      m_cat_I.DetectAll(shift, flags, snap);
      m_cat_J.DetectAll(shift, flags, snap);

      // Phase 3
      m_cat_K.DetectAll(shift, flags, snap);
      m_cat_L.DetectAll(shift, flags, snap);
      m_cat_M.DetectAll(shift, flags, snap);
      m_cat_N.DetectAll(shift, flags, snap);
      m_cat_O.DetectAll(shift, flags, snap);
      m_cat_P.DetectAll(shift, flags, snap);
      m_cat_Q.DetectAll(shift, flags, snap);
      m_cat_R.DetectAll(shift, flags, snap, prev_snap, prev_valid);

      // Final tally
      flags.CountAndScore();
   }
   
   //+---------------------------------------------------------------+
   //| Get category-specific count                                   |
   //+---------------------------------------------------------------+
   int CountCatA(const PatternFlags &f)
   {
      int c = 0;
      if(f.P1_MultiRej_Long) c++;
      if(f.P2_MultiRej_Short) c++;
      if(f.P3_WRB_Bull) c++;
      if(f.P4_WRB_Bear) c++;
      if(f.P5_Engulf_Trap_Bull) c++;
      if(f.P6_Engulf_Trap_Bear) c++;
      if(f.P7_PinBar) c++;
      if(f.P8_TwoBar_Reversal) c++;
      if(f.P9_BB_Touch_Reversal) c++;
      if(f.P10_BB_Squeeze_Break) c++;
      if(f.P11_EMA_Bounce) c++;
      if(f.P12_EMA_Cross) c++;
      if(f.P13_RSI_Extreme_Rev) c++;
      if(f.P14_RSI_Divergence) c++;
      if(f.P15_MACD_Zero_Cross) c++;
      if(f.P16_Stoch_Cross) c++;
      if(f.P17_Volume_Spike_Rev) c++;
      if(f.P18_Pivot_Bounce) c++;
      if(f.P19_Round_Number) c++;
      if(f.P20_Inside_Bar_Break) c++;
      return c;
   }
   
   int CountCatB(const PatternFlags &f)
   {
      int c = 0;
      if(f.P21_Doji) c++;
      if(f.P22_Dragonfly_Doji) c++;
      if(f.P23_Gravestone_Doji) c++;
      if(f.P24_Hammer) c++;
      if(f.P25_Inverted_Hammer) c++;
      if(f.P26_Hanging_Man) c++;
      if(f.P27_Shooting_Star) c++;
      if(f.P28_Bullish_Engulfing) c++;
      if(f.P29_Bearish_Engulfing) c++;
      if(f.P30_Piercing_Line) c++;
      if(f.P31_Dark_Cloud_Cover) c++;
      if(f.P32_Bullish_Harami) c++;
      if(f.P33_Bearish_Harami) c++;
      if(f.P34_Morning_Star) c++;
      if(f.P35_Evening_Star) c++;
      if(f.P36_Three_White_Soldiers) c++;
      if(f.P37_Three_Black_Crows) c++;
      if(f.P38_Tweezer_Bottom) c++;
      if(f.P39_Tweezer_Top) c++;
      if(f.P40_Marubozu) c++;
      return c;
   }
   
   int CountCatC(const PatternFlags &f)
   {
      int c = 0;
      if(f.P41_Supply_Zone_Reject) c++;
      if(f.P42_Demand_Zone_Reject) c++;
      if(f.P43_Bullish_Order_Block) c++;
      if(f.P44_Bearish_Order_Block) c++;
      if(f.P45_Breaker_Block_Bull) c++;
      if(f.P46_Breaker_Block_Bear) c++;
      if(f.P47_SR_Flip_Long) c++;
      if(f.P48_SR_Flip_Short) c++;
      if(f.P49_Trendline_Bounce_Long) c++;
      if(f.P50_Trendline_Bounce_Short) c++;
      return c;
   }
   
   int CountCatD(const PatternFlags &f)
   {
      int c = 0;
      if(f.P51_Higher_High_Higher_Low) c++;
      if(f.P52_Lower_High_Lower_Low) c++;
      if(f.P53_Break_Of_Structure_Bull) c++;
      if(f.P54_Break_Of_Structure_Bear) c++;
      if(f.P55_Change_Of_Character_Bull) c++;
      if(f.P56_Change_Of_Character_Bear) c++;
      if(f.P57_Liquidity_Sweep_Long) c++;
      if(f.P58_Liquidity_Sweep_Short) c++;
      if(f.P59_Failed_Breakout_Long) c++;
      if(f.P60_Failed_Breakout_Short) c++;
      return c;
   }
   
   int CountCatE(const PatternFlags &f)
   {
      int c = 0;
      if(f.P61_Double_Bottom) c++;
      if(f.P62_Double_Top) c++;
      if(f.P63_Triple_Bottom) c++;
      if(f.P64_Triple_Top) c++;
      if(f.P65_Head_Shoulders_Bear) c++;
      if(f.P66_Head_Shoulders_Bull) c++;
      if(f.P67_Triangle_Ascending) c++;
      if(f.P68_Triangle_Descending) c++;
      if(f.P69_Bull_Flag) c++;
      if(f.P70_Bear_Flag) c++;
      return c;
   }
   
   int CountCatF(const PatternFlags &f)
   {
      int c = 0;
      if(f.P71_Fair_Value_Gap_Bull) c++;
      if(f.P72_Fair_Value_Gap_Bear) c++;
      if(f.P73_Liquidity_Grab_Bull) c++;
      if(f.P74_Liquidity_Grab_Bear) c++;
      if(f.P75_Equal_Highs_Sweep) c++;
      if(f.P76_Equal_Lows_Sweep) c++;
      if(f.P77_Mitigation_Block_Bull) c++;
      if(f.P78_Mitigation_Block_Bear) c++;
      if(f.P79_POC_Bounce_Long) c++;
      if(f.P80_POC_Bounce_Short) c++;
      return c;
   }

   int CountCatG(const PatternFlags &f)
   {
      int c = 0;
      if(f.P81_ZScore_MeanRev_Long) c++;
      if(f.P82_ZScore_MeanRev_Short) c++;
      if(f.P83_ORB_Long) c++;
      if(f.P84_ORB_Short) c++;
      if(f.P85_NR4) c++;
      if(f.P86_NR7) c++;
      if(f.P87_BB_PctB_Extreme_Long) c++;
      if(f.P88_BB_PctB_Extreme_Short) c++;
      return c;
   }

   int CountCatH(const PatternFlags &f)
   {
      int c = 0;
      if(f.P89_OTE_Long) c++;
      if(f.P90_OTE_Short) c++;
      if(f.P91_LondonKZ_Long) c++;
      if(f.P92_LondonKZ_Short) c++;
      if(f.P93_NYSB_Long) c++;
      if(f.P94_NYSB_Short) c++;
      if(f.P95_PowerOf3_Long) c++;
      if(f.P96_PowerOf3_Short) c++;
      if(f.P97_PD_Array_Premium) c++;
      return c;
   }

   int CountCatI(const PatternFlags &f)
   {
      int c = 0;
      if(f.P98_VSA_NoDemand) c++;
      if(f.P99_VSA_NoSupply) c++;
      if(f.P100_VSA_StoppingVol_Bull) c++;
      if(f.P101_VSA_ClimacticVol_Bear) c++;
      if(f.P102_Wyckoff_Spring) c++;
      if(f.P103_Wyckoff_Upthrust) c++;
      if(f.P104_SellingClimax) c++;
      if(f.P105_BuyingClimax) c++;
      if(f.P106_CVD_Div_Bull) c++;
      if(f.P107_CVD_Div_Bear) c++;
      return c;
   }

   int CountCatJ(const PatternFlags &f)
   {
      int c = 0;
      if(f.P108_Gartley_Bull) c++;
      if(f.P109_Gartley_Bear) c++;
      if(f.P110_Bat_Bull) c++;
      if(f.P111_Bat_Bear) c++;
      if(f.P112_Butterfly_Bull) c++;
      if(f.P113_Butterfly_Bear) c++;
      if(f.P114_Crab_Bull) c++;
      if(f.P115_Crab_Bear) c++;
      if(f.P116_Cypher_Bull) c++;
      if(f.P117_Cypher_Bear) c++;
      if(f.P118_Asian_Sweep_Long) c++;
      if(f.P119_Asian_Sweep_Short) c++;
      if(f.P120_Sunday_Gap_Fill_Long) c++;
      if(f.P121_Sunday_Gap_Fill_Short) c++;
      if(f.P122_Kicker_Bull) c++;
      if(f.P123_Kicker_Bear) c++;
      if(f.P124_ThreeBar_Rev_Bull) c++;
      if(f.P125_ThreeBar_Rev_Bear) c++;
      return c;
   }

   //+---------------------------------------------------------------+
   //| PHASE 3 — Cat K..R counters                                   |
   //+---------------------------------------------------------------+
   int CountCatK(const PatternFlags &f)
   {
      int c = 0;
      if(f.P126_HTF_Bias_Long) c++;
      if(f.P127_HTF_Bias_Short) c++;
      if(f.P128_MTF_FVG_Aligned_Long) c++;
      if(f.P129_MTF_FVG_Aligned_Short) c++;
      if(f.P130_MTF_OB_Aligned_Long) c++;
      if(f.P131_MTF_OB_Aligned_Short) c++;
      if(f.P132_Daily_Bias_Intraday_Long) c++;
      if(f.P133_Daily_Bias_Intraday_Short) c++;
      if(f.P134_Triple_TF_Aligned_Long) c++;
      if(f.P135_Triple_TF_Aligned_Short) c++;
      return c;
   }

   int CountCatL(const PatternFlags &f)
   {
      int c = 0;
      if(f.P136_Ichimoku_TK_Cross_Bull) c++;
      if(f.P137_Ichimoku_TK_Cross_Bear) c++;
      if(f.P138_Ichimoku_Cloud_Break_Bull) c++;
      if(f.P139_Ichimoku_Cloud_Break_Bear) c++;
      if(f.P140_Ichimoku_Kumo_Twist_Bull) c++;
      if(f.P141_Ichimoku_Kumo_Twist_Bear) c++;
      if(f.P142_Ichimoku_Chikou_Confirm) c++;
      return c;
   }

   int CountCatM(const PatternFlags &f)
   {
      int c = 0;
      if(f.P143_Inducement_Bull) c++;
      if(f.P144_Inducement_Bear) c++;
      if(f.P145_Turtle_Soup_Long) c++;
      if(f.P146_Turtle_Soup_Short) c++;
      if(f.P147_Stop_Run_Reversal_Bull) c++;
      if(f.P148_Stop_Run_Reversal_Bear) c++;
      if(f.P149_Internal_Liq_Sweep_Long) c++;
      if(f.P150_External_Liq_Sweep_Long) c++;
      return c;
   }

   int CountCatN(const PatternFlags &f)
   {
      int c = 0;
      if(f.P151_Pullback_EMA20_Long) c++;
      if(f.P152_Pullback_EMA20_Short) c++;
      if(f.P153_Pullback_EMA50_Long) c++;
      if(f.P154_Pullback_EMA50_Short) c++;
      if(f.P155_Three_Touch_Trendline_Long) c++;
      if(f.P156_Three_Touch_Trendline_Short) c++;
      if(f.P157_Hidden_Div_Bull_RSI) c++;
      if(f.P158_Hidden_Div_Bear_RSI) c++;
      if(f.P159_Hidden_Div_Bull_MACD) c++;
      if(f.P160_Hidden_Div_Bear_MACD) c++;
      return c;
   }

   int CountCatO(const PatternFlags &f)
   {
      int c = 0;
      if(f.P161_VAH_Reject_Short) c++;
      if(f.P162_VAL_Reject_Long) c++;
      if(f.P163_Single_Print_Fill_Long) c++;
      if(f.P164_Single_Print_Fill_Short) c++;
      if(f.P165_POC_Migration_Long) c++;
      return c;
   }

   int CountCatP(const PatternFlags &f)
   {
      int c = 0;
      if(f.P166_Round_Number_Bounce_Long) c++;
      if(f.P167_Round_Number_Bounce_Short) c++;
      if(f.P168_Daily_Pivot_Tag_Long) c++;
      if(f.P169_Daily_Pivot_Tag_Short) c++;
      if(f.P170_Range_Mid_Bounce) c++;
      return c;
   }

   int CountCatQ(const PatternFlags &f)
   {
      int c = 0;
      if(f.P171_ABCD_Bull) c++;
      if(f.P172_ABCD_Bear) c++;
      if(f.P173_Three_Drives_Bull) c++;
      if(f.P174_Three_Drives_Bear) c++;
      return c;
   }

   int CountCatR(const PatternFlags &f)
   {
      int c = 0;
      if(f.P175_BB_Squeeze_Breakout_Long) c++;
      if(f.P176_BB_Squeeze_Breakout_Short) c++;
      if(f.P177_ATR_Expansion) c++;
      return c;
   }
};

#endif  // KMP_PATTERNS_MASTER_MQH