//+------------------------------------------------------------------+
//|                                              KMP_Structures.mqh |
//|                                                                  |
//|  Master pattern catalog — 125 patterns across 10 categories     |
//|                                                                  |
//|  PHASE 1 (P1-P80, default-on)                                    |
//|    A (P1-P20):   ORIGINAL STRATEGY (existing patterns)           |
//|    B (P21-P40):  CANDLESTICK PATTERNS                            |
//|    C (P41-P50):  SUPPORT/RESISTANCE & ORDER BLOCKS               |
//|    D (P51-P60):  PRICE ACTION & MARKET STRUCTURE                 |
//|    E (P61-P70):  CHART PATTERNS                                  |
//|    F (P71-P80):  SMART MONEY CONCEPTS                            |
//|                                                                  |
//|  PHASE 2 (P81-P125, opt-in)                                      |
//|    G (P81-P88):  STAT-EDGE (Crabel, Concretum, Bollinger)        |
//|    H (P89-P97):  SMC ADVANCED (ICT)                              |
//|    I (P98-P107): VOLUME / WYCKOFF / VSA                          |
//|    J (P108-P125): HARMONIC + SPECIALIZED                         |
//|                                                                  |
//|  Theory references: see /Docs/PATTERN_REFERENCE.md              |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_STRUCTURES_MQH
#define KMP_STRUCTURES_MQH

//+------------------------------------------------------------------+
//| Indicator Snapshot                                               |
//+------------------------------------------------------------------+
struct IndicatorSnapshot
{
   // EMAs
   double ema_9, ema_20, ema_50, ema_100, ema_200;
   string ema_alignment;
   
   // Bollinger Bands
   double bb_upper, bb_middle, bb_lower;
   double bb_width;
   double bb_width_avg;
   double bb_width_ratio;
   double bb_position_pct;
   bool   bb_squeeze;
   bool   bb_expansion;
   
   // ATR
   double atr_14, atr_50;
   double atr_ratio;
   string volatility_regime;
   
   // RSI / Stoch / MACD
   double rsi_7, rsi_14;
   double stoch_k, stoch_d;
   double macd_main, macd_signal, macd_histogram;
   bool   rsi_divergence_bull, rsi_divergence_bear;
   
   // Volume
   long   tick_volume;
   double volume_ma_20;
   double volume_ratio;
   bool   volume_spike;
   
   // ADX
   double adx, di_plus, di_minus;
   string trend_regime;

   // Ichimoku (Phase 3 — Cat L)
   double ichimoku_tenkan;       // Tenkan-sen (9)
   double ichimoku_kijun;        // Kijun-sen (26)
   double ichimoku_senkou_a;     // Senkou Span A at current bar (cloud)
   double ichimoku_senkou_b;     // Senkou Span B at current bar (cloud)
   double ichimoku_future_a;     // Senkou A projected forward (future cloud)
   double ichimoku_future_b;     // Senkou B projected forward
   double ichimoku_chikou;       // Chikou span (close shifted -26)
   
   // Time context
   string session;
   int    hour_of_day;
   int    day_of_week;
   
   // Pivot levels
   double pivot_pp, pivot_r1, pivot_r2, pivot_s1, pivot_s2;
   double daily_high, daily_low;
   double prev_day_high, prev_day_low;
   
   // Round numbers
   double nearest_round;
   double distance_to_round;
   
   // Bar anatomy
   double bar_range;
   double bar_body;
   double bar_upper_wick;
   double bar_lower_wick;
   double bar_body_pct;
   double bar_size_vs_avg;
   
   // Recent swing highs/lows
   double last_swing_high;
   double last_swing_low;
   datetime last_swing_high_time;
   datetime last_swing_low_time;
   int    bars_since_swing_high;
   int    bars_since_swing_low;
   string structure_state;
   
   void Reset()
   {
      ema_9 = ema_20 = ema_50 = ema_100 = ema_200 = 0;
      ema_alignment = "";
      bb_upper = bb_middle = bb_lower = 0;
      bb_width = bb_width_avg = 0;
      bb_width_ratio = bb_position_pct = 0;
      bb_squeeze = bb_expansion = false;
      atr_14 = atr_50 = atr_ratio = 0;
      volatility_regime = "";
      rsi_7 = rsi_14 = stoch_k = stoch_d = 0;
      macd_main = macd_signal = macd_histogram = 0;
      rsi_divergence_bull = rsi_divergence_bear = false;
      tick_volume = 0;
      volume_ma_20 = 0;
      volume_ratio = 0;
      volume_spike = false;
      adx = di_plus = di_minus = 0;
      trend_regime = "";
      ichimoku_tenkan = ichimoku_kijun = 0;
      ichimoku_senkou_a = ichimoku_senkou_b = 0;
      ichimoku_future_a = ichimoku_future_b = 0;
      ichimoku_chikou = 0;
      session = "";
      hour_of_day = 0;
      day_of_week = 0;
      pivot_pp = pivot_r1 = pivot_r2 = pivot_s1 = pivot_s2 = 0;
      daily_high = daily_low = 0;
      prev_day_high = prev_day_low = 0;
      nearest_round = distance_to_round = 0;
      bar_range = bar_body = 0;
      bar_upper_wick = bar_lower_wick = 0;
      bar_body_pct = bar_size_vs_avg = 0;
      last_swing_high = last_swing_low = 0;
      last_swing_high_time = last_swing_low_time = 0;
      bars_since_swing_high = bars_since_swing_low = 0;
      structure_state = "";
   }
};

//+------------------------------------------------------------------+
//| Pattern Flags — All 80 patterns                                  |
//|                                                                  |
//| Each pattern has:                                                |
//|   - Category (A/B/C/D/E/F)                                       |
//|   - Direction bias (long/short/both)                             |
//|   - Theory reference (see PATTERN_REFERENCE.md)                  |
//+------------------------------------------------------------------+
struct PatternFlags
{
   // ============ CATEGORY A: ORIGINAL STRATEGY (P1-P20) ============
   // (existing patterns, kept for backward compatibility)
   bool P1_MultiRej_Long;          // Multi-Rejection Zone Long
   bool P2_MultiRej_Short;         // Multi-Rejection Zone Short
   bool P3_WRB_Bull;               // Wide Range Bull
   bool P4_WRB_Bear;               // Wide Range Bear
   bool P5_Engulf_Trap_Bull;       // Engulfing After Trap Bull
   bool P6_Engulf_Trap_Bear;       // Engulfing After Trap Bear
   bool P7_PinBar;                 // Pin Bar
   bool P8_TwoBar_Reversal;        // Two-Bar Reversal
   bool P9_BB_Touch_Reversal;      // BB Touch + Reversal
   bool P10_BB_Squeeze_Break;      // BB Squeeze Breakout
   bool P11_EMA_Bounce;            // EMA Bounce
   bool P12_EMA_Cross;             // EMA Cross
   bool P13_RSI_Extreme_Rev;       // RSI Extreme + Reversal
   bool P14_RSI_Divergence;        // RSI Divergence
   bool P15_MACD_Zero_Cross;       // MACD Zero Cross
   bool P16_Stoch_Cross;           // Stochastic Cross
   bool P17_Volume_Spike_Rev;      // Volume Spike Reversal
   bool P18_Pivot_Bounce;          // Pivot Bounce
   bool P19_Round_Number;          // Round Number Bounce
   bool P20_Inside_Bar_Break;      // Inside Bar Break
   
   // ============ CATEGORY B: CANDLESTICK PATTERNS (P21-P40) ============
   // Reference: Steve Nison "Japanese Candlestick Charting Techniques"
   //            Thomas Bulkowski "Encyclopedia of Candlestick Charts"
   bool P21_Doji;                       // Doji (indecision)
   bool P22_Dragonfly_Doji;             // Dragonfly Doji (bullish reversal)
   bool P23_Gravestone_Doji;            // Gravestone Doji (bearish reversal)
   bool P24_Hammer;                     // Hammer (bullish reversal at low)
   bool P25_Inverted_Hammer;            // Inverted Hammer (bullish reversal)
   bool P26_Hanging_Man;                // Hanging Man (bearish reversal at high)
   bool P27_Shooting_Star;              // Shooting Star (bearish reversal)
   bool P28_Bullish_Engulfing;          // Bullish Engulfing (2-candle)
   bool P29_Bearish_Engulfing;          // Bearish Engulfing (2-candle)
   bool P30_Piercing_Line;              // Piercing Line (bullish)
   bool P31_Dark_Cloud_Cover;           // Dark Cloud Cover (bearish)
   bool P32_Bullish_Harami;             // Bullish Harami
   bool P33_Bearish_Harami;             // Bearish Harami
   bool P34_Morning_Star;               // Morning Star (3-candle bullish)
   bool P35_Evening_Star;               // Evening Star (3-candle bearish)
   bool P36_Three_White_Soldiers;       // Three White Soldiers (bullish)
   bool P37_Three_Black_Crows;          // Three Black Crows (bearish)
   bool P38_Tweezer_Bottom;             // Tweezer Bottom (bullish)
   bool P39_Tweezer_Top;                // Tweezer Top (bearish)
   bool P40_Marubozu;                   // Marubozu (strong continuation)
   
   // ============ CATEGORY C: S/R & ORDER BLOCKS (P41-P50) ============
   // Reference: Sam Seiden "Supply/Demand"
   //            ICT (Inner Circle Trader) "Order Blocks"
   //            Wyckoff "Accumulation/Distribution"
   bool P41_Supply_Zone_Reject;         // Price rejected from supply zone (short)
   bool P42_Demand_Zone_Reject;         // Price rejected from demand zone (long)
   bool P43_Bullish_Order_Block;        // Last bearish candle before strong rally
   bool P44_Bearish_Order_Block;        // Last bullish candle before strong drop
   bool P45_Breaker_Block_Bull;         // Failed bearish OB → support
   bool P46_Breaker_Block_Bear;         // Failed bullish OB → resistance
   bool P47_SR_Flip_Long;               // Old resistance → new support
   bool P48_SR_Flip_Short;              // Old support → new resistance
   bool P49_Trendline_Bounce_Long;      // Bounce off rising trendline
   bool P50_Trendline_Bounce_Short;     // Bounce off falling trendline
   
   // ============ CATEGORY D: PRICE ACTION & STRUCTURE (P51-P60) ============
   // Reference: Al Brooks "Trading Price Action"
   //            ICT "Market Structure"
   bool P51_Higher_High_Higher_Low;     // HH+HL = bullish structure
   bool P52_Lower_High_Lower_Low;       // LH+LL = bearish structure
   bool P53_Break_Of_Structure_Bull;    // BOS bullish
   bool P54_Break_Of_Structure_Bear;    // BOS bearish
   bool P55_Change_Of_Character_Bull;   // CHoCH (bearish→bullish)
   bool P56_Change_Of_Character_Bear;   // CHoCH (bullish→bearish)
   bool P57_Liquidity_Sweep_Long;       // Sweep of lows then reverse up
   bool P58_Liquidity_Sweep_Short;      // Sweep of highs then reverse down
   bool P59_Failed_Breakout_Long;       // Fake break down → reversal up
   bool P60_Failed_Breakout_Short;      // Fake break up → reversal down
   
   // ============ CATEGORY E: CHART PATTERNS (P61-P70) ============
   // Reference: Edwards & Magee "Technical Analysis of Stock Trends"
   //            Thomas Bulkowski "Encyclopedia of Chart Patterns"
   bool P61_Double_Bottom;              // W-pattern (bullish)
   bool P62_Double_Top;                 // M-pattern (bearish)
   bool P63_Triple_Bottom;              // Triple bottom (bullish)
   bool P64_Triple_Top;                 // Triple top (bearish)
   bool P65_Head_Shoulders_Bear;        // H&S top (bearish)
   bool P66_Head_Shoulders_Bull;        // Inverted H&S (bullish)
   bool P67_Triangle_Ascending;         // Ascending triangle (bullish)
   bool P68_Triangle_Descending;        // Descending triangle (bearish)
   bool P69_Bull_Flag;                  // Bull flag (bullish continuation)
   bool P70_Bear_Flag;                  // Bear flag (bearish continuation)
   
   // ============ CATEGORY F: SMART MONEY CONCEPTS (P71-P80) ============
   // Reference: ICT (Inner Circle Trader) concepts
   //            Volume Profile theory (Markets in Profile)
   bool P71_Fair_Value_Gap_Bull;        // FVG bullish (3-candle imbalance)
   bool P72_Fair_Value_Gap_Bear;        // FVG bearish
   bool P73_Liquidity_Grab_Bull;        // Stop-hunt below low → reverse up
   bool P74_Liquidity_Grab_Bear;        // Stop-hunt above high → reverse down
   bool P75_Equal_Highs_Sweep;          // Sweep of equal highs
   bool P76_Equal_Lows_Sweep;           // Sweep of equal lows
   bool P77_Mitigation_Block_Bull;      // Return to OB origin (bullish)
   bool P78_Mitigation_Block_Bear;      // Return to OB origin (bearish)
   bool P79_POC_Bounce_Long;            // Point of Control (volume) bounce up
   bool P80_POC_Bounce_Short;           // POC bounce down

   // ============ CATEGORY G: STATISTICAL EDGE (P81-P88) ============
   // Reference: Crabel, Concretum ORB, Bollinger, AQR/QuantConnect
   bool P81_ZScore_MeanRev_Long;        // Z-score <= -threshold (mean revert long)
   bool P82_ZScore_MeanRev_Short;       // Z-score >= +threshold
   bool P83_ORB_Long;                   // Opening Range Breakout long
   bool P84_ORB_Short;                  // ORB short
   bool P85_NR4;                        // Crabel NR4 (narrowest range of 4)
   bool P86_NR7;                        // Crabel NR7 (narrowest range of 7)
   bool P87_BB_PctB_Extreme_Long;       // %B <= 0 mean revert long
   bool P88_BB_PctB_Extreme_Short;      // %B >= 100 mean revert short

   // ============ CATEGORY H: SMC ADVANCED (P89-P97) ============
   // Reference: ICT (Inner Circle Trader)
   bool P89_OTE_Long;                   // Optimal Trade Entry 62-79% Fib long
   bool P90_OTE_Short;                  // OTE short
   bool P91_LondonKZ_Long;              // London Killzone bullish bar
   bool P92_LondonKZ_Short;             // London Killzone bearish bar
   bool P93_NYSB_Long;                  // NY Silver Bullet bullish
   bool P94_NYSB_Short;                 // NY Silver Bullet bearish
   bool P95_PowerOf3_Long;              // AMD: Accum-Manip-Distrib bullish
   bool P96_PowerOf3_Short;             // Power of 3 bearish
   bool P97_PD_Array_Premium;           // Premium-Discount: short bias above mid

   // ============ CATEGORY I: VOLUME / WYCKOFF / VSA (P98-P107) ============
   // Reference: Tom Williams VSA, Wyckoff, Bookmap CVD
   bool P98_VSA_NoDemand;               // Up bar narrow + low vol = bear cont.
   bool P99_VSA_NoSupply;               // Down bar narrow + low vol = bull cont.
   bool P100_VSA_StoppingVol_Bull;      // Down bar high vol close near high = bull rev.
   bool P101_VSA_ClimacticVol_Bear;     // Up bar high vol close near low = bear rev.
   bool P102_Wyckoff_Spring;            // Sweep below range support → reversal
   bool P103_Wyckoff_Upthrust;          // Sweep above range resistance → reversal
   bool P104_SellingClimax;             // Extreme down vol + range = exhaustion long
   bool P105_BuyingClimax;              // Extreme up vol + range = exhaustion short
   bool P106_CVD_Div_Bull;              // Price LL + signed-vol HL approx
   bool P107_CVD_Div_Bear;              // Price HH + signed-vol LH approx

   // ============ CATEGORY J: HARMONIC + SPECIALIZED (P108-P125) ============
   // Reference: Carney "Harmonic Trading", Bulkowski Kicker, classical PA
   bool P108_Gartley_Bull;              // XABCD Gartley bullish
   bool P109_Gartley_Bear;              // XABCD Gartley bearish
   bool P110_Bat_Bull;                  // Bat bullish
   bool P111_Bat_Bear;                  // Bat bearish
   bool P112_Butterfly_Bull;            // Butterfly bullish
   bool P113_Butterfly_Bear;            // Butterfly bearish
   bool P114_Crab_Bull;                 // Crab bullish (deepest extension)
   bool P115_Crab_Bear;                 // Crab bearish
   bool P116_Cypher_Bull;               // Cypher bullish
   bool P117_Cypher_Bear;               // Cypher bearish
   bool P118_Asian_Sweep_Long;          // Asian range low swept → London long
   bool P119_Asian_Sweep_Short;         // Asian range high swept → London short
   bool P120_Sunday_Gap_Fill_Long;      // Gap-down weekend → fill long
   bool P121_Sunday_Gap_Fill_Short;     // Gap-up weekend → fill short
   bool P122_Kicker_Bull;               // Bulkowski kicker bullish (~78%)
   bool P123_Kicker_Bear;               // Bulkowski kicker bearish
   bool P124_ThreeBar_Rev_Bull;         // Brooks 3-bar reversal long
   bool P125_ThreeBar_Rev_Bear;         // Brooks 3-bar reversal short

   // ============ CATEGORY K: MULTI-TIMEFRAME CONFLUENCE (P126-P135) ============
   // Reference: ICT MTF hierarchy + classical trend-following
   bool P126_HTF_Bias_Long;             // HTF EMA-aligned + LTF bullish bar
   bool P127_HTF_Bias_Short;
   bool P128_MTF_FVG_Aligned_Long;      // LTF entry inside HTF bullish FVG
   bool P129_MTF_FVG_Aligned_Short;
   bool P130_MTF_OB_Aligned_Long;       // LTF entry inside HTF bullish OB
   bool P131_MTF_OB_Aligned_Short;
   bool P132_Daily_Bias_Intraday_Long;  // D1 green + LTF bullish
   bool P133_Daily_Bias_Intraday_Short;
   bool P134_Triple_TF_Aligned_Long;    // D1 + H4 + H1 ทุก TF EMA bull
   bool P135_Triple_TF_Aligned_Short;

   // ============ CATEGORY L: ICHIMOKU SYSTEM (P136-P142) ============
   // Reference: Goichi Hosoda 1968, Patel et al. 2015 academic study
   bool P136_Ichimoku_TK_Cross_Bull;    // Tenkan crosses above Kijun
   bool P137_Ichimoku_TK_Cross_Bear;
   bool P138_Ichimoku_Cloud_Break_Bull; // Close breaks above cloud
   bool P139_Ichimoku_Cloud_Break_Bear;
   bool P140_Ichimoku_Kumo_Twist_Bull;  // Future cloud color flips green
   bool P141_Ichimoku_Kumo_Twist_Bear;
   bool P142_Ichimoku_Chikou_Confirm;   // Chikou span in clear space (BOTH dir)

   // ============ CATEGORY M: MODERN SMC (P143-P150) ============
   // Reference: ICT advanced + Larry Williams Turtle Soup
   bool P143_Inducement_Bull;           // Fake low sweep + reject in same bar
   bool P144_Inducement_Bear;
   bool P145_Turtle_Soup_Long;          // 20-day high break failed → long
   bool P146_Turtle_Soup_Short;
   bool P147_Stop_Run_Reversal_Bull;    // Sweep + high vol + close upper third
   bool P148_Stop_Run_Reversal_Bear;
   bool P149_Internal_Liq_Sweep_Long;   // Sweep minor swing low (≤20 bars)
   bool P150_External_Liq_Sweep_Long;   // Sweep major swing low (50+ bars)

   // ============ CATEGORY N: MOMENTUM + HIDDEN DIVERGENCE (P151-P160) ============
   // Reference: Brooks PA + Constance Brown Tech Analysis
   bool P151_Pullback_EMA20_Long;       // Strong uptrend + low touches EMA20
   bool P152_Pullback_EMA20_Short;
   bool P153_Pullback_EMA50_Long;       // Deeper pullback to EMA50
   bool P154_Pullback_EMA50_Short;
   bool P155_Three_Touch_Trendline_Long;// 3rd touch of trendline + bull bar
   bool P156_Three_Touch_Trendline_Short;
   bool P157_Hidden_Div_Bull_RSI;       // Price HL + RSI LL (continuation)
   bool P158_Hidden_Div_Bear_RSI;       // Price LH + RSI HH
   bool P159_Hidden_Div_Bull_MACD;
   bool P160_Hidden_Div_Bear_MACD;

   // ============ CATEGORY O: VOLUME PROFILE EXPANDED (P161-P165) ============
   // Reference: Steidlmayer Market Profile, Dalton
   bool P161_VAH_Reject_Short;          // Bounce off Value Area High
   bool P162_VAL_Reject_Long;           // Bounce off Value Area Low
   bool P163_Single_Print_Fill_Long;    // Low-volume gap fill long
   bool P164_Single_Print_Fill_Short;
   bool P165_POC_Migration_Long;        // POC trending up 3 days

   // ============ CATEGORY P: RANGE / REVERSION (P166-P170) ============
   // Reference: classical pivot trading + round number psychology
   bool P166_Round_Number_Bounce_Long;  // Bounce at round price
   bool P167_Round_Number_Bounce_Short;
   bool P168_Daily_Pivot_Tag_Long;      // Touch daily pivot + reverse up
   bool P169_Daily_Pivot_Tag_Short;
   bool P170_Range_Mid_Bounce;          // 50% of trading range bounce (BOTH)

   // ============ CATEGORY Q: ABCD / THREE DRIVES (P171-P174) ============
   // Reference: Carney harmonic light + Connors AR
   bool P171_ABCD_Bull;                 // 4-leg pattern, CD ≈ AB
   bool P172_ABCD_Bear;
   bool P173_Three_Drives_Bull;         // 3 successive HL + reversal
   bool P174_Three_Drives_Bear;

   // ============ CATEGORY R: VOLATILITY REGIME (P175-P177) ============
   // Reference: Bollinger + Crabel volatility cycle
   bool P175_BB_Squeeze_Breakout_Long;  // Squeeze + close above mid
   bool P176_BB_Squeeze_Breakout_Short;
   bool P177_ATR_Expansion;             // ATR ratio jump ≥ 2.0 (BOTH)

   // Meta
   int  total_count;
   int  direction;                       // 1=Long, -1=Short, 0=Neutral
   
   //+---------------------------------------------------------------+
   //| Reset                                                         |
   //+---------------------------------------------------------------+
   void Reset()
   {
      // Cat A
      P1_MultiRej_Long = false;
      P2_MultiRej_Short = false;
      P3_WRB_Bull = false;
      P4_WRB_Bear = false;
      P5_Engulf_Trap_Bull = false;
      P6_Engulf_Trap_Bear = false;
      P7_PinBar = false;
      P8_TwoBar_Reversal = false;
      P9_BB_Touch_Reversal = false;
      P10_BB_Squeeze_Break = false;
      P11_EMA_Bounce = false;
      P12_EMA_Cross = false;
      P13_RSI_Extreme_Rev = false;
      P14_RSI_Divergence = false;
      P15_MACD_Zero_Cross = false;
      P16_Stoch_Cross = false;
      P17_Volume_Spike_Rev = false;
      P18_Pivot_Bounce = false;
      P19_Round_Number = false;
      P20_Inside_Bar_Break = false;
      
      // Cat B
      P21_Doji = false;
      P22_Dragonfly_Doji = false;
      P23_Gravestone_Doji = false;
      P24_Hammer = false;
      P25_Inverted_Hammer = false;
      P26_Hanging_Man = false;
      P27_Shooting_Star = false;
      P28_Bullish_Engulfing = false;
      P29_Bearish_Engulfing = false;
      P30_Piercing_Line = false;
      P31_Dark_Cloud_Cover = false;
      P32_Bullish_Harami = false;
      P33_Bearish_Harami = false;
      P34_Morning_Star = false;
      P35_Evening_Star = false;
      P36_Three_White_Soldiers = false;
      P37_Three_Black_Crows = false;
      P38_Tweezer_Bottom = false;
      P39_Tweezer_Top = false;
      P40_Marubozu = false;
      
      // Cat C
      P41_Supply_Zone_Reject = false;
      P42_Demand_Zone_Reject = false;
      P43_Bullish_Order_Block = false;
      P44_Bearish_Order_Block = false;
      P45_Breaker_Block_Bull = false;
      P46_Breaker_Block_Bear = false;
      P47_SR_Flip_Long = false;
      P48_SR_Flip_Short = false;
      P49_Trendline_Bounce_Long = false;
      P50_Trendline_Bounce_Short = false;
      
      // Cat D
      P51_Higher_High_Higher_Low = false;
      P52_Lower_High_Lower_Low = false;
      P53_Break_Of_Structure_Bull = false;
      P54_Break_Of_Structure_Bear = false;
      P55_Change_Of_Character_Bull = false;
      P56_Change_Of_Character_Bear = false;
      P57_Liquidity_Sweep_Long = false;
      P58_Liquidity_Sweep_Short = false;
      P59_Failed_Breakout_Long = false;
      P60_Failed_Breakout_Short = false;
      
      // Cat E
      P61_Double_Bottom = false;
      P62_Double_Top = false;
      P63_Triple_Bottom = false;
      P64_Triple_Top = false;
      P65_Head_Shoulders_Bear = false;
      P66_Head_Shoulders_Bull = false;
      P67_Triangle_Ascending = false;
      P68_Triangle_Descending = false;
      P69_Bull_Flag = false;
      P70_Bear_Flag = false;
      
      // Cat F
      P71_Fair_Value_Gap_Bull = false;
      P72_Fair_Value_Gap_Bear = false;
      P73_Liquidity_Grab_Bull = false;
      P74_Liquidity_Grab_Bear = false;
      P75_Equal_Highs_Sweep = false;
      P76_Equal_Lows_Sweep = false;
      P77_Mitigation_Block_Bull = false;
      P78_Mitigation_Block_Bear = false;
      P79_POC_Bounce_Long = false;
      P80_POC_Bounce_Short = false;

      // Cat G
      P81_ZScore_MeanRev_Long = false;
      P82_ZScore_MeanRev_Short = false;
      P83_ORB_Long = false;
      P84_ORB_Short = false;
      P85_NR4 = false;
      P86_NR7 = false;
      P87_BB_PctB_Extreme_Long = false;
      P88_BB_PctB_Extreme_Short = false;

      // Cat H
      P89_OTE_Long = false;
      P90_OTE_Short = false;
      P91_LondonKZ_Long = false;
      P92_LondonKZ_Short = false;
      P93_NYSB_Long = false;
      P94_NYSB_Short = false;
      P95_PowerOf3_Long = false;
      P96_PowerOf3_Short = false;
      P97_PD_Array_Premium = false;

      // Cat I
      P98_VSA_NoDemand = false;
      P99_VSA_NoSupply = false;
      P100_VSA_StoppingVol_Bull = false;
      P101_VSA_ClimacticVol_Bear = false;
      P102_Wyckoff_Spring = false;
      P103_Wyckoff_Upthrust = false;
      P104_SellingClimax = false;
      P105_BuyingClimax = false;
      P106_CVD_Div_Bull = false;
      P107_CVD_Div_Bear = false;

      // Cat J
      P108_Gartley_Bull = false;
      P109_Gartley_Bear = false;
      P110_Bat_Bull = false;
      P111_Bat_Bear = false;
      P112_Butterfly_Bull = false;
      P113_Butterfly_Bear = false;
      P114_Crab_Bull = false;
      P115_Crab_Bear = false;
      P116_Cypher_Bull = false;
      P117_Cypher_Bear = false;
      P118_Asian_Sweep_Long = false;
      P119_Asian_Sweep_Short = false;
      P120_Sunday_Gap_Fill_Long = false;
      P121_Sunday_Gap_Fill_Short = false;
      P122_Kicker_Bull = false;
      P123_Kicker_Bear = false;
      P124_ThreeBar_Rev_Bull = false;
      P125_ThreeBar_Rev_Bear = false;

      // Cat K
      P126_HTF_Bias_Long = false;
      P127_HTF_Bias_Short = false;
      P128_MTF_FVG_Aligned_Long = false;
      P129_MTF_FVG_Aligned_Short = false;
      P130_MTF_OB_Aligned_Long = false;
      P131_MTF_OB_Aligned_Short = false;
      P132_Daily_Bias_Intraday_Long = false;
      P133_Daily_Bias_Intraday_Short = false;
      P134_Triple_TF_Aligned_Long = false;
      P135_Triple_TF_Aligned_Short = false;

      // Cat L
      P136_Ichimoku_TK_Cross_Bull = false;
      P137_Ichimoku_TK_Cross_Bear = false;
      P138_Ichimoku_Cloud_Break_Bull = false;
      P139_Ichimoku_Cloud_Break_Bear = false;
      P140_Ichimoku_Kumo_Twist_Bull = false;
      P141_Ichimoku_Kumo_Twist_Bear = false;
      P142_Ichimoku_Chikou_Confirm = false;

      // Cat M
      P143_Inducement_Bull = false;
      P144_Inducement_Bear = false;
      P145_Turtle_Soup_Long = false;
      P146_Turtle_Soup_Short = false;
      P147_Stop_Run_Reversal_Bull = false;
      P148_Stop_Run_Reversal_Bear = false;
      P149_Internal_Liq_Sweep_Long = false;
      P150_External_Liq_Sweep_Long = false;

      // Cat N
      P151_Pullback_EMA20_Long = false;
      P152_Pullback_EMA20_Short = false;
      P153_Pullback_EMA50_Long = false;
      P154_Pullback_EMA50_Short = false;
      P155_Three_Touch_Trendline_Long = false;
      P156_Three_Touch_Trendline_Short = false;
      P157_Hidden_Div_Bull_RSI = false;
      P158_Hidden_Div_Bear_RSI = false;
      P159_Hidden_Div_Bull_MACD = false;
      P160_Hidden_Div_Bear_MACD = false;

      // Cat O
      P161_VAH_Reject_Short = false;
      P162_VAL_Reject_Long = false;
      P163_Single_Print_Fill_Long = false;
      P164_Single_Print_Fill_Short = false;
      P165_POC_Migration_Long = false;

      // Cat P
      P166_Round_Number_Bounce_Long = false;
      P167_Round_Number_Bounce_Short = false;
      P168_Daily_Pivot_Tag_Long = false;
      P169_Daily_Pivot_Tag_Short = false;
      P170_Range_Mid_Bounce = false;

      // Cat Q
      P171_ABCD_Bull = false;
      P172_ABCD_Bear = false;
      P173_Three_Drives_Bull = false;
      P174_Three_Drives_Bear = false;

      // Cat R
      P175_BB_Squeeze_Breakout_Long = false;
      P176_BB_Squeeze_Breakout_Short = false;
      P177_ATR_Expansion = false;

      total_count = 0;
      direction = 0;
   }
   
   //+---------------------------------------------------------------+
   //| Calculate total count and dominant direction                  |
   //+---------------------------------------------------------------+
   void CountAndScore()
   {
      total_count = 0;
      int long_score = 0, short_score = 0;
      
      // Cat A
      if(P1_MultiRej_Long) { total_count++; long_score++; }
      if(P2_MultiRej_Short) { total_count++; short_score++; }
      if(P3_WRB_Bull) { total_count++; long_score++; }
      if(P4_WRB_Bear) { total_count++; short_score++; }
      if(P5_Engulf_Trap_Bull) { total_count++; long_score++; }
      if(P6_Engulf_Trap_Bear) { total_count++; short_score++; }
      if(P7_PinBar) total_count++;
      if(P8_TwoBar_Reversal) total_count++;
      if(P9_BB_Touch_Reversal) total_count++;
      if(P10_BB_Squeeze_Break) total_count++;
      if(P11_EMA_Bounce) total_count++;
      if(P12_EMA_Cross) total_count++;
      if(P13_RSI_Extreme_Rev) total_count++;
      if(P14_RSI_Divergence) total_count++;
      if(P15_MACD_Zero_Cross) total_count++;
      if(P16_Stoch_Cross) total_count++;
      if(P17_Volume_Spike_Rev) total_count++;
      if(P18_Pivot_Bounce) total_count++;
      if(P19_Round_Number) total_count++;
      if(P20_Inside_Bar_Break) total_count++;
      
      // Cat B (Candlesticks - directional)
      if(P21_Doji) total_count++;
      if(P22_Dragonfly_Doji) { total_count++; long_score++; }
      if(P23_Gravestone_Doji) { total_count++; short_score++; }
      if(P24_Hammer) { total_count++; long_score++; }
      if(P25_Inverted_Hammer) { total_count++; long_score++; }
      if(P26_Hanging_Man) { total_count++; short_score++; }
      if(P27_Shooting_Star) { total_count++; short_score++; }
      if(P28_Bullish_Engulfing) { total_count++; long_score++; }
      if(P29_Bearish_Engulfing) { total_count++; short_score++; }
      if(P30_Piercing_Line) { total_count++; long_score++; }
      if(P31_Dark_Cloud_Cover) { total_count++; short_score++; }
      if(P32_Bullish_Harami) { total_count++; long_score++; }
      if(P33_Bearish_Harami) { total_count++; short_score++; }
      if(P34_Morning_Star) { total_count++; long_score++; }
      if(P35_Evening_Star) { total_count++; short_score++; }
      if(P36_Three_White_Soldiers) { total_count++; long_score++; }
      if(P37_Three_Black_Crows) { total_count++; short_score++; }
      if(P38_Tweezer_Bottom) { total_count++; long_score++; }
      if(P39_Tweezer_Top) { total_count++; short_score++; }
      if(P40_Marubozu) total_count++;  // direction-agnostic (bull or bear)
      
      // Cat C (S/R)
      if(P41_Supply_Zone_Reject) { total_count++; short_score++; }
      if(P42_Demand_Zone_Reject) { total_count++; long_score++; }
      if(P43_Bullish_Order_Block) { total_count++; long_score++; }
      if(P44_Bearish_Order_Block) { total_count++; short_score++; }
      if(P45_Breaker_Block_Bull) { total_count++; long_score++; }
      if(P46_Breaker_Block_Bear) { total_count++; short_score++; }
      if(P47_SR_Flip_Long) { total_count++; long_score++; }
      if(P48_SR_Flip_Short) { total_count++; short_score++; }
      if(P49_Trendline_Bounce_Long) { total_count++; long_score++; }
      if(P50_Trendline_Bounce_Short) { total_count++; short_score++; }
      
      // Cat D (Structure)
      if(P51_Higher_High_Higher_Low) { total_count++; long_score++; }
      if(P52_Lower_High_Lower_Low) { total_count++; short_score++; }
      if(P53_Break_Of_Structure_Bull) { total_count++; long_score++; }
      if(P54_Break_Of_Structure_Bear) { total_count++; short_score++; }
      if(P55_Change_Of_Character_Bull) { total_count++; long_score++; }
      if(P56_Change_Of_Character_Bear) { total_count++; short_score++; }
      if(P57_Liquidity_Sweep_Long) { total_count++; long_score++; }
      if(P58_Liquidity_Sweep_Short) { total_count++; short_score++; }
      if(P59_Failed_Breakout_Long) { total_count++; long_score++; }
      if(P60_Failed_Breakout_Short) { total_count++; short_score++; }
      
      // Cat E (Chart patterns)
      if(P61_Double_Bottom) { total_count++; long_score++; }
      if(P62_Double_Top) { total_count++; short_score++; }
      if(P63_Triple_Bottom) { total_count++; long_score++; }
      if(P64_Triple_Top) { total_count++; short_score++; }
      if(P65_Head_Shoulders_Bear) { total_count++; short_score++; }
      if(P66_Head_Shoulders_Bull) { total_count++; long_score++; }
      if(P67_Triangle_Ascending) { total_count++; long_score++; }
      if(P68_Triangle_Descending) { total_count++; short_score++; }
      if(P69_Bull_Flag) { total_count++; long_score++; }
      if(P70_Bear_Flag) { total_count++; short_score++; }
      
      // Cat F (SMC)
      if(P71_Fair_Value_Gap_Bull) { total_count++; long_score++; }
      if(P72_Fair_Value_Gap_Bear) { total_count++; short_score++; }
      if(P73_Liquidity_Grab_Bull) { total_count++; long_score++; }
      if(P74_Liquidity_Grab_Bear) { total_count++; short_score++; }
      if(P75_Equal_Highs_Sweep) { total_count++; short_score++; }
      if(P76_Equal_Lows_Sweep) { total_count++; long_score++; }
      if(P77_Mitigation_Block_Bull) { total_count++; long_score++; }
      if(P78_Mitigation_Block_Bear) { total_count++; short_score++; }
      if(P79_POC_Bounce_Long) { total_count++; long_score++; }
      if(P80_POC_Bounce_Short) { total_count++; short_score++; }

      // Cat G (Stat-Edge)
      if(P81_ZScore_MeanRev_Long)  { total_count++; long_score++; }
      if(P82_ZScore_MeanRev_Short) { total_count++; short_score++; }
      if(P83_ORB_Long)             { total_count++; long_score++; }
      if(P84_ORB_Short)            { total_count++; short_score++; }
      if(P85_NR4) total_count++;   // direction-agnostic
      if(P86_NR7) total_count++;   // direction-agnostic
      if(P87_BB_PctB_Extreme_Long) { total_count++; long_score++; }
      if(P88_BB_PctB_Extreme_Short){ total_count++; short_score++; }

      // Cat H (SMC Advanced)
      if(P89_OTE_Long)        { total_count++; long_score++; }
      if(P90_OTE_Short)       { total_count++; short_score++; }
      if(P91_LondonKZ_Long)   { total_count++; long_score++; }
      if(P92_LondonKZ_Short)  { total_count++; short_score++; }
      if(P93_NYSB_Long)       { total_count++; long_score++; }
      if(P94_NYSB_Short)      { total_count++; short_score++; }
      if(P95_PowerOf3_Long)   { total_count++; long_score++; }
      if(P96_PowerOf3_Short)  { total_count++; short_score++; }
      if(P97_PD_Array_Premium){ total_count++; short_score++; }

      // Cat I (Volume / Wyckoff / VSA)
      if(P98_VSA_NoDemand)            { total_count++; short_score++; }
      if(P99_VSA_NoSupply)            { total_count++; long_score++; }
      if(P100_VSA_StoppingVol_Bull)   { total_count++; long_score++; }
      if(P101_VSA_ClimacticVol_Bear)  { total_count++; short_score++; }
      if(P102_Wyckoff_Spring)         { total_count++; long_score++; }
      if(P103_Wyckoff_Upthrust)       { total_count++; short_score++; }
      if(P104_SellingClimax)          { total_count++; long_score++; }
      if(P105_BuyingClimax)           { total_count++; short_score++; }
      if(P106_CVD_Div_Bull)           { total_count++; long_score++; }
      if(P107_CVD_Div_Bear)           { total_count++; short_score++; }

      // Cat J (Harmonic + Specialized)
      if(P108_Gartley_Bull)        { total_count++; long_score++; }
      if(P109_Gartley_Bear)        { total_count++; short_score++; }
      if(P110_Bat_Bull)            { total_count++; long_score++; }
      if(P111_Bat_Bear)            { total_count++; short_score++; }
      if(P112_Butterfly_Bull)      { total_count++; long_score++; }
      if(P113_Butterfly_Bear)      { total_count++; short_score++; }
      if(P114_Crab_Bull)           { total_count++; long_score++; }
      if(P115_Crab_Bear)           { total_count++; short_score++; }
      if(P116_Cypher_Bull)         { total_count++; long_score++; }
      if(P117_Cypher_Bear)         { total_count++; short_score++; }
      if(P118_Asian_Sweep_Long)    { total_count++; long_score++; }
      if(P119_Asian_Sweep_Short)   { total_count++; short_score++; }
      if(P120_Sunday_Gap_Fill_Long){ total_count++; long_score++; }
      if(P121_Sunday_Gap_Fill_Short){ total_count++; short_score++; }
      if(P122_Kicker_Bull)         { total_count++; long_score++; }
      if(P123_Kicker_Bear)         { total_count++; short_score++; }
      if(P124_ThreeBar_Rev_Bull)   { total_count++; long_score++; }
      if(P125_ThreeBar_Rev_Bear)   { total_count++; short_score++; }

      // Cat K (Multi-TF Confluence)
      if(P126_HTF_Bias_Long)         { total_count++; long_score++; }
      if(P127_HTF_Bias_Short)        { total_count++; short_score++; }
      if(P128_MTF_FVG_Aligned_Long)  { total_count++; long_score++; }
      if(P129_MTF_FVG_Aligned_Short) { total_count++; short_score++; }
      if(P130_MTF_OB_Aligned_Long)   { total_count++; long_score++; }
      if(P131_MTF_OB_Aligned_Short)  { total_count++; short_score++; }
      if(P132_Daily_Bias_Intraday_Long)  { total_count++; long_score++; }
      if(P133_Daily_Bias_Intraday_Short) { total_count++; short_score++; }
      if(P134_Triple_TF_Aligned_Long)    { total_count++; long_score++; }
      if(P135_Triple_TF_Aligned_Short)   { total_count++; short_score++; }

      // Cat L (Ichimoku)
      if(P136_Ichimoku_TK_Cross_Bull)    { total_count++; long_score++; }
      if(P137_Ichimoku_TK_Cross_Bear)    { total_count++; short_score++; }
      if(P138_Ichimoku_Cloud_Break_Bull) { total_count++; long_score++; }
      if(P139_Ichimoku_Cloud_Break_Bear) { total_count++; short_score++; }
      if(P140_Ichimoku_Kumo_Twist_Bull)  { total_count++; long_score++; }
      if(P141_Ichimoku_Kumo_Twist_Bear)  { total_count++; short_score++; }
      if(P142_Ichimoku_Chikou_Confirm)   total_count++;  // direction-agnostic

      // Cat M (Modern SMC)
      if(P143_Inducement_Bull)          { total_count++; long_score++; }
      if(P144_Inducement_Bear)          { total_count++; short_score++; }
      if(P145_Turtle_Soup_Long)         { total_count++; long_score++; }
      if(P146_Turtle_Soup_Short)        { total_count++; short_score++; }
      if(P147_Stop_Run_Reversal_Bull)   { total_count++; long_score++; }
      if(P148_Stop_Run_Reversal_Bear)   { total_count++; short_score++; }
      if(P149_Internal_Liq_Sweep_Long)  { total_count++; long_score++; }
      if(P150_External_Liq_Sweep_Long)  { total_count++; long_score++; }

      // Cat N (Momentum + Hidden Div)
      if(P151_Pullback_EMA20_Long)        { total_count++; long_score++; }
      if(P152_Pullback_EMA20_Short)       { total_count++; short_score++; }
      if(P153_Pullback_EMA50_Long)        { total_count++; long_score++; }
      if(P154_Pullback_EMA50_Short)       { total_count++; short_score++; }
      if(P155_Three_Touch_Trendline_Long) { total_count++; long_score++; }
      if(P156_Three_Touch_Trendline_Short){ total_count++; short_score++; }
      if(P157_Hidden_Div_Bull_RSI)        { total_count++; long_score++; }
      if(P158_Hidden_Div_Bear_RSI)        { total_count++; short_score++; }
      if(P159_Hidden_Div_Bull_MACD)       { total_count++; long_score++; }
      if(P160_Hidden_Div_Bear_MACD)       { total_count++; short_score++; }

      // Cat O (Volume Profile)
      if(P161_VAH_Reject_Short)        { total_count++; short_score++; }
      if(P162_VAL_Reject_Long)         { total_count++; long_score++; }
      if(P163_Single_Print_Fill_Long)  { total_count++; long_score++; }
      if(P164_Single_Print_Fill_Short) { total_count++; short_score++; }
      if(P165_POC_Migration_Long)      { total_count++; long_score++; }

      // Cat P (Range / Reversion)
      if(P166_Round_Number_Bounce_Long)  { total_count++; long_score++; }
      if(P167_Round_Number_Bounce_Short) { total_count++; short_score++; }
      if(P168_Daily_Pivot_Tag_Long)      { total_count++; long_score++; }
      if(P169_Daily_Pivot_Tag_Short)     { total_count++; short_score++; }
      if(P170_Range_Mid_Bounce)          total_count++;  // direction-agnostic

      // Cat Q (ABCD / Three Drives)
      if(P171_ABCD_Bull)         { total_count++; long_score++; }
      if(P172_ABCD_Bear)         { total_count++; short_score++; }
      if(P173_Three_Drives_Bull) { total_count++; long_score++; }
      if(P174_Three_Drives_Bear) { total_count++; short_score++; }

      // Cat R (Volatility Regime)
      if(P175_BB_Squeeze_Breakout_Long)  { total_count++; long_score++; }
      if(P176_BB_Squeeze_Breakout_Short) { total_count++; short_score++; }
      if(P177_ATR_Expansion)             total_count++;  // direction-agnostic

      // Determine dominant direction
      if(long_score > short_score) direction = 1;
      else if(short_score > long_score) direction = -1;
      else direction = 0;
   }
   
   //+---------------------------------------------------------------+
   //| Build CSV list for logging                                    |
   //+---------------------------------------------------------------+
   string ToCSVList() const
   {
      string s = "";
      // Cat A
      if(P1_MultiRej_Long) s += "P1 ";
      if(P2_MultiRej_Short) s += "P2 ";
      if(P3_WRB_Bull) s += "P3 ";
      if(P4_WRB_Bear) s += "P4 ";
      if(P5_Engulf_Trap_Bull) s += "P5 ";
      if(P6_Engulf_Trap_Bear) s += "P6 ";
      if(P7_PinBar) s += "P7 ";
      if(P8_TwoBar_Reversal) s += "P8 ";
      if(P9_BB_Touch_Reversal) s += "P9 ";
      if(P10_BB_Squeeze_Break) s += "P10 ";
      if(P11_EMA_Bounce) s += "P11 ";
      if(P12_EMA_Cross) s += "P12 ";
      if(P13_RSI_Extreme_Rev) s += "P13 ";
      if(P14_RSI_Divergence) s += "P14 ";
      if(P15_MACD_Zero_Cross) s += "P15 ";
      if(P16_Stoch_Cross) s += "P16 ";
      if(P17_Volume_Spike_Rev) s += "P17 ";
      if(P18_Pivot_Bounce) s += "P18 ";
      if(P19_Round_Number) s += "P19 ";
      if(P20_Inside_Bar_Break) s += "P20 ";
      // Cat B
      if(P21_Doji) s += "P21 ";
      if(P22_Dragonfly_Doji) s += "P22 ";
      if(P23_Gravestone_Doji) s += "P23 ";
      if(P24_Hammer) s += "P24 ";
      if(P25_Inverted_Hammer) s += "P25 ";
      if(P26_Hanging_Man) s += "P26 ";
      if(P27_Shooting_Star) s += "P27 ";
      if(P28_Bullish_Engulfing) s += "P28 ";
      if(P29_Bearish_Engulfing) s += "P29 ";
      if(P30_Piercing_Line) s += "P30 ";
      if(P31_Dark_Cloud_Cover) s += "P31 ";
      if(P32_Bullish_Harami) s += "P32 ";
      if(P33_Bearish_Harami) s += "P33 ";
      if(P34_Morning_Star) s += "P34 ";
      if(P35_Evening_Star) s += "P35 ";
      if(P36_Three_White_Soldiers) s += "P36 ";
      if(P37_Three_Black_Crows) s += "P37 ";
      if(P38_Tweezer_Bottom) s += "P38 ";
      if(P39_Tweezer_Top) s += "P39 ";
      if(P40_Marubozu) s += "P40 ";
      // Cat C
      if(P41_Supply_Zone_Reject) s += "P41 ";
      if(P42_Demand_Zone_Reject) s += "P42 ";
      if(P43_Bullish_Order_Block) s += "P43 ";
      if(P44_Bearish_Order_Block) s += "P44 ";
      if(P45_Breaker_Block_Bull) s += "P45 ";
      if(P46_Breaker_Block_Bear) s += "P46 ";
      if(P47_SR_Flip_Long) s += "P47 ";
      if(P48_SR_Flip_Short) s += "P48 ";
      if(P49_Trendline_Bounce_Long) s += "P49 ";
      if(P50_Trendline_Bounce_Short) s += "P50 ";
      // Cat D
      if(P51_Higher_High_Higher_Low) s += "P51 ";
      if(P52_Lower_High_Lower_Low) s += "P52 ";
      if(P53_Break_Of_Structure_Bull) s += "P53 ";
      if(P54_Break_Of_Structure_Bear) s += "P54 ";
      if(P55_Change_Of_Character_Bull) s += "P55 ";
      if(P56_Change_Of_Character_Bear) s += "P56 ";
      if(P57_Liquidity_Sweep_Long) s += "P57 ";
      if(P58_Liquidity_Sweep_Short) s += "P58 ";
      if(P59_Failed_Breakout_Long) s += "P59 ";
      if(P60_Failed_Breakout_Short) s += "P60 ";
      // Cat E
      if(P61_Double_Bottom) s += "P61 ";
      if(P62_Double_Top) s += "P62 ";
      if(P63_Triple_Bottom) s += "P63 ";
      if(P64_Triple_Top) s += "P64 ";
      if(P65_Head_Shoulders_Bear) s += "P65 ";
      if(P66_Head_Shoulders_Bull) s += "P66 ";
      if(P67_Triangle_Ascending) s += "P67 ";
      if(P68_Triangle_Descending) s += "P68 ";
      if(P69_Bull_Flag) s += "P69 ";
      if(P70_Bear_Flag) s += "P70 ";
      // Cat F
      if(P71_Fair_Value_Gap_Bull) s += "P71 ";
      if(P72_Fair_Value_Gap_Bear) s += "P72 ";
      if(P73_Liquidity_Grab_Bull) s += "P73 ";
      if(P74_Liquidity_Grab_Bear) s += "P74 ";
      if(P75_Equal_Highs_Sweep) s += "P75 ";
      if(P76_Equal_Lows_Sweep) s += "P76 ";
      if(P77_Mitigation_Block_Bull) s += "P77 ";
      if(P78_Mitigation_Block_Bear) s += "P78 ";
      if(P79_POC_Bounce_Long) s += "P79 ";
      if(P80_POC_Bounce_Short) s += "P80 ";
      // Cat G
      if(P81_ZScore_MeanRev_Long)  s += "P81 ";
      if(P82_ZScore_MeanRev_Short) s += "P82 ";
      if(P83_ORB_Long)             s += "P83 ";
      if(P84_ORB_Short)            s += "P84 ";
      if(P85_NR4)                  s += "P85 ";
      if(P86_NR7)                  s += "P86 ";
      if(P87_BB_PctB_Extreme_Long) s += "P87 ";
      if(P88_BB_PctB_Extreme_Short)s += "P88 ";
      // Cat H
      if(P89_OTE_Long)        s += "P89 ";
      if(P90_OTE_Short)       s += "P90 ";
      if(P91_LondonKZ_Long)   s += "P91 ";
      if(P92_LondonKZ_Short)  s += "P92 ";
      if(P93_NYSB_Long)       s += "P93 ";
      if(P94_NYSB_Short)      s += "P94 ";
      if(P95_PowerOf3_Long)   s += "P95 ";
      if(P96_PowerOf3_Short)  s += "P96 ";
      if(P97_PD_Array_Premium)s += "P97 ";
      // Cat I
      if(P98_VSA_NoDemand)            s += "P98 ";
      if(P99_VSA_NoSupply)            s += "P99 ";
      if(P100_VSA_StoppingVol_Bull)   s += "P100 ";
      if(P101_VSA_ClimacticVol_Bear)  s += "P101 ";
      if(P102_Wyckoff_Spring)         s += "P102 ";
      if(P103_Wyckoff_Upthrust)       s += "P103 ";
      if(P104_SellingClimax)          s += "P104 ";
      if(P105_BuyingClimax)           s += "P105 ";
      if(P106_CVD_Div_Bull)           s += "P106 ";
      if(P107_CVD_Div_Bear)           s += "P107 ";
      // Cat J
      if(P108_Gartley_Bull)        s += "P108 ";
      if(P109_Gartley_Bear)        s += "P109 ";
      if(P110_Bat_Bull)            s += "P110 ";
      if(P111_Bat_Bear)            s += "P111 ";
      if(P112_Butterfly_Bull)      s += "P112 ";
      if(P113_Butterfly_Bear)      s += "P113 ";
      if(P114_Crab_Bull)           s += "P114 ";
      if(P115_Crab_Bear)           s += "P115 ";
      if(P116_Cypher_Bull)         s += "P116 ";
      if(P117_Cypher_Bear)         s += "P117 ";
      if(P118_Asian_Sweep_Long)    s += "P118 ";
      if(P119_Asian_Sweep_Short)   s += "P119 ";
      if(P120_Sunday_Gap_Fill_Long)s += "P120 ";
      if(P121_Sunday_Gap_Fill_Short) s += "P121 ";
      if(P122_Kicker_Bull)         s += "P122 ";
      if(P123_Kicker_Bear)         s += "P123 ";
      if(P124_ThreeBar_Rev_Bull)   s += "P124 ";
      if(P125_ThreeBar_Rev_Bear)   s += "P125 ";
      // Cat K
      if(P126_HTF_Bias_Long)         s += "P126 ";
      if(P127_HTF_Bias_Short)        s += "P127 ";
      if(P128_MTF_FVG_Aligned_Long)  s += "P128 ";
      if(P129_MTF_FVG_Aligned_Short) s += "P129 ";
      if(P130_MTF_OB_Aligned_Long)   s += "P130 ";
      if(P131_MTF_OB_Aligned_Short)  s += "P131 ";
      if(P132_Daily_Bias_Intraday_Long)  s += "P132 ";
      if(P133_Daily_Bias_Intraday_Short) s += "P133 ";
      if(P134_Triple_TF_Aligned_Long)    s += "P134 ";
      if(P135_Triple_TF_Aligned_Short)   s += "P135 ";
      // Cat L
      if(P136_Ichimoku_TK_Cross_Bull)    s += "P136 ";
      if(P137_Ichimoku_TK_Cross_Bear)    s += "P137 ";
      if(P138_Ichimoku_Cloud_Break_Bull) s += "P138 ";
      if(P139_Ichimoku_Cloud_Break_Bear) s += "P139 ";
      if(P140_Ichimoku_Kumo_Twist_Bull)  s += "P140 ";
      if(P141_Ichimoku_Kumo_Twist_Bear)  s += "P141 ";
      if(P142_Ichimoku_Chikou_Confirm)   s += "P142 ";
      // Cat M
      if(P143_Inducement_Bull)        s += "P143 ";
      if(P144_Inducement_Bear)        s += "P144 ";
      if(P145_Turtle_Soup_Long)       s += "P145 ";
      if(P146_Turtle_Soup_Short)      s += "P146 ";
      if(P147_Stop_Run_Reversal_Bull) s += "P147 ";
      if(P148_Stop_Run_Reversal_Bear) s += "P148 ";
      if(P149_Internal_Liq_Sweep_Long)s += "P149 ";
      if(P150_External_Liq_Sweep_Long)s += "P150 ";
      // Cat N
      if(P151_Pullback_EMA20_Long)        s += "P151 ";
      if(P152_Pullback_EMA20_Short)       s += "P152 ";
      if(P153_Pullback_EMA50_Long)        s += "P153 ";
      if(P154_Pullback_EMA50_Short)       s += "P154 ";
      if(P155_Three_Touch_Trendline_Long) s += "P155 ";
      if(P156_Three_Touch_Trendline_Short)s += "P156 ";
      if(P157_Hidden_Div_Bull_RSI)        s += "P157 ";
      if(P158_Hidden_Div_Bear_RSI)        s += "P158 ";
      if(P159_Hidden_Div_Bull_MACD)       s += "P159 ";
      if(P160_Hidden_Div_Bear_MACD)       s += "P160 ";
      // Cat O
      if(P161_VAH_Reject_Short)       s += "P161 ";
      if(P162_VAL_Reject_Long)        s += "P162 ";
      if(P163_Single_Print_Fill_Long) s += "P163 ";
      if(P164_Single_Print_Fill_Short)s += "P164 ";
      if(P165_POC_Migration_Long)     s += "P165 ";
      // Cat P
      if(P166_Round_Number_Bounce_Long)  s += "P166 ";
      if(P167_Round_Number_Bounce_Short) s += "P167 ";
      if(P168_Daily_Pivot_Tag_Long)      s += "P168 ";
      if(P169_Daily_Pivot_Tag_Short)     s += "P169 ";
      if(P170_Range_Mid_Bounce)          s += "P170 ";
      // Cat Q
      if(P171_ABCD_Bull)         s += "P171 ";
      if(P172_ABCD_Bear)         s += "P172 ";
      if(P173_Three_Drives_Bull) s += "P173 ";
      if(P174_Three_Drives_Bear) s += "P174 ";
      // Cat R
      if(P175_BB_Squeeze_Breakout_Long)  s += "P175 ";
      if(P176_BB_Squeeze_Breakout_Short) s += "P176 ";
      if(P177_ATR_Expansion)             s += "P177 ";

      StringTrimRight(s);
      return s;
   }
};

#endif  // KMP_STRUCTURES_MQH