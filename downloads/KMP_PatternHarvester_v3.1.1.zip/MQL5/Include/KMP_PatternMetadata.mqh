//+------------------------------------------------------------------+
//|                                       KMP_PatternMetadata.mqh   |
//|                                                                  |
//|  Pattern metadata: direction bias, category, name for each       |
//|  of 80 patterns. Used by harvester EA to know how to enter      |
//|  on each pattern.                                                |
//|                                                                  |
//|  Direction bias:                                                 |
//|     1 = Long-biased (e.g., Bullish Engulfing, BOS Bull)         |
//|    -1 = Short-biased                                             |
//|     0 = Direction-agnostic (e.g., Doji, BB Squeeze - test BOTH) |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_PATTERN_METADATA_MQH
#define KMP_PATTERN_METADATA_MQH

#include "KMP_Structures.mqh"

#define TOTAL_PATTERNS 177

//+------------------------------------------------------------------+
//| Pattern info table                                              |
//+------------------------------------------------------------------+
struct PatternMeta
{
   int    id;             // P1, P2, ... P80
   string name;
   string category;       // A, B, C, D, E, F
   int    direction;      // 1=long, -1=short, 0=both
   string theory;         // brief theory ref
};

//+------------------------------------------------------------------+
//| Get pattern metadata array                                      |
//+------------------------------------------------------------------+
class CPatternMeta
{
public:
   static PatternMeta Get(int pattern_id)
   {
      PatternMeta m;
      m.id = pattern_id;
      
      // CATEGORY A — Original (P1-P20)
      switch(pattern_id)
      {
         case 1:  m.name="MultiRej_Long"; m.category="A"; m.direction=1; m.theory="Multi-rejection zone"; return m;
         case 2:  m.name="MultiRej_Short"; m.category="A"; m.direction=-1; m.theory="Multi-rejection zone"; return m;
         case 3:  m.name="WRB_Bull"; m.category="A"; m.direction=1; m.theory="Wide range bull"; return m;
         case 4:  m.name="WRB_Bear"; m.category="A"; m.direction=-1; m.theory="Wide range bear"; return m;
         case 5:  m.name="Engulf_Trap_Bull"; m.category="A"; m.direction=1; m.theory="Engulfing after trap"; return m;
         case 6:  m.name="Engulf_Trap_Bear"; m.category="A"; m.direction=-1; m.theory="Engulfing after trap"; return m;
         case 7:  m.name="PinBar"; m.category="A"; m.direction=0; m.theory="Pin bar at extreme"; return m;
         case 8:  m.name="TwoBar_Reversal"; m.category="A"; m.direction=0; m.theory="Two-bar reversal"; return m;
         case 9:  m.name="BB_Touch_Reversal"; m.category="A"; m.direction=0; m.theory="BB touch + reversal"; return m;
         case 10: m.name="BB_Squeeze_Break"; m.category="A"; m.direction=0; m.theory="BB squeeze breakout"; return m;
         case 11: m.name="EMA_Bounce"; m.category="A"; m.direction=0; m.theory="EMA 50/200 bounce"; return m;
         case 12: m.name="EMA_Cross"; m.category="A"; m.direction=0; m.theory="EMA cross"; return m;
         case 13: m.name="RSI_Extreme_Rev"; m.category="A"; m.direction=0; m.theory="RSI extreme reversal"; return m;
         case 14: m.name="RSI_Divergence"; m.category="A"; m.direction=0; m.theory="RSI divergence"; return m;
         case 15: m.name="MACD_Zero_Cross"; m.category="A"; m.direction=0; m.theory="MACD zero cross"; return m;
         case 16: m.name="Stoch_Cross"; m.category="A"; m.direction=0; m.theory="Stoch cross OB/OS"; return m;
         case 17: m.name="Volume_Spike_Rev"; m.category="A"; m.direction=0; m.theory="Volume spike reversal"; return m;
         case 18: m.name="Pivot_Bounce"; m.category="A"; m.direction=0; m.theory="Pivot bounce"; return m;
         case 19: m.name="Round_Number"; m.category="A"; m.direction=0; m.theory="Round number bounce"; return m;
         case 20: m.name="Inside_Bar_Break"; m.category="A"; m.direction=0; m.theory="Inside bar breakout"; return m;
         
         // CATEGORY B — Candlestick (Nison, Bulkowski)
         case 21: m.name="Doji"; m.category="B"; m.direction=0; m.theory="Nison ch.8 indecision"; return m;
         case 22: m.name="Dragonfly_Doji"; m.category="B"; m.direction=1; m.theory="Nison ch.8 bullish reversal"; return m;
         case 23: m.name="Gravestone_Doji"; m.category="B"; m.direction=-1; m.theory="Nison ch.8 bearish reversal"; return m;
         case 24: m.name="Hammer"; m.category="B"; m.direction=1; m.theory="Nison ch.4"; return m;
         case 25: m.name="Inverted_Hammer"; m.category="B"; m.direction=1; m.theory="Nison ch.5"; return m;
         case 26: m.name="Hanging_Man"; m.category="B"; m.direction=-1; m.theory="Nison ch.4"; return m;
         case 27: m.name="Shooting_Star"; m.category="B"; m.direction=-1; m.theory="Nison ch.5"; return m;
         case 28: m.name="Bullish_Engulfing"; m.category="B"; m.direction=1; m.theory="Nison ch.6"; return m;
         case 29: m.name="Bearish_Engulfing"; m.category="B"; m.direction=-1; m.theory="Nison ch.6"; return m;
         case 30: m.name="Piercing_Line"; m.category="B"; m.direction=1; m.theory="Nison ch.6"; return m;
         case 31: m.name="Dark_Cloud_Cover"; m.category="B"; m.direction=-1; m.theory="Nison ch.6"; return m;
         case 32: m.name="Bullish_Harami"; m.category="B"; m.direction=1; m.theory="Nison ch.6 harami"; return m;
         case 33: m.name="Bearish_Harami"; m.category="B"; m.direction=-1; m.theory="Nison ch.6"; return m;
         case 34: m.name="Morning_Star"; m.category="B"; m.direction=1; m.theory="Nison ch.7"; return m;
         case 35: m.name="Evening_Star"; m.category="B"; m.direction=-1; m.theory="Nison ch.7"; return m;
         case 36: m.name="Three_White_Soldiers"; m.category="B"; m.direction=1; m.theory="Nison ch.7"; return m;
         case 37: m.name="Three_Black_Crows"; m.category="B"; m.direction=-1; m.theory="Nison ch.7"; return m;
         case 38: m.name="Tweezer_Bottom"; m.category="B"; m.direction=1; m.theory="Nison ch.6"; return m;
         case 39: m.name="Tweezer_Top"; m.category="B"; m.direction=-1; m.theory="Nison ch.6"; return m;
         case 40: m.name="Marubozu"; m.category="B"; m.direction=0; m.theory="Nison ch.3 strong continuation"; return m;
         
         // CATEGORY C — S/R & Order Blocks
         case 41: m.name="Supply_Zone_Reject"; m.category="C"; m.direction=-1; m.theory="Seiden Supply"; return m;
         case 42: m.name="Demand_Zone_Reject"; m.category="C"; m.direction=1; m.theory="Seiden Demand"; return m;
         case 43: m.name="Bullish_Order_Block"; m.category="C"; m.direction=1; m.theory="ICT OB"; return m;
         case 44: m.name="Bearish_Order_Block"; m.category="C"; m.direction=-1; m.theory="ICT OB"; return m;
         case 45: m.name="Breaker_Block_Bull"; m.category="C"; m.direction=1; m.theory="ICT Breaker"; return m;
         case 46: m.name="Breaker_Block_Bear"; m.category="C"; m.direction=-1; m.theory="ICT Breaker"; return m;
         case 47: m.name="SR_Flip_Long"; m.category="C"; m.direction=1; m.theory="Edwards & Magee polarity"; return m;
         case 48: m.name="SR_Flip_Short"; m.category="C"; m.direction=-1; m.theory="Edwards & Magee polarity"; return m;
         case 49: m.name="Trendline_Bounce_Long"; m.category="C"; m.direction=1; m.theory="Edwards & Magee TL"; return m;
         case 50: m.name="Trendline_Bounce_Short"; m.category="C"; m.direction=-1; m.theory="Edwards & Magee TL"; return m;
         
         // CATEGORY D — Structure
         case 51: m.name="HHHL"; m.category="D"; m.direction=1; m.theory="Dow Theory bullish"; return m;
         case 52: m.name="LHLL"; m.category="D"; m.direction=-1; m.theory="Dow Theory bearish"; return m;
         case 53: m.name="BOS_Bull"; m.category="D"; m.direction=1; m.theory="ICT BOS"; return m;
         case 54: m.name="BOS_Bear"; m.category="D"; m.direction=-1; m.theory="ICT BOS"; return m;
         case 55: m.name="CHoCH_Bull"; m.category="D"; m.direction=1; m.theory="ICT CHoCH reversal"; return m;
         case 56: m.name="CHoCH_Bear"; m.category="D"; m.direction=-1; m.theory="ICT CHoCH reversal"; return m;
         case 57: m.name="Liq_Sweep_Long"; m.category="D"; m.direction=1; m.theory="ICT sweep"; return m;
         case 58: m.name="Liq_Sweep_Short"; m.category="D"; m.direction=-1; m.theory="ICT sweep"; return m;
         case 59: m.name="Failed_Breakout_Long"; m.category="D"; m.direction=1; m.theory="Brooks failed BO"; return m;
         case 60: m.name="Failed_Breakout_Short"; m.category="D"; m.direction=-1; m.theory="Brooks failed BO"; return m;
         
         // CATEGORY E — Chart Patterns
         case 61: m.name="Double_Bottom"; m.category="E"; m.direction=1; m.theory="E&M ch.6 W-pattern"; return m;
         case 62: m.name="Double_Top"; m.category="E"; m.direction=-1; m.theory="E&M ch.6 M-pattern"; return m;
         case 63: m.name="Triple_Bottom"; m.category="E"; m.direction=1; m.theory="E&M ch.6"; return m;
         case 64: m.name="Triple_Top"; m.category="E"; m.direction=-1; m.theory="E&M ch.6"; return m;
         case 65: m.name="HnS_Bear"; m.category="E"; m.direction=-1; m.theory="E&M ch.6 ~93% reliable"; return m;
         case 66: m.name="HnS_Bull"; m.category="E"; m.direction=1; m.theory="E&M ch.6 inverted"; return m;
         case 67: m.name="Triangle_Asc"; m.category="E"; m.direction=1; m.theory="Bulkowski"; return m;
         case 68: m.name="Triangle_Desc"; m.category="E"; m.direction=-1; m.theory="Bulkowski"; return m;
         case 69: m.name="Bull_Flag"; m.category="E"; m.direction=1; m.theory="E&M ch.7"; return m;
         case 70: m.name="Bear_Flag"; m.category="E"; m.direction=-1; m.theory="E&M ch.7"; return m;
         
         // CATEGORY F — SMC
         case 71: m.name="FVG_Bull"; m.category="F"; m.direction=1; m.theory="ICT FVG"; return m;
         case 72: m.name="FVG_Bear"; m.category="F"; m.direction=-1; m.theory="ICT FVG"; return m;
         case 73: m.name="Liq_Grab_Bull"; m.category="F"; m.direction=1; m.theory="ICT stop hunt"; return m;
         case 74: m.name="Liq_Grab_Bear"; m.category="F"; m.direction=-1; m.theory="ICT stop hunt"; return m;
         case 75: m.name="Equal_Highs_Sweep"; m.category="F"; m.direction=-1; m.theory="ICT EQH"; return m;
         case 76: m.name="Equal_Lows_Sweep"; m.category="F"; m.direction=1; m.theory="ICT EQL"; return m;
         case 77: m.name="Mitigation_Block_Bull"; m.category="F"; m.direction=1; m.theory="ICT mitigation"; return m;
         case 78: m.name="Mitigation_Block_Bear"; m.category="F"; m.direction=-1; m.theory="ICT mitigation"; return m;
         case 79: m.name="POC_Bounce_Long"; m.category="F"; m.direction=1; m.theory="Dalton Markets in Profile"; return m;
         case 80: m.name="POC_Bounce_Short"; m.category="F"; m.direction=-1; m.theory="Dalton Markets in Profile"; return m;

         // CATEGORY G — Statistical Edge (P81-P88)
         case 81: m.name="ZScore_MeanRev_Long"; m.category="G"; m.direction=1; m.theory="QuantConnect Z-score MR"; return m;
         case 82: m.name="ZScore_MeanRev_Short"; m.category="G"; m.direction=-1; m.theory="QuantConnect Z-score MR"; return m;
         case 83: m.name="ORB_Long"; m.category="G"; m.direction=1; m.theory="Concretum ORB 2023"; return m;
         case 84: m.name="ORB_Short"; m.category="G"; m.direction=-1; m.theory="Concretum ORB 2023"; return m;
         case 85: m.name="NR4"; m.category="G"; m.direction=0; m.theory="Crabel NR4"; return m;
         case 86: m.name="NR7"; m.category="G"; m.direction=0; m.theory="Crabel NR7"; return m;
         case 87: m.name="BB_PctB_Long"; m.category="G"; m.direction=1; m.theory="Bollinger %B extreme"; return m;
         case 88: m.name="BB_PctB_Short"; m.category="G"; m.direction=-1; m.theory="Bollinger %B extreme"; return m;

         // CATEGORY H — SMC Advanced (P89-P97)
         case 89: m.name="OTE_Long"; m.category="H"; m.direction=1; m.theory="ICT OTE 62-79% Fib"; return m;
         case 90: m.name="OTE_Short"; m.category="H"; m.direction=-1; m.theory="ICT OTE 62-79% Fib"; return m;
         case 91: m.name="LondonKZ_Long"; m.category="H"; m.direction=1; m.theory="ICT London Killzone"; return m;
         case 92: m.name="LondonKZ_Short"; m.category="H"; m.direction=-1; m.theory="ICT London Killzone"; return m;
         case 93: m.name="NYSB_Long"; m.category="H"; m.direction=1; m.theory="ICT NY Silver Bullet"; return m;
         case 94: m.name="NYSB_Short"; m.category="H"; m.direction=-1; m.theory="ICT NY Silver Bullet"; return m;
         case 95: m.name="PowerOf3_Long"; m.category="H"; m.direction=1; m.theory="ICT AMD"; return m;
         case 96: m.name="PowerOf3_Short"; m.category="H"; m.direction=-1; m.theory="ICT AMD"; return m;
         case 97: m.name="PD_Array_Premium"; m.category="H"; m.direction=-1; m.theory="ICT PD Array"; return m;

         // CATEGORY I — Volume / Wyckoff / VSA (P98-P107)
         case 98:  m.name="VSA_NoDemand"; m.category="I"; m.direction=-1; m.theory="Williams VSA"; return m;
         case 99:  m.name="VSA_NoSupply"; m.category="I"; m.direction=1; m.theory="Williams VSA"; return m;
         case 100: m.name="VSA_StoppingVol_Bull"; m.category="I"; m.direction=1; m.theory="Williams stopping vol"; return m;
         case 101: m.name="VSA_ClimaxVol_Bear"; m.category="I"; m.direction=-1; m.theory="Williams climax"; return m;
         case 102: m.name="Wyckoff_Spring"; m.category="I"; m.direction=1; m.theory="Wyckoff spring"; return m;
         case 103: m.name="Wyckoff_Upthrust"; m.category="I"; m.direction=-1; m.theory="Wyckoff upthrust"; return m;
         case 104: m.name="SellingClimax"; m.category="I"; m.direction=1; m.theory="VSA selling climax"; return m;
         case 105: m.name="BuyingClimax"; m.category="I"; m.direction=-1; m.theory="VSA buying climax"; return m;
         case 106: m.name="CVD_Div_Bull"; m.category="I"; m.direction=1; m.theory="CVD divergence (approx)"; return m;
         case 107: m.name="CVD_Div_Bear"; m.category="I"; m.direction=-1; m.theory="CVD divergence (approx)"; return m;

         // CATEGORY J — Harmonic + Specialized (P108-P125)
         case 108: m.name="Gartley_Bull"; m.category="J"; m.direction=1; m.theory="Carney Gartley"; return m;
         case 109: m.name="Gartley_Bear"; m.category="J"; m.direction=-1; m.theory="Carney Gartley"; return m;
         case 110: m.name="Bat_Bull"; m.category="J"; m.direction=1; m.theory="Carney Bat"; return m;
         case 111: m.name="Bat_Bear"; m.category="J"; m.direction=-1; m.theory="Carney Bat"; return m;
         case 112: m.name="Butterfly_Bull"; m.category="J"; m.direction=1; m.theory="Carney Butterfly"; return m;
         case 113: m.name="Butterfly_Bear"; m.category="J"; m.direction=-1; m.theory="Carney Butterfly"; return m;
         case 114: m.name="Crab_Bull"; m.category="J"; m.direction=1; m.theory="Carney Crab"; return m;
         case 115: m.name="Crab_Bear"; m.category="J"; m.direction=-1; m.theory="Carney Crab"; return m;
         case 116: m.name="Cypher_Bull"; m.category="J"; m.direction=1; m.theory="Carney Cypher"; return m;
         case 117: m.name="Cypher_Bear"; m.category="J"; m.direction=-1; m.theory="Carney Cypher"; return m;
         case 118: m.name="Asian_Sweep_Long"; m.category="J"; m.direction=1; m.theory="Williams session sweep"; return m;
         case 119: m.name="Asian_Sweep_Short"; m.category="J"; m.direction=-1; m.theory="Williams session sweep"; return m;
         case 120: m.name="Sunday_Gap_Fill_Long"; m.category="J"; m.direction=1; m.theory="Weekend gap fill"; return m;
         case 121: m.name="Sunday_Gap_Fill_Short"; m.category="J"; m.direction=-1; m.theory="Weekend gap fill"; return m;
         case 122: m.name="Kicker_Bull"; m.category="J"; m.direction=1; m.theory="Bulkowski kicker ~78%"; return m;
         case 123: m.name="Kicker_Bear"; m.category="J"; m.direction=-1; m.theory="Bulkowski kicker"; return m;
         case 124: m.name="ThreeBar_Rev_Bull"; m.category="J"; m.direction=1; m.theory="Brooks 3-bar rev"; return m;
         case 125: m.name="ThreeBar_Rev_Bear"; m.category="J"; m.direction=-1; m.theory="Brooks 3-bar rev"; return m;
         // Cat K — Multi-TF Confluence
         case 126: m.name="HTF_Bias_Long"; m.category="K"; m.direction=1; m.theory="ICT MTF bias"; return m;
         case 127: m.name="HTF_Bias_Short"; m.category="K"; m.direction=-1; m.theory="ICT MTF bias"; return m;
         case 128: m.name="MTF_FVG_Aligned_Long"; m.category="K"; m.direction=1; m.theory="ICT MTF FVG"; return m;
         case 129: m.name="MTF_FVG_Aligned_Short"; m.category="K"; m.direction=-1; m.theory="ICT MTF FVG"; return m;
         case 130: m.name="MTF_OB_Aligned_Long"; m.category="K"; m.direction=1; m.theory="ICT MTF OB"; return m;
         case 131: m.name="MTF_OB_Aligned_Short"; m.category="K"; m.direction=-1; m.theory="ICT MTF OB"; return m;
         case 132: m.name="Daily_Bias_Intraday_Long"; m.category="K"; m.direction=1; m.theory="L.Williams long-term bias"; return m;
         case 133: m.name="Daily_Bias_Intraday_Short"; m.category="K"; m.direction=-1; m.theory="L.Williams long-term bias"; return m;
         case 134: m.name="Triple_TF_Aligned_Long"; m.category="K"; m.direction=1; m.theory="D1+H4+H1 stack"; return m;
         case 135: m.name="Triple_TF_Aligned_Short"; m.category="K"; m.direction=-1; m.theory="D1+H4+H1 stack"; return m;
         // Cat L — Ichimoku
         case 136: m.name="Ichimoku_TK_Cross_Bull"; m.category="L"; m.direction=1; m.theory="Hosoda 1968 TK cross"; return m;
         case 137: m.name="Ichimoku_TK_Cross_Bear"; m.category="L"; m.direction=-1; m.theory="Hosoda 1968 TK cross"; return m;
         case 138: m.name="Ichimoku_Cloud_Break_Bull"; m.category="L"; m.direction=1; m.theory="Kumo breakout"; return m;
         case 139: m.name="Ichimoku_Cloud_Break_Bear"; m.category="L"; m.direction=-1; m.theory="Kumo breakout"; return m;
         case 140: m.name="Ichimoku_Kumo_Twist_Bull"; m.category="L"; m.direction=1; m.theory="Future cloud flip"; return m;
         case 141: m.name="Ichimoku_Kumo_Twist_Bear"; m.category="L"; m.direction=-1; m.theory="Future cloud flip"; return m;
         case 142: m.name="Ichimoku_Chikou_Confirm"; m.category="L"; m.direction=0; m.theory="Chikou clear space"; return m;
         // Cat M — Modern SMC
         case 143: m.name="Inducement_Bull"; m.category="M"; m.direction=1; m.theory="ICT IFC fake-low reject"; return m;
         case 144: m.name="Inducement_Bear"; m.category="M"; m.direction=-1; m.theory="ICT IFC fake-high reject"; return m;
         case 145: m.name="Turtle_Soup_Long"; m.category="M"; m.direction=1; m.theory="L.Williams 20-day failure"; return m;
         case 146: m.name="Turtle_Soup_Short"; m.category="M"; m.direction=-1; m.theory="L.Williams 20-day failure"; return m;
         case 147: m.name="Stop_Run_Reversal_Bull"; m.category="M"; m.direction=1; m.theory="Aggressor flip + vol"; return m;
         case 148: m.name="Stop_Run_Reversal_Bear"; m.category="M"; m.direction=-1; m.theory="Aggressor flip + vol"; return m;
         case 149: m.name="Internal_Liq_Sweep_Long"; m.category="M"; m.direction=1; m.theory="ICT internal liquidity"; return m;
         case 150: m.name="External_Liq_Sweep_Long"; m.category="M"; m.direction=1; m.theory="ICT external liquidity"; return m;
         // Cat N — Momentum + Hidden Div
         case 151: m.name="Pullback_EMA20_Long"; m.category="N"; m.direction=1; m.theory="Brooks pullback to MA"; return m;
         case 152: m.name="Pullback_EMA20_Short"; m.category="N"; m.direction=-1; m.theory="Brooks pullback to MA"; return m;
         case 153: m.name="Pullback_EMA50_Long"; m.category="N"; m.direction=1; m.theory="Deeper pullback to MA"; return m;
         case 154: m.name="Pullback_EMA50_Short"; m.category="N"; m.direction=-1; m.theory="Deeper pullback to MA"; return m;
         case 155: m.name="Three_Touch_Trendline_Long"; m.category="N"; m.direction=1; m.theory="Bulkowski 3rd touch"; return m;
         case 156: m.name="Three_Touch_Trendline_Short"; m.category="N"; m.direction=-1; m.theory="Bulkowski 3rd touch"; return m;
         case 157: m.name="Hidden_Div_Bull_RSI"; m.category="N"; m.direction=1; m.theory="C.Brown hidden div"; return m;
         case 158: m.name="Hidden_Div_Bear_RSI"; m.category="N"; m.direction=-1; m.theory="C.Brown hidden div"; return m;
         case 159: m.name="Hidden_Div_Bull_MACD"; m.category="N"; m.direction=1; m.theory="C.Brown hidden div"; return m;
         case 160: m.name="Hidden_Div_Bear_MACD"; m.category="N"; m.direction=-1; m.theory="C.Brown hidden div"; return m;
         // Cat O — Volume Profile
         case 161: m.name="VAH_Reject_Short"; m.category="O"; m.direction=-1; m.theory="Steidlmayer Value Area"; return m;
         case 162: m.name="VAL_Reject_Long"; m.category="O"; m.direction=1; m.theory="Steidlmayer Value Area"; return m;
         case 163: m.name="Single_Print_Fill_Long"; m.category="O"; m.direction=1; m.theory="Low-vol gap fill"; return m;
         case 164: m.name="Single_Print_Fill_Short"; m.category="O"; m.direction=-1; m.theory="Low-vol gap fill"; return m;
         case 165: m.name="POC_Migration_Long"; m.category="O"; m.direction=1; m.theory="POC trend acceptance"; return m;
         // Cat P — Range / Reversion
         case 166: m.name="Round_Number_Bounce_Long"; m.category="P"; m.direction=1; m.theory="Lefevre round-number psych"; return m;
         case 167: m.name="Round_Number_Bounce_Short"; m.category="P"; m.direction=-1; m.theory="Lefevre round-number psych"; return m;
         case 168: m.name="Daily_Pivot_Tag_Long"; m.category="P"; m.direction=1; m.theory="Murphy classical pivot"; return m;
         case 169: m.name="Daily_Pivot_Tag_Short"; m.category="P"; m.direction=-1; m.theory="Murphy classical pivot"; return m;
         case 170: m.name="Range_Mid_Bounce"; m.category="P"; m.direction=0; m.theory="50% range pivot"; return m;
         // Cat Q — ABCD / Three Drives
         case 171: m.name="ABCD_Bull"; m.category="Q"; m.direction=1; m.theory="Carney ABCD harmonic light"; return m;
         case 172: m.name="ABCD_Bear"; m.category="Q"; m.direction=-1; m.theory="Carney ABCD harmonic light"; return m;
         case 173: m.name="Three_Drives_Bull"; m.category="Q"; m.direction=1; m.theory="Connors Three Drives"; return m;
         case 174: m.name="Three_Drives_Bear"; m.category="Q"; m.direction=-1; m.theory="Connors Three Drives"; return m;
         // Cat R — Vol Regime
         case 175: m.name="BB_Squeeze_Breakout_Long"; m.category="R"; m.direction=1; m.theory="Bollinger squeeze cycle"; return m;
         case 176: m.name="BB_Squeeze_Breakout_Short"; m.category="R"; m.direction=-1; m.theory="Bollinger squeeze cycle"; return m;
         case 177: m.name="ATR_Expansion"; m.category="R"; m.direction=0; m.theory="Crabel volatility cycle"; return m;
      }
      
      // Unknown
      m.name = "UNKNOWN"; m.category = "?"; m.direction = 0; m.theory = "";
      return m;
   }
   
   //+---------------------------------------------------------------+
   //| Check if specific pattern fired                              |
   //+---------------------------------------------------------------+
   static bool IsFired(int pattern_id, const PatternFlags &f)
   {
      switch(pattern_id)
      {
         case 1:  return f.P1_MultiRej_Long;
         case 2:  return f.P2_MultiRej_Short;
         case 3:  return f.P3_WRB_Bull;
         case 4:  return f.P4_WRB_Bear;
         case 5:  return f.P5_Engulf_Trap_Bull;
         case 6:  return f.P6_Engulf_Trap_Bear;
         case 7:  return f.P7_PinBar;
         case 8:  return f.P8_TwoBar_Reversal;
         case 9:  return f.P9_BB_Touch_Reversal;
         case 10: return f.P10_BB_Squeeze_Break;
         case 11: return f.P11_EMA_Bounce;
         case 12: return f.P12_EMA_Cross;
         case 13: return f.P13_RSI_Extreme_Rev;
         case 14: return f.P14_RSI_Divergence;
         case 15: return f.P15_MACD_Zero_Cross;
         case 16: return f.P16_Stoch_Cross;
         case 17: return f.P17_Volume_Spike_Rev;
         case 18: return f.P18_Pivot_Bounce;
         case 19: return f.P19_Round_Number;
         case 20: return f.P20_Inside_Bar_Break;
         case 21: return f.P21_Doji;
         case 22: return f.P22_Dragonfly_Doji;
         case 23: return f.P23_Gravestone_Doji;
         case 24: return f.P24_Hammer;
         case 25: return f.P25_Inverted_Hammer;
         case 26: return f.P26_Hanging_Man;
         case 27: return f.P27_Shooting_Star;
         case 28: return f.P28_Bullish_Engulfing;
         case 29: return f.P29_Bearish_Engulfing;
         case 30: return f.P30_Piercing_Line;
         case 31: return f.P31_Dark_Cloud_Cover;
         case 32: return f.P32_Bullish_Harami;
         case 33: return f.P33_Bearish_Harami;
         case 34: return f.P34_Morning_Star;
         case 35: return f.P35_Evening_Star;
         case 36: return f.P36_Three_White_Soldiers;
         case 37: return f.P37_Three_Black_Crows;
         case 38: return f.P38_Tweezer_Bottom;
         case 39: return f.P39_Tweezer_Top;
         case 40: return f.P40_Marubozu;
         case 41: return f.P41_Supply_Zone_Reject;
         case 42: return f.P42_Demand_Zone_Reject;
         case 43: return f.P43_Bullish_Order_Block;
         case 44: return f.P44_Bearish_Order_Block;
         case 45: return f.P45_Breaker_Block_Bull;
         case 46: return f.P46_Breaker_Block_Bear;
         case 47: return f.P47_SR_Flip_Long;
         case 48: return f.P48_SR_Flip_Short;
         case 49: return f.P49_Trendline_Bounce_Long;
         case 50: return f.P50_Trendline_Bounce_Short;
         case 51: return f.P51_Higher_High_Higher_Low;
         case 52: return f.P52_Lower_High_Lower_Low;
         case 53: return f.P53_Break_Of_Structure_Bull;
         case 54: return f.P54_Break_Of_Structure_Bear;
         case 55: return f.P55_Change_Of_Character_Bull;
         case 56: return f.P56_Change_Of_Character_Bear;
         case 57: return f.P57_Liquidity_Sweep_Long;
         case 58: return f.P58_Liquidity_Sweep_Short;
         case 59: return f.P59_Failed_Breakout_Long;
         case 60: return f.P60_Failed_Breakout_Short;
         case 61: return f.P61_Double_Bottom;
         case 62: return f.P62_Double_Top;
         case 63: return f.P63_Triple_Bottom;
         case 64: return f.P64_Triple_Top;
         case 65: return f.P65_Head_Shoulders_Bear;
         case 66: return f.P66_Head_Shoulders_Bull;
         case 67: return f.P67_Triangle_Ascending;
         case 68: return f.P68_Triangle_Descending;
         case 69: return f.P69_Bull_Flag;
         case 70: return f.P70_Bear_Flag;
         case 71: return f.P71_Fair_Value_Gap_Bull;
         case 72: return f.P72_Fair_Value_Gap_Bear;
         case 73: return f.P73_Liquidity_Grab_Bull;
         case 74: return f.P74_Liquidity_Grab_Bear;
         case 75: return f.P75_Equal_Highs_Sweep;
         case 76: return f.P76_Equal_Lows_Sweep;
         case 77: return f.P77_Mitigation_Block_Bull;
         case 78: return f.P78_Mitigation_Block_Bear;
         case 79: return f.P79_POC_Bounce_Long;
         case 80: return f.P80_POC_Bounce_Short;
         // Cat G
         case 81: return f.P81_ZScore_MeanRev_Long;
         case 82: return f.P82_ZScore_MeanRev_Short;
         case 83: return f.P83_ORB_Long;
         case 84: return f.P84_ORB_Short;
         case 85: return f.P85_NR4;
         case 86: return f.P86_NR7;
         case 87: return f.P87_BB_PctB_Extreme_Long;
         case 88: return f.P88_BB_PctB_Extreme_Short;
         // Cat H
         case 89: return f.P89_OTE_Long;
         case 90: return f.P90_OTE_Short;
         case 91: return f.P91_LondonKZ_Long;
         case 92: return f.P92_LondonKZ_Short;
         case 93: return f.P93_NYSB_Long;
         case 94: return f.P94_NYSB_Short;
         case 95: return f.P95_PowerOf3_Long;
         case 96: return f.P96_PowerOf3_Short;
         case 97: return f.P97_PD_Array_Premium;
         // Cat I
         case 98:  return f.P98_VSA_NoDemand;
         case 99:  return f.P99_VSA_NoSupply;
         case 100: return f.P100_VSA_StoppingVol_Bull;
         case 101: return f.P101_VSA_ClimacticVol_Bear;
         case 102: return f.P102_Wyckoff_Spring;
         case 103: return f.P103_Wyckoff_Upthrust;
         case 104: return f.P104_SellingClimax;
         case 105: return f.P105_BuyingClimax;
         case 106: return f.P106_CVD_Div_Bull;
         case 107: return f.P107_CVD_Div_Bear;
         // Cat J
         case 108: return f.P108_Gartley_Bull;
         case 109: return f.P109_Gartley_Bear;
         case 110: return f.P110_Bat_Bull;
         case 111: return f.P111_Bat_Bear;
         case 112: return f.P112_Butterfly_Bull;
         case 113: return f.P113_Butterfly_Bear;
         case 114: return f.P114_Crab_Bull;
         case 115: return f.P115_Crab_Bear;
         case 116: return f.P116_Cypher_Bull;
         case 117: return f.P117_Cypher_Bear;
         case 118: return f.P118_Asian_Sweep_Long;
         case 119: return f.P119_Asian_Sweep_Short;
         case 120: return f.P120_Sunday_Gap_Fill_Long;
         case 121: return f.P121_Sunday_Gap_Fill_Short;
         case 122: return f.P122_Kicker_Bull;
         case 123: return f.P123_Kicker_Bear;
         case 124: return f.P124_ThreeBar_Rev_Bull;
         case 125: return f.P125_ThreeBar_Rev_Bear;
         // Cat K
         case 126: return f.P126_HTF_Bias_Long;
         case 127: return f.P127_HTF_Bias_Short;
         case 128: return f.P128_MTF_FVG_Aligned_Long;
         case 129: return f.P129_MTF_FVG_Aligned_Short;
         case 130: return f.P130_MTF_OB_Aligned_Long;
         case 131: return f.P131_MTF_OB_Aligned_Short;
         case 132: return f.P132_Daily_Bias_Intraday_Long;
         case 133: return f.P133_Daily_Bias_Intraday_Short;
         case 134: return f.P134_Triple_TF_Aligned_Long;
         case 135: return f.P135_Triple_TF_Aligned_Short;
         // Cat L
         case 136: return f.P136_Ichimoku_TK_Cross_Bull;
         case 137: return f.P137_Ichimoku_TK_Cross_Bear;
         case 138: return f.P138_Ichimoku_Cloud_Break_Bull;
         case 139: return f.P139_Ichimoku_Cloud_Break_Bear;
         case 140: return f.P140_Ichimoku_Kumo_Twist_Bull;
         case 141: return f.P141_Ichimoku_Kumo_Twist_Bear;
         case 142: return f.P142_Ichimoku_Chikou_Confirm;
         // Cat M
         case 143: return f.P143_Inducement_Bull;
         case 144: return f.P144_Inducement_Bear;
         case 145: return f.P145_Turtle_Soup_Long;
         case 146: return f.P146_Turtle_Soup_Short;
         case 147: return f.P147_Stop_Run_Reversal_Bull;
         case 148: return f.P148_Stop_Run_Reversal_Bear;
         case 149: return f.P149_Internal_Liq_Sweep_Long;
         case 150: return f.P150_External_Liq_Sweep_Long;
         // Cat N
         case 151: return f.P151_Pullback_EMA20_Long;
         case 152: return f.P152_Pullback_EMA20_Short;
         case 153: return f.P153_Pullback_EMA50_Long;
         case 154: return f.P154_Pullback_EMA50_Short;
         case 155: return f.P155_Three_Touch_Trendline_Long;
         case 156: return f.P156_Three_Touch_Trendline_Short;
         case 157: return f.P157_Hidden_Div_Bull_RSI;
         case 158: return f.P158_Hidden_Div_Bear_RSI;
         case 159: return f.P159_Hidden_Div_Bull_MACD;
         case 160: return f.P160_Hidden_Div_Bear_MACD;
         // Cat O
         case 161: return f.P161_VAH_Reject_Short;
         case 162: return f.P162_VAL_Reject_Long;
         case 163: return f.P163_Single_Print_Fill_Long;
         case 164: return f.P164_Single_Print_Fill_Short;
         case 165: return f.P165_POC_Migration_Long;
         // Cat P
         case 166: return f.P166_Round_Number_Bounce_Long;
         case 167: return f.P167_Round_Number_Bounce_Short;
         case 168: return f.P168_Daily_Pivot_Tag_Long;
         case 169: return f.P169_Daily_Pivot_Tag_Short;
         case 170: return f.P170_Range_Mid_Bounce;
         // Cat Q
         case 171: return f.P171_ABCD_Bull;
         case 172: return f.P172_ABCD_Bear;
         case 173: return f.P173_Three_Drives_Bull;
         case 174: return f.P174_Three_Drives_Bear;
         // Cat R
         case 175: return f.P175_BB_Squeeze_Breakout_Long;
         case 176: return f.P176_BB_Squeeze_Breakout_Short;
         case 177: return f.P177_ATR_Expansion;
      }
      return false;
   }
};

#endif  // KMP_PATTERN_METADATA_MQH