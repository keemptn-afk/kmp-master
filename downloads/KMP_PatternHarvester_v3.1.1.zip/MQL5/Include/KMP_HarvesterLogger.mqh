//+------------------------------------------------------------------+
//|                                  KMP_HarvesterLogger.mqh        |
//|                                                                  |
//|  DETAILED LOGGER for Pattern Harvester EA                       |
//|                                                                  |
//|  Saves comprehensive data per trade:                             |
//|    - Pattern info (single pattern triggered)                     |
//|    - Bar anatomy (OHLC, body, wicks)                            |
//|    - Entry quality (where in bar entry happened)                 |
//|    - Path tracking (price at multiple time intervals)            |
//|    - MFE/MAE in dollars and ATR                                  |
//|    - Optimal SL/TP suggestion                                    |
//|    - Indicator snapshot                                          |
//+------------------------------------------------------------------+
#property copyright "Keem & Claude - 2026"

#ifndef KMP_HARVESTER_LOGGER_MQH
#define KMP_HARVESTER_LOGGER_MQH

#include "KMP_Structures.mqh"
#include "KMP_PatternMetadata.mqh"

//+------------------------------------------------------------------+
//| Path snapshot — price at specific time after entry              |
//+------------------------------------------------------------------+
struct PathSnapshot
{
   int    hour_offset;     // 1, 6, 12, 24, 48, 72, 120, 168, 240
   double price;
   double pnl_atr;         // PnL in ATR units (favorable for direction)
   bool   captured;
   
   void Reset() { hour_offset = 0; price = 0; pnl_atr = 0; captured = false; }
};

//+------------------------------------------------------------------+
//| Detailed trade record                                           |
//+------------------------------------------------------------------+
struct HarvestRecord
{
   // === IDENTIFICATION ===
   ulong              ticket;
   int                pattern_id;       // 1-80
   string             pattern_name;
   string             pattern_category; // A-F
   int                pattern_direction; // expected: 1, -1, 0
   int                trade_direction;  // actual: 1 or -1
   string             symbol;
   ENUM_TIMEFRAMES    timeframe;
   datetime           open_time;
   datetime           close_time;
   datetime           expire_time;
   
   // === BAR ANATOMY (signal bar) ===
   double             bar_open;
   double             bar_high;
   double             bar_low;
   double             bar_close;
   double             bar_body;
   double             bar_upper_wick;
   double             bar_lower_wick;
   double             bar_range;
   
   // === ENTRY QUALITY ===
   double             entry_price;            // ACTUAL fill price from broker (set in OnTradeTransaction DEAL_ENTRY_IN)
   double             intended_entry_price;   // Price at order request time (before broker fill)
   int                spread_at_entry_pts;    // Spread in points at order open time
   int                spread_at_exit_pts;     // Spread in points at close time
   double             entry_vs_body_pct;      // 0% = bottom of body, 100% = top
   double             entry_vs_range_pct;     // 0% = bar low, 100% = bar high
   double             entry_distance_from_high_atr;  // distance from bar high in ATR
   double             entry_distance_from_low_atr;
   string             entry_quality;           // "AT_LOW", "AT_HIGH", "MIDDLE"
   
   // === PATH TRACKING ===
   PathSnapshot       path_1h;
   PathSnapshot       path_6h;
   PathSnapshot       path_12h;
   PathSnapshot       path_24h;
   PathSnapshot       path_48h;
   PathSnapshot       path_72h;
   PathSnapshot       path_120h;   // Phase 3: extended tracking
   PathSnapshot       path_168h;   // 7 days
   PathSnapshot       path_240h;   // 10 days = 2 trading weeks
   
   // === MFE / MAE ===
   double             max_favorable;
   double             max_adverse;
   double             max_favorable_atr;
   double             max_adverse_atr;
   datetime           mfe_time;
   datetime           mae_time;
   int                hours_to_mfe;
   int                hours_to_mae;
   
   // === EXIT ===
   double             exit_price;
   double             pnl_dollars;
   double             pnl_atr;
   string             exit_reason;
   int                hours_held;
   bool               direction_correct;     // did pnl > 0?
   
   // === OPTIMAL EXIT ANALYSIS ===
   double             pnl_at_1h;
   double             pnl_at_6h;
   double             pnl_at_12h;
   double             pnl_at_24h;
   double             pnl_at_48h;
   double             pnl_at_72h;
   
   // === SL/TP ANALYSIS ===
   bool               sl_05_hit;            // would SL @ 0.5×ATR have been hit?
   bool               sl_10_hit;            // SL @ 1×ATR
   bool               sl_20_hit;            // SL @ 2×ATR
   bool               sl_30_hit;            // SL @ 3×ATR
   bool               tp_10_hit;            // TP @ 1×ATR
   bool               tp_20_hit;            // TP @ 2×ATR
   bool               tp_30_hit;            // TP @ 3×ATR
   bool               tp_50_hit;            // TP @ 5×ATR
   datetime           tp_10_time;           // when TP 1×ATR was first hit
   datetime           tp_20_time;
   datetime           tp_30_time;
   datetime           tp_50_time;
   
   // === LOT / RISK ===
   double             lot;
   double             entry_balance;
   double             entry_atr;
   
   // === INDICATORS AT ENTRY ===
   IndicatorSnapshot  indicators;
   
   // === ALL PATTERN FLAGS ===
   PatternFlags       all_patterns;          // all 80 patterns at entry bar
   
   bool               active;
};

//+------------------------------------------------------------------+
//| Harvester Logger Class                                          |
//+------------------------------------------------------------------+
class CHarvesterLogger
{
private:
   int    m_handle;
   string m_filename;
   bool   m_header_written;
   
public:
   CHarvesterLogger() : m_handle(INVALID_HANDLE), m_filename(""), m_header_written(false) {}
   
   bool Open(string filename)
   {
      m_filename = filename;
      m_handle = FileOpen(filename, FILE_WRITE | FILE_CSV | FILE_ANSI | FILE_COMMON, ',');
      if(m_handle == INVALID_HANDLE)
      {
         Print("ERROR: Cannot open log file: ", filename, " err=", GetLastError());
         return false;
      }
      WriteHeader();
      return true;
   }
   
   void Close()
   {
      if(m_handle != INVALID_HANDLE)
      {
         FileClose(m_handle);
         m_handle = INVALID_HANDLE;
      }
   }
   
   //+---------------------------------------------------------------+
   //| Write CSV header                                              |
   //+---------------------------------------------------------------+
   void WriteHeader()
   {
      if(m_handle == INVALID_HANDLE) return;
      if(m_header_written) return;
      
      string h = "";
      // Identification
      h += "ticket,pattern_id,pattern_name,pattern_cat,pattern_dir_expected,trade_dir,";
      h += "symbol,tf,open_time,close_time,";
      // Bar anatomy
      h += "bar_open,bar_high,bar_low,bar_close,bar_body,bar_upper_wick,bar_lower_wick,bar_range,";
      // Entry quality + execution metadata (NEW: spread/slippage)
      h += "entry_price,intended_entry_price,spread_at_entry_pts,spread_at_exit_pts,";
      h += "entry_vs_body_pct,entry_vs_range_pct,";
      h += "entry_dist_from_high_atr,entry_dist_from_low_atr,entry_quality,";
      // Path tracking
      h += "path_1h_pnl_atr,path_6h_pnl_atr,path_12h_pnl_atr,";
      h += "path_24h_pnl_atr,path_48h_pnl_atr,path_72h_pnl_atr,";
      h += "path_120h_pnl_atr,path_168h_pnl_atr,path_240h_pnl_atr,";
      // MFE/MAE
      h += "mfe_atr,mae_atr,hours_to_mfe,hours_to_mae,";
      // Exit
      h += "exit_price,pnl_dollars,pnl_atr,exit_reason,hours_held,direction_correct,";
      // SL/TP analysis
      h += "sl_05x_hit,sl_10x_hit,sl_20x_hit,sl_30x_hit,";
      h += "tp_10x_hit,tp_20x_hit,tp_30x_hit,tp_50x_hit,";
      h += "hours_to_tp10,hours_to_tp20,hours_to_tp30,hours_to_tp50,";
      // Lot/risk
      h += "lot,entry_balance,entry_atr,";
      // Indicators
      h += "ema9,ema20,ema50,ema200,ema_align,";
      h += "bb_upper,bb_mid,bb_lower,bb_width,bb_pos,";
      h += "atr14,atr50,vol_regime,trend_regime,";
      h += "rsi14,stoch_k,stoch_d,macd_main,macd_signal,";
      h += "tick_vol,vol_ratio,vol_spike,";
      h += "adx,di_plus,di_minus,session,hour,dow,";
      // Pattern flags (top-level summary only, full list in separate column)
      h += "patterns_total,patterns_long_score,patterns_short_score,patterns_list";
      h += "\n";
      
      FileWriteString(m_handle, h);
      FileFlush(m_handle);
      m_header_written = true;
   }
   
   //+---------------------------------------------------------------+
   //| Write a complete record                                       |
   //+---------------------------------------------------------------+
   void WriteRecord(const HarvestRecord &r)
   {
      if(m_handle == INVALID_HANDLE) return;
      
      string s = "";
      // Identification
      s += IntegerToString(r.ticket) + ",";
      s += IntegerToString(r.pattern_id) + ",";
      s += r.pattern_name + ",";
      s += r.pattern_category + ",";
      s += IntegerToString(r.pattern_direction) + ",";
      s += IntegerToString(r.trade_direction) + ",";
      s += r.symbol + ",";
      s += EnumToString(r.timeframe) + ",";
      s += TimeToString(r.open_time, TIME_DATE | TIME_MINUTES) + ",";
      s += TimeToString(r.close_time, TIME_DATE | TIME_MINUTES) + ",";
      
      // Bar anatomy
      s += DoubleToString(r.bar_open, 5) + ",";
      s += DoubleToString(r.bar_high, 5) + ",";
      s += DoubleToString(r.bar_low, 5) + ",";
      s += DoubleToString(r.bar_close, 5) + ",";
      s += DoubleToString(r.bar_body, 5) + ",";
      s += DoubleToString(r.bar_upper_wick, 5) + ",";
      s += DoubleToString(r.bar_lower_wick, 5) + ",";
      s += DoubleToString(r.bar_range, 5) + ",";
      
      // Entry quality + execution metadata
      s += DoubleToString(r.entry_price, 5) + ",";
      s += DoubleToString(r.intended_entry_price, 5) + ",";
      s += IntegerToString(r.spread_at_entry_pts) + ",";
      s += IntegerToString(r.spread_at_exit_pts) + ",";
      s += DoubleToString(r.entry_vs_body_pct, 1) + ",";
      s += DoubleToString(r.entry_vs_range_pct, 1) + ",";
      s += DoubleToString(r.entry_distance_from_high_atr, 3) + ",";
      s += DoubleToString(r.entry_distance_from_low_atr, 3) + ",";
      s += r.entry_quality + ",";
      
      // Path tracking
      s += DoubleToString(r.path_1h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_6h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_12h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_24h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_48h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_72h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_120h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_168h.pnl_atr, 3) + ",";
      s += DoubleToString(r.path_240h.pnl_atr, 3) + ",";
      
      // MFE/MAE
      s += DoubleToString(r.max_favorable_atr, 3) + ",";
      s += DoubleToString(r.max_adverse_atr, 3) + ",";
      s += IntegerToString(r.hours_to_mfe) + ",";
      s += IntegerToString(r.hours_to_mae) + ",";
      
      // Exit
      s += DoubleToString(r.exit_price, 5) + ",";
      s += DoubleToString(r.pnl_dollars, 2) + ",";
      s += DoubleToString(r.pnl_atr, 3) + ",";
      s += r.exit_reason + ",";
      s += IntegerToString(r.hours_held) + ",";
      s += (r.direction_correct ? "YES," : "NO,");
      
      // SL/TP
      s += (r.sl_05_hit ? "1," : "0,");
      s += (r.sl_10_hit ? "1," : "0,");
      s += (r.sl_20_hit ? "1," : "0,");
      s += (r.sl_30_hit ? "1," : "0,");
      s += (r.tp_10_hit ? "1," : "0,");
      s += (r.tp_20_hit ? "1," : "0,");
      s += (r.tp_30_hit ? "1," : "0,");
      s += (r.tp_50_hit ? "1," : "0,");
      
      // Hours to TP
      if(r.tp_10_hit) s += IntegerToString((int)((r.tp_10_time - r.open_time) / 3600)) + ",";
      else s += ",";
      if(r.tp_20_hit) s += IntegerToString((int)((r.tp_20_time - r.open_time) / 3600)) + ",";
      else s += ",";
      if(r.tp_30_hit) s += IntegerToString((int)((r.tp_30_time - r.open_time) / 3600)) + ",";
      else s += ",";
      if(r.tp_50_hit) s += IntegerToString((int)((r.tp_50_time - r.open_time) / 3600)) + ",";
      else s += ",";
      
      // Lot/risk
      s += DoubleToString(r.lot, 2) + ",";
      s += DoubleToString(r.entry_balance, 2) + ",";
      s += DoubleToString(r.entry_atr, 5) + ",";
      
      // Indicators
      s += DoubleToString(r.indicators.ema_9, 5) + ",";
      s += DoubleToString(r.indicators.ema_20, 5) + ",";
      s += DoubleToString(r.indicators.ema_50, 5) + ",";
      s += DoubleToString(r.indicators.ema_200, 5) + ",";
      s += r.indicators.ema_alignment + ",";
      s += DoubleToString(r.indicators.bb_upper, 5) + ",";
      s += DoubleToString(r.indicators.bb_middle, 5) + ",";
      s += DoubleToString(r.indicators.bb_lower, 5) + ",";
      s += DoubleToString(r.indicators.bb_width_ratio, 3) + ",";
      s += DoubleToString(r.indicators.bb_position_pct, 1) + ",";
      s += DoubleToString(r.indicators.atr_14, 5) + ",";
      s += DoubleToString(r.indicators.atr_50, 5) + ",";
      s += r.indicators.volatility_regime + ",";
      s += r.indicators.trend_regime + ",";
      s += DoubleToString(r.indicators.rsi_14, 1) + ",";
      s += DoubleToString(r.indicators.stoch_k, 1) + ",";
      s += DoubleToString(r.indicators.stoch_d, 1) + ",";
      s += DoubleToString(r.indicators.macd_main, 5) + ",";
      s += DoubleToString(r.indicators.macd_signal, 5) + ",";
      s += IntegerToString((int)r.indicators.tick_volume) + ",";
      s += DoubleToString(r.indicators.volume_ratio, 2) + ",";
      s += (r.indicators.volume_spike ? "1," : "0,");
      s += DoubleToString(r.indicators.adx, 1) + ",";
      s += DoubleToString(r.indicators.di_plus, 1) + ",";
      s += DoubleToString(r.indicators.di_minus, 1) + ",";
      s += r.indicators.session + ",";
      s += IntegerToString(r.indicators.hour_of_day) + ",";
      s += IntegerToString(r.indicators.day_of_week) + ",";
      
      // All patterns
      int long_score = 0, short_score = 0;
      ComputeScores(r.all_patterns, long_score, short_score);
      s += IntegerToString(r.all_patterns.total_count) + ",";
      s += IntegerToString(long_score) + ",";
      s += IntegerToString(short_score) + ",";
      s += "\"" + r.all_patterns.ToCSVList() + "\"";
      
      s += "\n";
      
      FileWriteString(m_handle, s);
      FileFlush(m_handle);
   }
   
   void ComputeScores(const PatternFlags &f, int &long_score, int &short_score)
   {
      long_score = 0; short_score = 0;
      for(int i = 1; i <= TOTAL_PATTERNS; i++)
      {
         if(CPatternMeta::IsFired(i, f))
         {
            PatternMeta m = CPatternMeta::Get(i);
            if(m.direction == 1) long_score++;
            else if(m.direction == -1) short_score++;
         }
      }
   }
};

#endif  // KMP_HARVESTER_LOGGER_MQH